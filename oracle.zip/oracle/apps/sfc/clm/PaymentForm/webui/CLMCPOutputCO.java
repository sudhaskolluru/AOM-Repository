/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package oracle.apps.sfc.clm.PaymentForm.webui;

import java.io.InputStream;
import java.io.Serializable;

import java.net.URL;

import java.net.URLConnection;

import java.sql.CallableStatement;
import java.sql.Types;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OARawTextBean;
import oracle.apps.fnd.framework.webui.beans.OAStaticStyledTextBean;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;
import oracle.apps.sfc.clm.PaymentForm.server.CLMPaymentAMImpl;

/**
 * Controller for ...
 */
public class CLMCPOutputCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
    CLMPaymentAMImpl    am  =   (CLMPaymentAMImpl)pageContext.getApplicationModule(webBean);

//  String cpReqid  = pageContext.getParameter("param1"); //get passed parameters
//  String reqno    = pageContext.getParameter("param2");
//  cpReqid="22333704";  841323
//  to get the value of output directory
//  String fileName = "/o"+cpReqid+".out";
//  Serializable[] s= {cpReqid,"OUTPUT"};
//  Get the output URL for this requests output.
//  String outputURL=(String)am.invokeMethod("getCPOutLogUrl",s);
//  String outputURL=
//  System.out.println("Action fired="+outputURL);

    String  outputURL   =   "";
    int     cpid        =   841323;

    String              stmt    = "BEGIN xxsify_clm_pay_wf_valid_pkg.clm_cp_output_get_url(:1,:2); end;";
    CallableStatement   cs      =  am.getOADBTransaction().createCallableStatement(stmt, 1);
    try
    {
        cs.setInt(1,  cpid  );  
        cs.registerOutParameter(2,Types.VARCHAR);
        cs.execute(); 
        outputURL = cs.getString(2);
        cs.close();
    } 
    catch (Exception e) 
    {
        throw new OAException("Error while calling clm_cp_output_get_url procedre"+e.getMessage());
    } 
//  ="http://ebsdev.sify.net:8000/OA_CGI/FNDWRR.exe?temp_id=2897464294";
    String msg  =   "";
    try
    {
        URL             url     =   new URL(outputURL);
        URLConnection   urlcon  =   url.openConnection();
        InputStream     stream  =   urlcon.getInputStream();
        int i;
        while((i=stream.read())!=-1)
        {
            msg =   msg+(char)i;
            System.out.print((char)i);
        }

    }
    catch(Exception e)
    {
        System.out.println(e);
    }
    System.out.println("In open popup co="+msg);
//  OAStaticStyledTextBean text = (OAStaticStyledTextBean)webBean.findChildRecursive("text");
//  text.setText(pageContext,msg);

//  OAMessageStyledTextBean text = (OAMessageStyledTextBean)webBean.findChildRecursive("text");
//  text.setText(pageContext,msg);

//  OARawTextBean text1 = (OARawTextBean)webBean.findChildRecursive("text1");
//  text1.setValue(pageContext,msg);
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
        super.processFormRequest(pageContext, webBean);
  }

}
