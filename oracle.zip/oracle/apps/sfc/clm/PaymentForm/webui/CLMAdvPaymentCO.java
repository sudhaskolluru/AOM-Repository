/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package oracle.apps.sfc.clm.PaymentForm.webui;

import java.io.Serializable;

import java.sql.CallableStatement;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OADialogPage;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.sfc.clm.PaymentForm.server.CLMPaymentAMImpl;
import oracle.apps.sfc.clm.PaymentForm.server.CLMPaymentInvoiceEOVORowImpl;

/**
 * Controller for ...
 */
public class CLMAdvPaymentCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");
        
    String clmid    =   "";
//  String bwReqid  =   "";
    String poNo     =   "";
    String saveFlag =   "";

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
    CLMPaymentAMImpl    am  =   (CLMPaymentAMImpl)pageContext.getApplicationModule(webBean);
//  Serializable        s[] =   {clmid,"create"};
    clmid                   =   pageContext.getParameter("clmId");
//  bwReqid                 =   pageContext.getParameter("bwReqId");
    poNo                    =   pageContext.getParameter("poNo");
    System.out.println("in adv co1");
//    am.invokeMethod("executAdvancePayVO",new Serializable[]{clmid,poNo} );
    am.executAdvancePayVO(clmid,poNo);
//    am.invokeMethod("setAdvValues");
    am.setAdvValues();
//  am.invokeMethod("HandlePPR");
    System.out.println("in pg co");
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    CLMPaymentAMImpl    am  =   (CLMPaymentAMImpl)pageContext.getApplicationModule(webBean);
    OAViewObject        vo  =   am.getCLMPaymentInvoiceEOVO1();
    if (pageContext.getParameter("SaveBtn") != null)
    {
        saveFlag    =   "Y";
        int advAmt  =   0;
        int poAmt   =   0;
        
        for (int i = 0; i < vo.getFetchedRowCount(); i++)
        {   
            CLMPaymentInvoiceEOVORowImpl rowi = ( CLMPaymentInvoiceEOVORowImpl)vo.getRowAtRangeIndex(i);        
            if(rowi.getInvoiceAmount() == null || rowi.getInvoiceAmount().equals(""))
            {                        
                throw new OAException("Please Enter Advance Amount",OAException.ERROR);              
            }
            if(rowi.getClmInvoiceNumber() == null || rowi.getClmInvoiceNumber().equals(""))
            {
                throw new OAException("Please Enter Advance Invoice Number",OAException.ERROR);              
            }
            if(rowi.getInvoiceAmount() != null) 
            {
                advAmt  =   rowi.getInvoiceAmount().intValue();
                poAmt   =   rowi.getPoAmount().intValue();
                if ( advAmt > poAmt  ) 
                {
                    saveFlag    =   "N";
                    throw new OAException("Advance Amount Exceeds PO Amount:",OAException.ERROR);
                }
            }
            rowi.setInvoiceWfStatus("Saved");
            rowi.setSaveFlag("Y");
            rowi.setInvoiceStatus("New");
        }
        //  pageContext.putSessionValue("clmIdS1",clmid);
        //  pageContext.putSessionValue("poNoS1",pono);
        am.getOADBTransaction().commit();
        throw new OAException("Saved Successfully..",OAException.CONFIRMATION);     
    }
    if (pageContext.getParameter("SubmitBtn") != null)
    {
        int advAmt  =   0;
        int poAmt   =   0;
        //  if(pageContext.getSessionValue("clmIdS1")!=null && pageContext.getSessionValue("poNoS1")!=null){
        
        //   String lid=(String)pageContext.getSessionValue("clmIdS1");
        //   String pno=(String)pageContext.getSessionValue("poNoS1");
        for (int i = 0; i < vo.getFetchedRowCount(); i++)
        {   
            CLMPaymentInvoiceEOVORowImpl rowi = ( CLMPaymentInvoiceEOVORowImpl)vo.getRowAtRangeIndex(i);                
            // clmid=rowi.getClmId();
            //poNo=rowi.getPoNumber();   
            if(rowi.getInvoiceAmount() == null || rowi.getInvoiceAmount().equals(""))
            {                        
                throw new OAException("Please Enter Advance Amount",OAException.ERROR);              
            }
            if(rowi.getClmInvoiceNumber() == null || rowi.getClmInvoiceNumber().equals(""))
            { 
                throw new OAException("Please Enter Advance Invoice Number",OAException.ERROR);              
            }    
            if(rowi.getInvoiceDate() == null)
            {
                throw new OAException("Please Enter Invoice Date",OAException.ERROR);              
            }
            if(rowi.getInvoiceAmount() != null) 
            { 
                advAmt  =   rowi.getInvoiceAmount().intValue();
                poAmt   =   rowi.getPoAmount().intValue();
                if ( advAmt > poAmt  ) 
                {
                    saveFlag    =   "N";
                    throw new OAException("Advance Amount Exceeds PO Amount:",OAException.ERROR);
                }  
            }
            rowi.setInvoiceWfStatus("Submitted");
            rowi.setSaveFlag("N");
            rowi.setInvoiceStatus("New");
            rowi.setAdvAmount(rowi.getInvoiceAmount());
            rowi.setAdvInvoiceNo(rowi.getClmInvoiceNumber());
        } 
        am.getOADBTransaction().commit();
        String stmt = "BEGIN xxsify_clm_pay_wf_valid_pkg.sify_clm_pay_adv_submit(:1,:2,:3,:4); end;";
        CallableStatement cs =  am.getOADBTransaction().createCallableStatement(stmt, 1);
        try 
        {
            cs.setString(1,clmid);
            cs.setString(2,poNo);
            cs.setString(3,pageContext.getUserName());
            cs.setString(4,saveFlag);
            cs.execute(); 
            cs.close();
        } 
        catch (Exception e) 
        {
            throw new OAException("Error while submitting advance invoice wf"+e.getMessage());
        } 
        OAException confirmMessage  =   new OAException("The Invoice for the CLM ID "+clmid+" submitted for approval");
        OADialogPage dialogPage     =   new OADialogPage(OAException.CONFIRMATION, confirmMessage, null, "OA.jsp?page=/oracle/apps/sfc/clm/PaymentForm/webui/CLMAdvancePayHomePG",  null);
        pageContext.redirectToDialogPage(dialogPage);
    }
    if (pageContext.getParameter("CancelBtn") != null)
    {
        pageContext.setForwardURL(  "OA.jsp?page=/oracle/apps/sfc/clm/PaymentForm/webui/CLMAdvancePayHomePG"    , 
                                    null                                                                        , 
                                    OAWebBeanConstants.KEEP_MENU_CONTEXT                                        , 
                                    null                                                                        , 
                                    null                                                                        , 
                                    false                                                                       , 
                                    OAWebBeanConstants.ADD_BREAD_CRUMB_NO                                       , 
                                    OAWebBeanConstants.IGNORE_MESSAGES
                                );
    }
  }
}
