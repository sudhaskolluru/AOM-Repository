/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package oracle.apps.sfc.clm.poform.webui;

import com.sun.java.util.collections.HashMap;

import java.io.BufferedReader;
import java.io.InputStream;

import java.sql.CallableStatement;
import java.sql.Types;

import jxl.Cell;
import jxl.CellType;
import jxl.Sheet;
import jxl.Workbook;


import jxl.read.biff.BiffException;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import oracle.cabo.ui.data.DataObject;

import oracle.jbo.Row;
import oracle.jbo.domain.BlobDomain;
import oracle.jbo.server.ViewObjectImpl;

/**
 * Controller for ...
 */
public class CLMCreateCircuitCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");
    public String errFlag="N";

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
      
    String  hdrid   =   pageContext.getParameter("PO_HDR_ID"); 
    String  clmId   =   pageContext.getParameter("PO_CLM_ID"); 
    
    OAApplicationModule am          = pageContext.getApplicationModule(webBean);
    OAViewObject        vo          = (OAViewObject)am.findViewObject("CLMCircuitTempDowloadVO");
    vo.executeQuery();
    
    OAViewObject        circuitVO   = (OAViewObject)am.findViewObject("CLMCircuitIdsVO");
    
    circuitVO.setWhereClause(null);
    circuitVO.setWhereClauseParams(null);
    circuitVO.setWhereClause("clm_id=:1");
    circuitVO.setWhereClauseParam(0,clmId);
    circuitVO.executeQuery();
  
    //  PoAM.executeCircuitVO(hdrid,clmId);  
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
     super.processFormRequest(pageContext, webBean);
     OAApplicationModule am = pageContext.getApplicationModule(webBean);
     
     String     hdrid   =   pageContext.getParameter("PO_HDR_ID"); 
     String     clmId   =   pageContext.getParameter("PO_CLM_ID"); 
     int        batchId =   0;
     String     errmsg  =   "";
    
     // String Session = (String)pageContext.getSessionValueDirect("Session");     
     // if (pageContext.getParameter("craeteRow") != null) {
    
    /*  
     *  if ("CreateRow".equals(pageContext.getParameter("event"))) 
     *  {        
            PoAM.createCircuitRow(hdrid,clmId);
        }
      
        if ("delete".equals(pageContext.getParameter("event"))) 
        {
            //ReqAM.deleteRecord();
             String rowref=pageContext.getParameter(OAWebBeanConstants.EVENT_SOURCE_ROW_REFERENCE);      
            Row rw=(Row)PoAM.findRowByRef(rowref);
            rw.remove(); 
        }*/      
        /*  
         * if ("checkCircuitIdDuplicate".equals(pageContext.getParameter("event"))) 
         * {       
                String  rowref  =   pageContext.getParameter(OAWebBeanConstants.EVENT_SOURCE_ROW_REFERENCE);      
                Row     rw      =   (Row)PoAM.findRowByRef(rowref);
                if(rw.getAttribute("CircuitId")!=null) 
                {
                    String  circuitId= (String)rw.getAttribute("CircuitId")+"";
                    String result=(String)PoAM.checkCircuitIdExists(hdrid,clmId,circuitId);
                    if ("Y".equalsIgnoreCase(result))
                    {      
                        throw new OAException("Circuit Id already used for other CLM ID.Please enter different Circuit Id",OAException.ERROR); 
                    }
                }      
           }*/
      
        //   if (pageContext.getParameter("saveBtn") != null) {
        /*  if ("SaveEvent".equals(pageContext.getParameter(EVENT_PARAM))) 
         *  {       
                System.out.println("inside save");
                PoAM.getOADBTransaction().commit();
                HashMap hm=new HashMap();
                hm.put("BackNavFrom","CircuitPage");     
                //  hm.put("circuitMode","EditMode");  
                hm.put("pMode","EditMode");
                pageContext.forwardImmediately("OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMPoCreatePG",
                null,
                OAWebBeanConstants.KEEP_MENU_CONTEXT,
                null,
                hm,
                true, // retain AM
                OAWebBeanConstants.ADD_BREAD_CRUMB_NO);
             } */
      
        if("UploadDataEvent".equals(pageContext.getParameter(EVENT_PARAM)))
        {
            errFlag =   "N";
            System.out.println("upload event fired "+errFlag);        
            
            if (pageContext.getSessionValue("UploadClicked")== null) 
            {
                System.out.println("upload clicked "+errFlag);        
                pageContext.putSessionValue("UploadClicked","Y");         
                ViewObjectImpl  vo              =  (ViewObjectImpl)am.findViewObject("CLMPoCircuitsTabEOVO");
                DataObject      excelUploadData =  pageContext.getNamedDataObject("UploadItem");
        
                //  System.out.println("vo init ");
                //  Declare Variable that will be used in reading uploaded file  
                batchId =   am.getOADBTransaction().getSequenceValue("xxsify_clm_circuit_id_s").intValue();
        
                String          fileName         = null;  
                String          contentType      = null;  
                Long            fileCapacity     = null;  
                BlobDomain      uploadStream     = null;  
                BufferedReader  inReader         = null;  
                try 
                {  
                    fileName        =   (String)excelUploadData.selectValue(null, "UPLOAD_FILE_NAME");  
                    contentType     =   (String)excelUploadData.selectValue(null, "UPLOAD_FILE_MIME_TYPE");  
                    uploadStream    =   (BlobDomain)excelUploadData.selectValue(null, fileName);                  
                }        
                catch (NullPointerException ex) 
                {  
                    System.out.println("exception as it is not excel file catch ex");
                    throw new OAException("Please Select an Excel File to Upload it to Database!!!",  OAException.ERROR);          
                }
                try
                {        
                    String[]    excel_data      = new String[32];
                    InputStream inputWorkbook   = uploadStream.getInputStream();
                    Workbook w;
                    System.out.println(" Into Readexcel method :" ) ;                    
                    try
                    {   
                        w           =   Workbook.getWorkbook(inputWorkbook);                    
                        // Get the first sheet
                        Sheet sheet =   w.getSheet(0);
                    
                        for (int i = 1; i < sheet.getRows(); i++)
                        {
                            System.out.println(" Into i->"+i) ;
                            for (int j = 0; j < sheet.getColumns(); j++)
                            {
                                System.out.println(" Into j->"+j) ;
                                Cell        cell = sheet.getCell(j, i);
                                CellType    type = cell.getType();
                                if (cell.getType() == CellType.LABEL)
                                {
                                    //System.out.println("I got a char " + cell.getContents());
                                    excel_data[j] = cell.getContents();
                                }                                
                                else if (cell.getType() == CellType.NUMBER)
                                {
                                    //System.out.println("I got a number " + cell.getContents());                                
                                    excel_data[j] = cell.getContents();                                
                                }                                
                                else if(cell.getType()==CellType.DATE)
                                {
                                    //System.out.println("I got a date " + cell.getContents());
                                    excel_data[j] = cell.getContents();
                                }
                                else
                                {
                                
                                }
                            }  // columns  j for loop end;                                        
                            vo.setMaxFetchSize(0) ;
                            Row row = vo.createRow();
                            try
                            {
                                //  for (int i=0; i < excel_data.length; i++)
                                if (excel_data.length > 1 )
                                {
                                row.setAttribute("ClmId", clmId);
                                row.setAttribute("CircuitId", excel_data[0]);
                                row.setAttribute("Attribute2", "New");
                                row.setAttribute("Attribute1", batchId);
                                }  // IF excel data length
                                System.out.println("after IF excel data length ");
                            }  // TRY
                            catch(Exception e)
                            {
                                // System.out.println(e.getMessage());
                                errFlag="Y";
                                errmsg=e.getMessage();
                            }
                        System.out.println("before insert row");
                        vo.insertRow(row);
                    } // rows i for loop end
                    System.out.println("before try end");
                } // try end
                catch (BiffException e)
                {
                    errFlag="Y";
                    errmsg=e.getMessage();
                    //   throw new OAException("error while reading excel file"+e.getMessage(),OAException.ERROR);
                }
                System.out.println("before main try");
            } // Main try
            catch(Exception e)
            {
                errFlag="Y";
                errmsg=e.getMessage();
            }
            System.out.println("after main try");        
            if (!errFlag.equalsIgnoreCase("N"))
            {
                System.out.println("error flag Y->"+errFlag);
                pageContext.removeSessionValue("UploadClicked");
                throw new OAException("Upload Fail due to =>"+errmsg,OAException.ERROR);     
            }
        }
        am.getOADBTransaction().commit(); 
        
        String errMsg1  =   "N";
        String stmt     =   "BEGIN xxsify_clm_po_wf_pkg.circuit_id_load_validations(:1,:2,:3); end;";
        CallableStatement cs = 
        am.getOADBTransaction().createCallableStatement(stmt, 1);
        try 
        {        
            cs.setInt(1,batchId);
            cs.setInt(2,Integer.parseInt(clmId));
            cs.registerOutParameter(3,Types.VARCHAR);           
            cs.execute(); 
            errMsg1=cs.getString(3);
            cs.close();
        } 
        catch (Exception e) 
        {
            pageContext.removeSessionValue("UploadClicked");
            throw new OAException("Error while calling circuit_id_load_validations "+e.getMessage());
        }         
        System.out.println("errmag1="+errMsg1);        
        if (!"N".equals(errMsg1))
        {        
            pageContext.removeSessionValue("UploadClicked");        
            throw new OAException("Upload Fails due to=>"+errMsg1,OAException.ERROR);        
        }               
        //  HashMap hm=new HashMap();
        //  hm.put("BackNavFrom","CircuitPage");          
        //  hm.put("circuitMode","EditMode");
        //  hm.put("pMode","EditMode");
        
        
        OAViewObject circuitVO = (OAViewObject)am.findViewObject("CLMCircuitIdsVO");
        circuitVO.setWhereClause(null);
        circuitVO.setWhereClauseParams(null);
        circuitVO.setWhereClause("clm_id=:1");
        circuitVO.setWhereClauseParam(0,clmId);
        circuitVO.executeQuery();
        
        /*  OADialogPage dialogPage = 
        new OADialogPage(OAException.CONFIRMATION, confirmMessage, 
        null, 
        "OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMPoCreatePG&retainAM=Y&pMode="+"EditMode"+"&BackNavFrom="+"CircuitPage", 
        null);
        
        pageContext.redirectToDialogPage(dialogPage);*/
        pageContext.removeSessionValue("UploadClicked");
        throw new OAException("Data Uploaded Successfully",OAException.CONFIRMATION);
        // pageContext.forwardImmediatelyToCurrentPage(null,true,"Y");
        // OAException confirmMessage =  new OAException("Data Uploaded Successfully",OAException.CONFIRMATION);
        // pageContext.putDialogMessage(confirmMessage);
        }
        if (pageContext.getParameter("BackBtn") != null) 
        {
            pageContext.removeSessionValue("UploadClicked");
            HashMap hm=new HashMap();
            hm.put("BackNavFrom","CircuitPage");          
            //  hm.put("circuitMode","EditMode");  
            hm.put("pMode","EditMode");
            
            pageContext.forwardImmediately  (
                                                "OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMPoCreatePG"   ,
                                                null                                                            ,
                                                OAWebBeanConstants.KEEP_MENU_CONTEXT                            ,
                                                null                                                            ,
                                                hm                                                              ,
                                                true                                                            , // retain AM
                                                OAWebBeanConstants.ADD_BREAD_CRUMB_NO
                                            );
      }
  }

}
