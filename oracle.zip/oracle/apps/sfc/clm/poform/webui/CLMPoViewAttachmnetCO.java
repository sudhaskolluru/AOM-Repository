/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package oracle.apps.sfc.clm.poform.webui;

import com.sun.java.util.collections.HashMap;


import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.sfc.clm.poform.server.CLMCreatePoAMImpl;
/**
 * Controller for ...
 */
public class CLMPoViewAttachmnetCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region. 
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
      super.processRequest(pageContext, webBean);
    
      //      String PO_HDR_ID=pageContext.getParameter("PO_HDR_ID");
      //      String PO_CLM_ID=pageContext.getParameter("PO_CLM_ID");
      //      String BW_CLM_ID=pageContext.getParameter("BW_CLM_ID");
      //      System.out.println("PO_CLM_ID "+PO_CLM_ID);

    //  String BW_REQ_ID="";

        if(pageContext.getSessionValue("pModeSessionVal") != null)
        {
            pageContext.removeSessionValue("pModeSessionVal");
        }
        if(pageContext.getSessionValue("PoBwReqIDSessionVal") != null)
        {
            pageContext.removeSessionValue("PoBwReqIDSessionVal");
        }
        CLMCreatePoAMImpl PoAM =  (CLMCreatePoAMImpl)pageContext.getApplicationModule(webBean);
      
        String pMode        =   pageContext.getParameter("pMode");
        String BW_REQ_ID    =   pageContext.getParameter("PO_BW_REQ_ID"); 
        String PO_HDR_ID    =   pageContext.getParameter("PO_HDR_ID");
        System.out.println("BW_REQ_ID "+BW_REQ_ID);
        System.out.println("pMode "+pMode);
        System.out.println("in view attach pg PO_HDR_ID "+PO_HDR_ID);
      
        pageContext.putSessionValue("pModeSessionVal",pMode);   
        pageContext.putSessionValue("PoBwReqIDSessionVal",BW_REQ_ID);   
      
        OAViewObject vo = PoAM.getCLMViewPOAttachmentsVO();
        vo.setWhereClause(null);
        vo.setWhereClauseParams(null);
        // vo.setWhereClause("BAND_WIDH_REQ_ID=:1");
        //vo.setWhereClauseParam(0,BW_REQ_ID);  
        vo.setWhereClause("clm_po_hdr_id=:1");
        vo.setWhereClauseParam(0,PO_HDR_ID);
        vo.executeQuery();
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    
      CLMCreatePoAMImpl PoAM =   (CLMCreatePoAMImpl)pageContext.getApplicationModule(webBean);
      String Event = pageContext.getParameter(EVENT_PARAM);
      String BW_REQ_ID=pageContext.getParameter("PO_BW_REQ_ID"); 
      String PO_HDR_ID=pageContext.getParameter("PO_HDR_ID");
      
      if ("BACKPG".equalsIgnoreCase(Event)) 
      {  
          HashMap hm=new HashMap();
          hm.put("BackNavFrom","AttachPage");          
          pageContext.forwardImmediately("OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMPoCreatePG",
                                          null                                      ,
                                          OAWebBeanConstants.KEEP_MENU_CONTEXT      ,
                                          null                                      ,
                                          hm                                        ,
                                          true                                      , // retain AM
                                          OAWebBeanConstants.ADD_BREAD_CRUMB_NO);
      }
      if ("ADDFILE".equalsIgnoreCase(Event)) 
      {
        String pModeVal=(String )pageContext.getSessionValue("pModeSessionVal");
        String poBwreqID=(String )pageContext.getSessionValue("PoBwReqIDSessionVal");
        System.out.println("pModeVal ADD"+pModeVal);
        System.out.println("poBwreqID   ADD "+poBwreqID);
        HashMap params=new HashMap();
        params.put("pModeVal",pModeVal);
        params.put ("poBwreqID",BW_REQ_ID);
        params.put ("PO_HDR_ID",PO_HDR_ID);
        pageContext.forwardImmediately("OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMPoAddAttachmentPG", 
                                        null, (byte)0, null, params, true, 
                                        "N");
      }
      if ("UPDATTACH".equalsIgnoreCase(Event)) 
      {
        String pModeVal=(String )pageContext.getSessionValue("pModeSessionVal");
        String poBwreqID=(String )pageContext.getSessionValue("PoBwReqIDSessionVal");
        System.out.println("pModeVal update "+pModeVal);
        System.out.println("poBwreqID   update "+poBwreqID);
        HashMap params=new HashMap();
        params.put("pModeVal",pModeVal);
        params.put ("poBwreqID",BW_REQ_ID);
        params.put ("PO_HDR_ID",PO_HDR_ID);
        pageContext.forwardImmediately("OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMPoAddAttachmentPG", 
                                      null, (byte)0, null, params, true, 
                                      "N");
    }
    if ("DELATTACH".equalsIgnoreCase(Event)) 
    {  
        String bwReqId=pageContext.getSessionValue("PoBwReqIDSessionVal")+"";
        String attachID= pageContext.getParameter("SelectedAttachID");
        System.out.println("attachid "+attachID);
        PoAM.DeleteAttach(attachID,bwReqId);
    }
  }//PFR

}
