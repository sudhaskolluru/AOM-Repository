package oracle.apps.sfc.clm.poform.webui;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.StringTokenizer;
import java.util.Vector;
import oracle.jbo.domain.Number;

public class CLMClass1 
{
    public CLMClass1() 
    {
    }
    public static void main(String args[])
    {
    
        //PROGRAM #1    WHITESPACE TRIM IN STRING
        String  str         =   "250000�";        
        String  mysz2       =   str.replaceAll("\\W","");
        Number  directNum   =   new Number(0);
        try
        {
            directNum=new Number(Integer.parseInt(mysz2.trim()));
        }
        catch(Exception e)
        {        
            System.out.println(" catch "+e.getMessage());
        }
        
        System.out.println("Trimmed String   "+directNum);            
        //PROGRAM #2  : PREVIOUS DATE        
        String                  commDate        =   "2017-12-01";        
        oracle.jbo.domain.Date  jboCommDate     =   null;
        oracle.jbo.domain.Date  jboPoEndDate    =   null;
        oracle.jbo.domain.Date  convPoEndDate   =   null;
        
        DateFormat      formatter;
        java.util.Date  cdate;
                
        if (commDate != null) 
        {
            try 
            {
                formatter   = new SimpleDateFormat("yyyy-MM-dd");
                cdate       = formatter.parse(commDate);
                java.sql.Date POsqlDate     =   new java.sql.Date(cdate.getTime()+ 364L * 24 * 60 * 60 * 1000);            
                java.sql.Date sqlDate       =   new java.sql.Date(cdate.getTime()-1);            
                jboCommDate                 =   new oracle.jbo.domain.Date(sqlDate);
                jboPoEndDate                =   new oracle.jbo.domain.Date(POsqlDate);            
                /*            
                    Calendar c1 = Calendar.getInstance();
                    c1.setTime(jboPoEndDate.getValue());
                    c1.add(Calendar.DATE, 364);            
                    java.util.Date javaUtilDate = c1.getTime();
                    java.sql.Date posqldate = new java.sql.Date(javaUtilDate.getTime()); 
                    convPoEndDate=new oracle.jbo.domain.Date(posqldate);
                */            
            } 
            catch (ParseException e) 
            {
                e.printStackTrace();
            }
        }
        
        System.out.println("previous date for given DATE:  "+jboCommDate);        
        System.out.println("next year for given DATE:  "+jboPoEndDate);        
        //PROGRAM #3 : COMPARE DATES        
        oracle.jbo.domain.Date jboCommissionDate    = null;
        oracle.jbo.domain.Date jboApprovalDate      = null;
        
        DateFormat fmter;
        
        //java.util.Date aDate,Bdate;
        
        String commidate=   "2017-11-20";
        String appDate  =   "2017-11-27";
        
        if (commidate != null) 
        {
            try 
            {
                formatter = new SimpleDateFormat("yyyy-MM-dd");                
                java.util.Date cdDate = formatter.parse(commidate);
                java.util.Date apdate = formatter.parse(appDate);
                
                
                int comparison = cdDate.compareTo(apdate);  //if 1 
                
                if(comparison ==0)
                {
                    System.out.println(" equal dates "+comparison);
                }
                else if (comparison ==1)
                {
                    System.out.println(" comm date is greater "+comparison);
                }
                else if(comparison==-1)
                {
                    System.out.println(" comm date is smaller "+comparison);
                }
                else
                {
                
                }            
            } 
            catch (ParseException e) 
            {
                e.printStackTrace();
            }
        }
        //PROGRAM #4 : STRING TOKENS
        
        Vector  errMsgs     =   new Vector();
        String  nulVal      =   null;
        String  retValues   =   "## update value";
        
        if(retValues !=null)
        {
            StringTokenizer st2 = new StringTokenizer(retValues, "##");
            while(st2.hasMoreTokens())
            {
                errMsgs.add(st2.nextToken());
                System.out.println(" err token "+errMsgs.toString());
            }
            System.out.println("errmessage size :"+errMsgs.size());
        
            if(errMsgs!=null && errMsgs.size()>1)
            {
                for(int i=1;i<errMsgs.size();i++)
                {
                    System.out.println(" i in vector size ");
                    System.out.println(errMsgs.get(i).toString());
                }
            }        
            else if(errMsgs.size()==1)
            {               
                System.out.println(" errmsgs.size =1 ");
                System.out.println(errMsgs.get(0).toString());            
            }        
            else if(errMsgs.size()==0)
            {
                System.out.println(" errmsgs.size =0 ");
                System.out.println("ret val "+retValues);
            }
            else
            {
                System.out.println("ret val "+retValues);
            }        
        }
        else
        System.out.println("ret val "+retValues);
        
        String amt  =   " ";
        
        String oldPrice = amt.replaceAll("\\W","");
        System.out.println("oldPrice "+oldPrice);
        
        try
        {
            Number  abc =   new Number(Double.parseDouble(oldPrice.trim()));
            System.out.println("number field is "+abc);
        }
        catch( Exception e)
        {
            System.out.println("e.message"+e.getMessage());
        }        
    }//maiin pgm   
}
