/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package oracle.apps.sfc.clm.InvoiceBulkUpload.webui;

import java.sql.PreparedStatement;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.server.common.OAApplicationModule;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;

/**
 * Controller for ...
 */
public class XXSifyCLMInvBulkUploadHomePGCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");
    String suppName="";
     String respName="";
  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
      OAApplicationModule am = (OAApplicationModule)pageContext.getApplicationModule(webBean);
      int userid=pageContext.getUserId();
      System.out.println("userid -->"+userid);
      
      respName = pageContext.getResponsibilityName();
      System.out.println("respName -->"+respName);
      
      if ( respName.equals(pageContext.getProfile("XXSIFY_LMS_ISUPP_RESP"))||respName.equals(pageContext.getProfile("Sify iSupplier Invoice Upload"))){
                                     
               Connection conn2 =(Connection)am.getOADBTransaction().getJdbcConnection();
               try
               {
                       String qry1="select aps.vendor_name\n" + 
                       "from\n" + 
                       "fnd_user fu,\n" + 
                       "ak_web_user_sec_attr_values ak,\n" + 
                       "ap_suppliers aps\n" + 
                       "where fu.user_id=ak.web_user_id\n" + 
                       "and ak.number_value=aps.vendor_id\n" + 
                       "and ak.attribute_code='ICX_SUPPLIER_ORG_ID'\n" + 
                       "and fu.user_id=(:1)";
                      
                       
                       PreparedStatement stmt1;         
                       stmt1 = conn2.prepareStatement(qry1);   
                       stmt1.setInt(1, userid);    
                                       for (ResultSet resultset = stmt1.executeQuery(); resultset.next(); )
                                       {                   
                                        suppName = resultset.getString(1);                   
                                       }
                                       stmt1.close();

                   } catch (SQLException e)
                   {         
                  throw new OAException("Error while getting supplier details=>"+e.getMessage());         
                   }
                   
          OAViewObject vo=(OAViewObject)am.findViewObject("CLMInvoiceHomeVO1");
          vo.setWhereClause(null);
          vo.setWhereClauseParams(null);
          //vo.setWhereClause("Supplier=:1");
          //vo.setWhereClauseParam(0,suppName);
		  vo.setWhereClause("Supplier='"+suppName+"'");
          vo.executeQuery();
          
          OAMessageLovInputBean lov=(OAMessageLovInputBean)webBean.findChildRecursive("vendorSearch");
          lov.setValue(pageContext,suppName);
          lov.setReadOnly(Boolean.TRUE);
      }
                  
               
    //)
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
      String supp="";
         String vendor ="";
           OAApplicationModule am = (OAApplicationModule)pageContext.getApplicationModule(webBean);
        String bno = pageContext.getParameter("batchNoItem");
         //String 
         vendor = pageContext.getParameter("vendorSearch");
         String fromDate = pageContext.getParameter("fromDateSearch");
         String toDate = pageContext.getParameter("toDateSearch");
      
      if (pageContext.getParameter("SearchBtn") != null){
                          OAViewObject vo=(OAViewObject)am.findViewObject("CLMInvoiceHomeVO1");
                          System.out.println("bn"+bno);
                          System.out.println("sup"+vendor);
                          System.out.println("fd"+fromDate);
                          System.out.println("td"+toDate);
                          vo.setWhereClause(null);
                          vo.setWhereClauseParams(null);
                          vo.setWhereClause("stg_batch_id=nvl(:1,stg_batch_id) and supplier=nvl(:2,supplier) and trunc(creation_date) between nvl(:3,trunc(creation_date)) and nvl(:4,trunc(creation_date))");
                          vo.setWhereClauseParam(0, bno);
                          vo.setWhereClauseParam(1, vendor);
                          vo.setWhereClauseParam(2, fromDate);
                          vo.setWhereClauseParam(3, toDate);
                          System.out.println("  vo query "+vo.getQuery());
                          vo.executeQuery();
                          
                      }
                      
                      
          if (pageContext.getParameter("StandardInvBtn") != null){
                    
                    pageContext.setForwardURL("OA.jsp?page=/oracle/apps/sfc/clm/InvoiceBulkUpload/webui/XXSifyCLMInvBulkUploadPG", 
                                                       null, 
                                                       OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                                       null, 
                                                       null , 
                                                       true, 
                                                       OAWebBeanConstants.ADD_BREAD_CRUMB_YES, 
                                                       OAWebBeanConstants.IGNORE_MESSAGES);
          }
  }

}
