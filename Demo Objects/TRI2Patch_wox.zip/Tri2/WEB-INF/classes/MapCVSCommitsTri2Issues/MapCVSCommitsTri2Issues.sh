echo "Runnning MapCVSCommitsTri2Issues.sh inturn cvs-changelog-build.xml ant build file"
ant -buildfile cvs-changelog-build.xml > MapCVSCommitsTri2Issues.log
echo "MapCVSCommitsTri2Issues.sh Ran successfully"

