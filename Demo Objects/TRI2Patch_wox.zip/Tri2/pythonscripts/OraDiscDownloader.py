import StringIO
import fnmatch
import socket
import sys
import time
import select
import shutil

import paramiko
import os



try:
    print 'Number of arguments:', len(sys.argv), 'arguments.'
    #destinationPassword was also getting printed in TRI2 logs so commented the below statement.
    #print 'Argument List:', str(sys.argv)

    objectType       = sys.argv[1]
    sourceInstanceIP = sys.argv[2]
    sudoToUser       = sys.argv[3]
    sourceInstanceUname     = sys.argv[4]
    sourceInstancePassword  = sys.argv[5]
    appsDetails    = sys.argv[6]
    logFileName    = sys.argv[7]
    eulName        = sys.argv[8]
    objectIdentifier  = sys.argv[9]
    uploadBasedir     = sys.argv[10]
    connectToSudoCmd  = sys.argv[11]
    destinationDir    = sys.argv[12]
    objectName = objectIdentifier + ".eex"
    eulNameeex = eulName + ".eex"

    print "objectType:" + objectType + "sourceInstanceIP:" + sourceInstanceIP + "sudoToUser:" + sudoToUser + "sourceInstanceUname:" + sourceInstanceUname + "appsDetails:" + appsDetails + "logFileName:" + logFileName + "eulName:" + eulName + "objectIdentifier:" + objectIdentifier + "uploadBasedir:" + uploadBasedir+ "connectToSudoCmd:" + connectToSudoCmd + "destinationDir:" + destinationDir + "objectName:" + objectName + "eulNameeex:" + eulNameeex

    contents = StringIO.StringIO()
    error = StringIO.StringIO()
    logfile = "extractAOLlog.log"
    migrationLogFile = open(logFileName, "a")

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(sourceInstanceIP, username=sourceInstanceUname, password=sourceInstancePassword)
    print "objectname:" + objectName

    def Copy():
        remotedir = uploadBasedir  + "/" + objectIdentifier + "/"
        localdir = destinationDir + "/"
        print remotedir
        print localdir
        print "remotedir:" + remotedir + ", localdir:" + localdir
        sftp = ssh.open_sftp()
        remoteFiles = sftp.listdir(path=remotedir)
        for files in remoteFiles:
            print "files:" + files
            if fnmatch.fnmatch(files, objectName):
                sftp.get(remotedir + files, localdir + files)

    print "creating directory"
    chan1 = ssh.get_transport().open_session()
    chan1.get_pty()
    chan1.settimeout(1080)
    chan1.exec_command("mkdir -p  " + uploadBasedir + "/" + objectIdentifier+ " ; chmod -R 777 " + uploadBasedir + "/" + objectIdentifier + ";whoami")
    exit_status = chan1.recv_exit_status()
    print "created directory"

    def writingLogs():
        remotedir = uploadBasedir + "/"
        localdir = fileNameStr + "/"
        print "remotedir:" + remotedir + ", localdir:" + localdir
        sftp = ssh.open_sftp()
        remoteFiles = sftp.listdir(path=remotedir)
        for files in remoteFiles:
            print "files:" + files
            if fnmatch.fnmatch(files, 'extractAOLlog.log'):
                sftp.get(remotedir + files, localdir + files)
        f = open(localdir + "extractAOLlog.log")
        for line in f.readlines():
            print "line:" + line
            migrationLogFile.write(line)
        f.close()

    def deletingLogs():
        command = "rm -rf " + uploadBasedir + "/"+objectIdentifier
        Channel = ssh.get_transport().open_session()
        Channel.get_pty()
        Channel.settimeout(1080)
        Channel.exec_command(command)
        Channel.exit_status = Channel.recv_exit_status()

    def channelCreation(command):
        Channel = ssh.get_transport().open_session()
        Channel.get_pty()
        Channel.settimeout(1080)
        Channel.exec_command(command)
        Channel.recv_exit_status()
        return

except Exception as copyObjectException:
    print "Exception:"
    print copyObjectException

    #migrationLogFile.write(str(copyObjectException))

finally:
    print "finally1 block........................"

try:

    if objectType == "BUSINESS_AREA":
        if  sudoToUser != "" and sudoToUser != "null":
            command1 = "%s 'whoami; cd /home/%s; pwd; . .bash_profile;eulapi -connect %s  -eul %s -export %s/%s/%s -business_area_and_contents %s -identifier  -log  %s/%s/extractAOLlog.log;whoami;chmod -R 777 %s/%s/%s'" % (
            connectToSudoCmd, sudoToUser, appsDetails, eulName, uploadBasedir, objectIdentifier, objectName,
            objectIdentifier, uploadBasedir, objectIdentifier, uploadBasedir, objectIdentifier, objectName)
            channelCreation(command1)
            Copy()
        else:
                command1 = "pwd; . .bash_profile;eulapi -connect " + appsDetails + "  -eul " + eulName + " -export " + uploadBasedir + "/" + objectIdentifier + "/" + objectName + " -business_area_and_contents " + objectIdentifier + " -identifier  -log  " + uploadBasedir + "/" + objectIdentifier + "/extractAOLlog.log;whoami;chmod -R 777 " + uploadBasedir + "/" + objectIdentifier + "/" + objectName + ""
                channelCreation(command1)
                Copy()

    if objectType == "BA_FOLDER":
        if  sudoToUser != "" and sudoToUser != "null":
            command1 = "%s 'whoami; cd /home/%s; pwd; . .bash_profile;eulapi -connect %s  -eul %s -export %s/%s/%s -folder %s -identifier  -log  %s/%s/extractAOLlog.log;whoami;chmod -R 777 %s/%s/%s'" % (
            connectToSudoCmd, sudoToUser, appsDetails, eulName, uploadBasedir, objectIdentifier, objectName,
            objectIdentifier, uploadBasedir, objectIdentifier, uploadBasedir, objectIdentifier, objectName)
            channelCreation(command1)
            Copy()
        else:
                command1 = "pwd; . .bash_profile;eulapi -connect " + appsDetails + "  -eul " + eulName + " -export " + uploadBasedir + "/" + objectIdentifier + "/" + objectName + " -folder " + objectIdentifier + " -identifier  -log  " + uploadBasedir + "/" + objectIdentifier + "/extractAOLlog.log;whoami;chmod -R 777 " + uploadBasedir + "/" + objectIdentifier + "/" + objectName + ""
                channelCreation(command1)
                Copy()

    if objectType == "WORKBOOK":
        if  sudoToUser != "" and sudoToUser != "null":
            command1 = "%s 'whoami; cd /home/%s; pwd; . .bash_profile;eulapi -connect %s  -eul %s -export %s/%s/%s -workbook %s -identifier  -log  %s/%s/extractAOLlog.log;whoami;chmod -R 777 %s/%s/%s'" % (
            connectToSudoCmd, sudoToUser, appsDetails, eulName, uploadBasedir, objectIdentifier, objectName,
            objectIdentifier, uploadBasedir, objectIdentifier, uploadBasedir, objectIdentifier, objectName)
            channelCreation(command1)
            Copy()
        else:
                command1 = "pwd; . .bash_profile;eulapi -connect " + appsDetails + "  -eul " + eulName + " -export " + uploadBasedir + "/" + objectIdentifier + "/" + objectName + " -workbook " + objectIdentifier + " -identifier  -log  " + uploadBasedir + "/" + objectIdentifier + "/extractAOLlog.log;whoami;chmod -R 777 " + uploadBasedir + "/" + objectIdentifier + "/" + objectName + ""
                channelCreation(command1)
                Copy()

    if objectType == "DISCOVERER_EUL":
        if  sudoToUser != "" and sudoToUser != "null":
            command1 = "%s 'whoami; cd /home/%s; pwd; . .bash_profile;eulapi -connect %s  -eul %s -export %s/%s/%s -all -log  %s/%s/extractAOLlog.log;whoami;chmod -R 777 %s/%s/%s'" % (
            connectToSudoCmd, sudoToUser, appsDetails, eulName, uploadBasedir, eulName, eulNameeex,
            uploadBasedir, objectIdentifier, uploadBasedir, objectIdentifier, objectName)
            channelCreation(command1)
            Copy()
        else:
                command1 = "pwd; . .bash_profile;eulapi -connect " + appsDetails + "  -eul " + eulName + " -export " + uploadBasedir + "/" + eulName + "/" + eulNameeex + " -all  -log  " + uploadBasedir + "/" + objectIdentifier + "/extractAOLlog.log;whoami;chmod -R 777 " + uploadBasedir + "/" + objectIdentifier +"/" + objectName + ""
                channelCreation(command1)
                Copy()

except Exception as migrationException:
    print "Migration Exception:"
    print migrationException
    migrationLogFile.write(str(migrationException))

finally:
    deletingLogs()
    print "finally2block"
    migrationLogFile.close()
    ssh.close()
    sys.exit(1)