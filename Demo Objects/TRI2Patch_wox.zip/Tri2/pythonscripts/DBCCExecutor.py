import StringIO
import fnmatch
import socket
import sys
import time
import select
import shutil
from turtle import done

import paramiko
import os

try:
        print 'Number of arguments:', len( sys.argv ), ' arguments.'
        #destinationPassword was also getting printed in TRI2 logs so commented the below statement.
        #print 'Argument List:', str( sys.argv )
        appsSchemaPassword      = sys.argv[1]
        instanceUsername        = sys.argv[2]
        instancePassword        = sys.argv[3]
        instanceIp              = sys.argv[4]
        instancePortNumber      = sys.argv[5]
        logFileName             = sys.argv[6]
        tri2Directory           = sys.argv[7]
        isSudoUser              = sys.argv[8]
        sudoToUser              = sys.argv[9]
        uploadBaseTargetDir     = sys.argv[10]
        singleQuotes            = sys.argv[11]
        connectToSudoCmd        = sys.argv[12]
        migrationRequestNumber  = sys.argv[13]
        dbccExecutionFromScheduler = sys.argv[14]
        dbccExecutionDate       = sys.argv[15]

        content   = StringIO.StringIO( )
        error     = StringIO.StringIO( )

        print "appsSchemaPassword:" + appsSchemaPassword
        print "instanceUsername:" + instanceUsername
        print "instancePassword:" + instancePassword
        print "instanceIp:" + instanceIp
        print "instancePortNumber:" + instancePortNumber
        print "logFileName:" + logFileName
        print "tri2Directory:" + tri2Directory
        print "isSudoUser:" + isSudoUser
        print "sudoToUser:" + sudoToUser
        print "uploadBaseTargetDir:" + uploadBaseTargetDir
        print "singleQuotes:" + singleQuotes
        print "connectToSudoCmd:" + connectToSudoCmd
        print "migrationRequestNumber:" + migrationRequestNumber
        print "dbccExecutionFromScheduler:" + dbccExecutionFromScheduler
        print "dbccExecutionDate:" + dbccExecutionDate

        ssh = paramiko.SSHClient( )
        ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy( ) )
        ssh.connect( instanceIp, username=instanceUsername, password=instancePassword )
        migLogFile = open( logFileName, "a" )
        def channelCreation(command):
                Channel = ssh.get_transport( ).open_session( )
                Channel.get_pty( )
                Channel.settimeout( 1080 )
                Channel.exec_command( command )
                exit_status = Channel.recv_exit_status( )
                return

        print "Creating temporary directory for executing DBCC..."
        command = "whoami; pwd; . ~/.bash_profile; mkdir -p " + uploadBaseTargetDir
        channelCreation(command)
        print "Created temporary directory for executing DBCC!"

        if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                print "Changing the permission for " + uploadBaseTargetDir + " in temporary folder..."
                command = ". ~/.bash_profile; chmod 777 " + uploadBaseTargetDir
                channelCreation(command)
                print "Changed permission to " + uploadBaseTargetDir + " in temporary folder!"

        # DBCC execution
        if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                print "Inside if, inside sudo user..."
                print "Executing DBCC in target instance..."
                command = "%s 'whoami; cd /home/%s; pwd; . ~/.bash_profile; cd %s; sqlplus apps/%s @$AD_TOP/sql/ADZDDBCC.sql > dbcc-execution-%s.log'" % (
                        connectToSudoCmd, sudoToUser, uploadBaseTargetDir, appsSchemaPassword, dbccExecutionDate)
                channelCreation(command)
                print "Executed DBCC in target instance!"
                print "Inside if, sudo user completed!"
        else:
                print "Inside else, inside normal user..."
                print "Executing DBCC in target instance..."
                command = "pwd;. ~/.bash_profile; cd " + uploadBaseTargetDir + "; sqlplus apps/" + appsSchemaPassword + " @$AD_TOP/sql/ADZDDBCC.sql > dbcc-execution-" + dbccExecutionDate + ".log"
                channelCreation(command)
                print "Executed DBCC in target instance!"
                print "Inside else, normal user completed!"


        print "Copying dbcc-execution-" + dbccExecutionDate + ".log to TRI2 server..."
        if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                remotedir = uploadBaseTargetDir + "/"
        else:
                remotedir = "/home/" + instanceUsername + "/" + uploadBaseTargetDir + "/"
        localdir = tri2Directory + "/"
        if dbccExecutionFromScheduler != "true" and migrationRequestNumber != "null":
                localdir = localdir + "/OnlinePatchingLogs/DBCCExecutionLogs/" + migrationRequestNumber + "/"
        else:
                localdir = localdir + "/OnlinePatchingLogs/DBCCExecutionLogs/"

        print "remotedir final:" + remotedir
        print "localdir final:" + localdir
        sftp = ssh.open_sftp()
        remoteFiles = sftp.listdir(path=remotedir)
        for files in remoteFiles:
                print "files final:" + files
                if fnmatch.fnmatchcase(files, 'dbcc*.log'):
                        sftp.get(remotedir + files, localdir + files)
        print "Copied dbcc-execution-" + dbccExecutionDate + ".log to TRI2 server..."

        print "Deleting dbcc-execution-" + dbccExecutionDate + ".log in target instance..."
        command = "pwd;. ~/.bash_profile; cd " + uploadBaseTargetDir + "; rm -rf dbcc-execution-" + dbccExecutionDate + ".log"
        channelCreation(command)
        print "Deleted dbcc-execution-" + dbccExecutionDate + ".log in target instance!"

finally:
    print "finally..."