import StringIO
import fnmatch
import socket
import sys
import time
import select
import shutil
#from turtle import done

import paramiko
import os

import xml.etree.ElementTree as ET
import zipfile

try:
		#print 'Number of arguments:', len( sys.argv ), ' arguments.'
		#sourceInstancePassword was also getting printed in TRI2 logs so commented the below statement.
		#print 'Argument List:', str( sys.argv )
		
		commandToRun                         = sys.argv[1]
		
		if commandToRun == 'exportFromRepository':
			sourceInstanceName                   = sys.argv[2]
			sourceInstanceUserName               = sys.argv[3]
			sourceInstancePassword               = sys.argv[4]
			sourceInstanceIP                     = sys.argv[5]
			sourceInstancePortNumber             = sys.argv[6]
			sourceInstanceRepository             = sys.argv[7]
			sourceInstanceRepositoryDomain       = sys.argv[8]
			sourceInstanceRepositoryUsername     = sys.argv[9]
			sourceInstanceRepositoryPassword     = sys.argv[10]
			objectType                           = sys.argv[11]
			sourceFolderName                     = sys.argv[12]
			sourceWorkflowName			         = sys.argv[13]
			sourceMappingName			         = sys.argv[14]
			temparoryLocalFolder                 = sys.argv[15]
			envFileCommand						= sys.argv[16]
			sourceInstanceInformaticaExportFolder = sys.argv[17]
			
		if commandToRun == 'copyToTarget':	
			
			sourceInstanceName                   = sys.argv[2]
			sourceInstanceUserName               = sys.argv[3]
			sourceInstancePassword               = sys.argv[4]
			sourceInstanceIP                     = sys.argv[5]
			sourceInstancePortNumber             = sys.argv[6]
			targetInstanceRepositoryDomain    	 = sys.argv[7]
			targetInstanceRepositoryUsername  	 = sys.argv[8]
			targetInstanceRepositoryPassword  	 = sys.argv[9]
			targetInstanceRepository           = sys.argv[10]
			objectType                           = sys.argv[11]
			targetFolderName                     = sys.argv[12]
			targetWorkflowName			         = sys.argv[13]
			targetMappingName			         = sys.argv[14]
			
			temparoryLocalFolderWhileMigration = sys.argv[15]
			logFilePath                        = sys.argv[16]
			migLogFile = ''
			envFileCommand						= sys.argv[17]
			targetInstanceInformaticaImportFolder = sys.argv[18]
			sourceFolderNameForFolderMigration  = sys.argv[19]
			
			
			print targetInstanceRepository
			print targetFolderName
		
		def findstatus(output):
			exit_status = 0;
			if output.find('Failed to execute objectimport') != -1:
				exit_status = 2;
			elif output.find('Failed to execute connect') != -1:
				exit_status = 2;
				
			return exit_status
				
		def createChannelAndExecuteCommand(command):
			try:
				print "createChannelAndExecuteCommand >" + command
				Channel = ssh.get_transport().open_session()
				Channel.get_pty()
				Channel.settimeout(1080)
				stdin,stdout,stderr=ssh.exec_command(command, get_pty=True)
				stdout=stdout.readlines()
				output=""
				for line in stdout:
					output=output+line
				if output!="":
					print output
				else:
					print "There was no output for this command"
				exit_status = findstatus(output)
				#exit_status = Channel.recv_exit_status()
				#exit_status = ssh.recv_exit_status()
				print "createChannelAndExecuteCommand end."
				return exit_status
			except Exception as createChannelAndExecuteCommandException:
				print "Unexpected error while creating channel and executing command :", sys.exc_info()[0]
				#migLogFile.write("Unexpected error while creating channel and executing command:" + str(sys.exc_info()[0]) + "\n")
				exit_status = -1
				return exit_status
				
		try:
			print "Creating ssh connection to target instance..."
			#migLogFile.write("Creating ssh connection to target instance...\n")
			ssh = paramiko.SSHClient( )
			ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy( ) )
			print "Connecting to target instance through password " + sourceInstanceIP + " " + sourceInstanceUserName
			#migLogFile.write("Connecting to target instance through password...\n")
			ssh.connect( sourceInstanceIP, username=sourceInstanceUserName, password=sourceInstancePassword )
			print "Connected to target instance through password"
			#migLogFile.write("Connected to target instance through password...\n")
			exit_status = 0
			print "Created ssh connection to target instance."
			#migLogFile.write("Created ssh connection to target instance.\n")
		except paramiko.AuthenticationException:
			print "Authentication Exception"
			#migLogFile.write("Authentication Exception\n")
			connection_status = -1
			sys.exit(1)
		except Exception as sshConnectionException:
			exit_status = -1
			print "Unexpected error while opening ssh connection:", sys.exc_info()[0]
			#migLogFile.write("Unexpected error while opening ssh connection:" + str(sys.exc_info()[0]) + "\n")
			sys.exit(1)
			
		if commandToRun == 'exportFromRepository':
			print "command : " + commandToRun
			try:	
				if sourceInstanceRepository != None and sourceFolderName != None:
					print "Target Repository Name and Target folder Name are available"
					
					command = "mkdir -p " + sourceInstanceInformaticaExportFolder 
					exit_status = createChannelAndExecuteCommand(command)
					
					commandBeforeImport = envFileCommand + " cd " + sourceInstanceInformaticaExportFolder + ";"
					
					if objectType =="Informatica Folder":
						print "Object Type: " + objectType
						command = commandBeforeImport + "pmrep connect -r " + sourceInstanceRepository + " -d " + sourceInstanceRepositoryDomain + " -n " + sourceInstanceRepositoryUsername + " -x " + sourceInstanceRepositoryPassword
						exit_status = createChannelAndExecuteCommand(command)
						
						command = commandBeforeImport + "pmrep objectexport -f " + sourceFolderName + " -u " + sourceFolderName + ".xml"
						exit_status = createChannelAndExecuteCommand(command)
						
						try:
							print "Opening sftp connection to target instance..."
							#migLogFile.write("Opening sftp connection to target instance...\n")
							command = commandBeforeImport
							exit_status = createChannelAndExecuteCommand(command)
							sftp = ssh.open_sftp()
							print "Opened sftp connection to target instance."
							
							remoteFiles = sftp.listdir(path=sourceInstanceInformaticaExportFolder)
							if len(remoteFiles) != 0:
								for files in remoteFiles:
									print "each file :" + files
						
							print sourceInstanceInformaticaExportFolder + sourceFolderName + ".xml"
							print temparoryLocalFolder + "/" + sourceFolderName + ".xml"
							sftp.get(sourceInstanceInformaticaExportFolder + sourceFolderName + ".xml", temparoryLocalFolder + "/" + sourceFolderName + ".xml")
							#migLogFile.write("Opened sftp connection to target instance.\n")
							print "Folder exported successfully"
							
							command = commandBeforeImport + " rm " + sourceFolderName + ".xml"
							exit_status = createChannelAndExecuteCommand(command)
							
						except Exception as sftpConnectionException:
							exit_status = -1
							#print('An error occurred creating SFTP client: %s: %s' % (e.__class__, e))
							print "Unexpected error while opening sftp connection:",  sys.exc_info()[0]
							#migLogFile.write("Unexpected error while opening sftp connection:" + str(sys.exc_info()[0]) + "\n")
							
					elif objectType =="Informatica Workflow":
						print "Object Type: " + objectType
						command = commandBeforeImport + "pmrep connect -r " + sourceInstanceRepository + " -d " + sourceInstanceRepositoryDomain + " -n " + sourceInstanceRepositoryUsername + " -x " + sourceInstanceRepositoryPassword
						exit_status = createChannelAndExecuteCommand(command)
						
						command = commandBeforeImport + "pmrep objectexport -n " + sourceWorkflowName + " -o Workflow -f " + sourceFolderName + " -m -s -b -r -u " + sourceWorkflowName + ".xml"
						exit_status = createChannelAndExecuteCommand(command)
						
						try:
							print "Opening sftp connection to target instance..."
							#migLogFile.write("Opening sftp connection to target instance...\n")
							command = commandBeforeImport
							exit_status = createChannelAndExecuteCommand(command)
							sftp = ssh.open_sftp()
							print "Opened sftp connection to target instance."
						
							remoteFiles = sftp.listdir(path=sourceInstanceInformaticaExportFolder)
							if len(remoteFiles) != 0:
								for files in remoteFiles:
									print "each file :" + files
						
							print sourceInstanceInformaticaExportFolder + sourceWorkflowName + ".xml"
							print temparoryLocalFolder + "/" + sourceWorkflowName + ".xml"
							sftp.get(sourceInstanceInformaticaExportFolder + sourceWorkflowName + ".xml", temparoryLocalFolder + "/" + sourceWorkflowName + ".xml")
							#migLogFile.write("Opened sftp connection to target instance.\n")
							print "Workflow exported successfully"
							
							command = commandBeforeImport + " rm " + sourceWorkflowName + ".xml"
							exit_status = createChannelAndExecuteCommand(command)
							
						except Exception as sftpConnectionException:
							exit_status = -1
							#print('An error occurred creating SFTP client: %s: %s' % (e.__class__, e))
							print "Unexpected error while opening sftp connection:",  sys.exc_info()[0]
							#migLogFile.write("Unexpected error while opening sftp connection:" + str(sys.exc_info()[0]) + "\n")
							
					elif objectType =="Informatica Mapping":
						print "Object Type: " + objectType
						command = commandBeforeImport + "pmrep connect -r " + sourceInstanceRepository + " -d " + sourceInstanceRepositoryDomain + " -n " + sourceInstanceRepositoryUsername + " -x " + sourceInstanceRepositoryPassword
						exit_status = createChannelAndExecuteCommand(command)
						
						command = commandBeforeImport + "pmrep objectexport -n " + sourceMappingName + " -o Mapping -f " + sourceFolderName + " -m -s -b -r -u " + sourceMappingName + ".xml"
						exit_status = createChannelAndExecuteCommand(command)
						
						try:
							print "Opening sftp connection to target instance..."
							#migLogFile.write("Opening sftp connection to target instance...\n")
							command = commandBeforeImport
							exit_status = createChannelAndExecuteCommand(command)
							sftp = ssh.open_sftp()
							print "Opened sftp connection to target instance."
						
							remoteFiles = sftp.listdir(path=sourceInstanceInformaticaExportFolder)
							if len(remoteFiles) != 0:
								for files in remoteFiles:
									print "each file :" + files
						
							print sourceInstanceInformaticaExportFolder + sourceMappingName + ".xml"
							print temparoryLocalFolder + "/" + sourceMappingName + ".xml"
							sftp.get(sourceInstanceInformaticaExportFolder + sourceMappingName + ".xml", temparoryLocalFolder + "/" + sourceMappingName + ".xml")
							#migLogFile.write("Opened sftp connection to target instance.\n")
							print "Mapping exported successfully"
							
							command = commandBeforeImport + " rm " + sourceMappingName + ".xml"
							exit_status = createChannelAndExecuteCommand(command)
							
						except Exception as sftpConnectionException:
							exit_status = -1
							#print('An error occurred creating SFTP client: %s: %s' % (e.__class__, e))
							print "Unexpected error while opening sftp connection:",  sys.exc_info()[0]
							#migLogFile.write("Unexpected error while opening sftp connection:" + str(sys.exc_info()[0]) + "\n")
					
						if exit_status == 0:
							print "Changed permissions"
							#migLogFile.write("Created folder in target instance to copy object.\n")
					else:
						print "Invalid Object Type"
				else:
					print "Invalid arguments, Please pass Target Repository Name, Target folder Name as parameters"
				
			except Exception as Exception:
				exit_status = -1
				print "Unexpected error while executing command:", sys.exc_info()[0]
				#migLogFile.write("Unexpected error :" + str(sys.exc_info()[0]) + "\n")
				
		elif commandToRun == "copyToTarget":
			print "command : " + commandToRun
			
			command = "mkdir -p " + targetInstanceInformaticaImportFolder 
			exit_status = createChannelAndExecuteCommand(command)
			
			commandBeforeImport = envFileCommand + " cd " + targetInstanceInformaticaImportFolder
			exit_status = createChannelAndExecuteCommand(commandBeforeImport)
			migLogFile = open(logFilePath, "a")
			try:
				if objectType =="Informatica Folder":
					print "Object Type: " + objectType
					try:
						print "Opening sftp connection to target instance..."
						migLogFile.write("Opening sftp connection to target instance...\n")
						sftp = ssh.open_sftp( )
						print "Opened sftp connection to target instance."
						migLogFile.write("Opened sftp connection to target instance.\n")
					except Exception as sftpConnectionException:
						exit_status = -1
						print "Unexpected error while opening sftp connection:",  sys.exc_info()[0]
						migLogFile.write("Unexpected error while opening sftp connection:" + str(sys.exc_info()[0]) + "\n")
						
					try:
						print "Copying object to target instance..."
						migLogFile.write("Copying object to target instance...\n")
						print temparoryLocalFolderWhileMigration + "/" + sourceFolderNameForFolderMigration + ".zip"
						print targetInstanceInformaticaImportFolder + sourceFolderNameForFolderMigration + ".zip"
					
						sftp.put( temparoryLocalFolderWhileMigration + "/" + sourceFolderNameForFolderMigration + ".xml", targetInstanceInformaticaImportFolder + sourceFolderNameForFolderMigration + ".xml")
						sftp.put( temparoryLocalFolderWhileMigration + "/" + sourceFolderNameForFolderMigration + "_Informatica_Control_File.xml", targetInstanceInformaticaImportFolder + sourceFolderNameForFolderMigration + "_Informatica_Control_File.xml")
						
						print "Copied object to target instance."
						migLogFile.write("Copied object to target instance.\n")

						os.remove(temparoryLocalFolderWhileMigration + "/" + sourceFolderNameForFolderMigration + ".xml")
						os.remove(temparoryLocalFolderWhileMigration + "/" + sourceFolderNameForFolderMigration + "_Informatica_Control_File.xml")

						command = commandBeforeImport + "; mv " + sourceFolderNameForFolderMigration + ".xml " + targetFolderName + ".xml;"
						exit_status = createChannelAndExecuteCommand(command)
						
						if exit_status == 0:
							print "Connecting to Informatica Repository..."
							migLogFile.write("Connecting to Informatica Repository...\n")
							command = commandBeforeImport + "; pmrep connect -r " + targetInstanceRepository + " -d " + targetInstanceRepositoryDomain + " -n " + targetInstanceRepositoryUsername + " -x " + targetInstanceRepositoryPassword
							exit_status = createChannelAndExecuteCommand(command)
						
						if exit_status == 0:
							command = commandBeforeImport + ";pmrep createFolder -n " + targetFolderName
							exit_status = createChannelAndExecuteCommand(command)
						
							print "Importing Folder...: " + targetFolderName
							migLogFile.write("Importing Folder...: " + targetFolderName + "\n")
							command = commandBeforeImport + "; pmrep objectimport -i " + targetFolderName + ".xml  -c " + sourceFolderNameForFolderMigration +"_Informatica_Control_File.xml"
							exit_status = createChannelAndExecuteCommand(command)
								
							if exit_status == 0:	
								print "Folder Imported Successfully...\n"
								migLogFile.write("Folder Imported Successfully...\n")
							else:
								print "Folder Import failed...\n"
								migLogFile.write("Folder Import failed...\n")
						else:
							print "Couldn't connect to Target Repository...\n"
							migLogFile.write("Couldn't connect to Target Repository...\n")
						
					except Exception as copyObjectException:
						exit_status = -1
						print "Unexpected error while copying object:", sys.exc_info()[2]
						migLogFile.write("Unexpected error while copying object:" + str(sys.exc_info()[2]) + "\n")
					finally:
						command = commandBeforeImport + "; rm " + targetFolderName + ".xml; rm " + sourceFolderNameForFolderMigration +"_Informatica_Control_File.xml"
						exit_status = createChannelAndExecuteCommand(command)
						
				elif objectType =="Informatica Workflow":
					print "Object Type: " + objectType
					try:
						print "Opening sftp connection to target instance..."
						migLogFile.write("Opening sftp connection to target instance...\n")
						sftp = ssh.open_sftp( )
						print "Opened sftp connection to target instance."
						migLogFile.write("Opened sftp connection to target instance.\n")
					except Exception as sftpConnectionException:
						exit_status = -1
						print "Unexpected error while opening sftp connection:",  sys.exc_info()[0]
						migLogFile.write("Unexpected error while opening sftp connection:" + str(sys.exc_info()[0]) + "\n")
						
					try:
						print "Copying object to target instance..."
						migLogFile.write("Copying object to target instance...\n")
						print temparoryLocalFolderWhileMigration + "/" + targetWorkflowName + ".zip"
						print targetInstanceInformaticaImportFolder + "/" + targetWorkflowName + ".zip"
						
						sftp.put( temparoryLocalFolderWhileMigration + "/" + targetWorkflowName + ".zip", targetInstanceInformaticaImportFolder + targetWorkflowName + ".zip")
						print "Copied object to target instance."
						migLogFile.write("Copied object to target instance.\n")
						
						command = commandBeforeImport + ";unzip " + targetWorkflowName + ".zip; rm " + targetWorkflowName + ".zip;"
						exit_status = createChannelAndExecuteCommand(command)
						
						if exit_status == 0:
							print "Connecting to Informatica Repository..."
							migLogFile.write("Connecting to Informatica Repository...\n")
							command = commandBeforeImport + "; pmrep connect -r " + targetInstanceRepository + " -d " + targetInstanceRepositoryDomain + " -n " + targetInstanceRepositoryUsername + " -x " + targetInstanceRepositoryPassword
							exit_status = createChannelAndExecuteCommand(command)
							
						if exit_status == 0:
							command = commandBeforeImport + ";pmrep createFolder -n " + targetFolderName
							exit_status = createChannelAndExecuteCommand(command)
							
							print "Importing Workflow...: " + targetWorkflowName
							migLogFile.write("Importing Workflow...: " + targetWorkflowName + "\n")
							command = commandBeforeImport + "; pmrep objectimport -i " + targetWorkflowName + ".xml  -c " + targetWorkflowName +"_Informatica_Control_File.xml"
							exit_status = createChannelAndExecuteCommand(command)
							
							if exit_status == 0:
								print "Workflow Imported Successfully...\n"
								migLogFile.write("Workflow Imported Successfully...\n")
							else:
								print "Workflow Import Failed...\n"
								migLogFile.write("Workflow Import Failed...\n")
						else:
							print "Couldn't connect to Target Repository...\n"
							migLogFile.write("Couldn't connect to Target Repository...\n")
						
					except Exception as copyObjectException:
						exit_status = -1
						print "Unexpected error while copying object:", sys.exc_info()[2]
						migLogFile.write("Unexpected error while copying object:" + str(sys.exc_info()[2]) + "\n")
					finally:
						command = commandBeforeImport + "; rm " + targetWorkflowName + ".xml; rm " + targetWorkflowName +"_Informatica_Control_File.xml"
						exit_status = createChannelAndExecuteCommand(command)

				elif objectType =="Informatica Mapping":
					print "Object Type: " + objectType
					try:
						print "Opening sftp connection to target instance..."
						migLogFile.write("Opening sftp connection to target instance...\n")
						sftp = ssh.open_sftp( )
						print "Opened sftp connection to target instance."
						migLogFile.write("Opened sftp connection to target instance.\n")
					except Exception as sftpConnectionException:
						exit_status = -1
						print "Unexpected error while opening sftp connection:",  sys.exc_info()[0]
						migLogFile.write("Unexpected error while opening sftp connection:" + str(sys.exc_info()[0]) + "\n")
						
					try:
						print "Copying object to target instance..."
						migLogFile.write("Copying object to target instance...\n")
						print temparoryLocalFolderWhileMigration + "/" + targetMappingName + ".zip"
						print targetInstanceInformaticaImportFolder + "/" + targetMappingName + ".zip"
						
						sftp.put( temparoryLocalFolderWhileMigration + "/" + targetMappingName + ".zip", targetInstanceInformaticaImportFolder + targetMappingName + ".zip")
						print "Copied object to target instance."
						migLogFile.write("Copied object to target instance.\n")
						
						command = commandBeforeImport + ";unzip " + targetMappingName + ".zip; rm " + targetMappingName + ".zip;"
						exit_status = createChannelAndExecuteCommand(command)
						
						if exit_status == 0:
							print "Connecting to Informatica Repository..."
							migLogFile.write("Connecting to Informatica Repository...\n")
							command = commandBeforeImport + "; pmrep connect -r " + targetInstanceRepository + " -d " + targetInstanceRepositoryDomain + " -n " + targetInstanceRepositoryUsername + " -x " + targetInstanceRepositoryPassword
							exit_status = createChannelAndExecuteCommand(command)
							
						if exit_status == 0:
							command = commandBeforeImport + ";pmrep createFolder -n " + targetFolderName
							exit_status = createChannelAndExecuteCommand(command)
							
							print "Importing Mapping...: " + targetMappingName
							migLogFile.write("Importing Mapping...: " + targetMappingName + "\n")
							command = commandBeforeImport + "; pmrep objectimport -i " + targetMappingName + ".xml  -c " + targetMappingName +"_Informatica_Control_File.xml"
							exit_status = createChannelAndExecuteCommand(command)
						
							if exit_status == 0:
								print "Mapping Imported Successfully...\n"
								migLogFile.write("Mapping Imported Successfully...\n")
							else:
								print "Mapping Import Failed...\n"
								migLogFile.write("Mapping Import Failed...\n")
						else:
							print "Couldn't connect to Target Repository...\n"
							migLogFile.write("Couldn't connect to Target Repository...\n")
						
					except Exception as copyObjectException:
						exit_status = -1
						print "Unexpected error while copying object:", sys.exc_info()[2]
						migLogFile.write("Unexpected error while copying object:" + str(sys.exc_info()[2]) + "\n")
					finally:
						command = commandBeforeImport + "; rm " + targetMappingName + ".xml; rm " + targetMappingName +"_Informatica_Control_File.xml"
						exit_status = createChannelAndExecuteCommand(command)

				else:
					print "Unable to create folder in target instance to copy object."
					migLogFile.write("Unable to create folder in target instance to copy object.\n")
				
			except Exception as createFolderException:
				exit_status = -1
				print "Unexpected error while creating folder:", sys.exc_info()[0]
				migLogFile.write("Unexpected error while creating folder:" + str(sys.exc_info()[0]) + "\n")
	
except Exception as Exception:
		exit_status = -1
		print "Unexpected error :", sys.exc_info()[0]
		if commandToRun == "copyToTarget":
			migLogFile.write("Unexpected error :" + str(sys.exc_info()[0]) + "\n")