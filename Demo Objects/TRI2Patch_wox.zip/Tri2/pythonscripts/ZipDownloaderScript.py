import StringIO
import fnmatch
import os
import paramiko
import select
import shutil
import socket
import sys
import time
import zipfile
try:
    print 'Number of arguments:', len(sys.argv), 'arguments.'
    #destinationPassword was also getting printed in TRI2 logs so commented the below statement.
    #print 'Argument List:', str(sys.argv)

    AbsolutePath     = sys.argv[1]
    AbsolutePath = AbsolutePath+"/"
    gpsUploadToHere  = sys.argv[2]
    zipName          = sys.argv[3]
    print "AbsolutePath:" + AbsolutePath + "gpsUploadToHere:" + gpsUploadToHere + "zipName:" + zipName
    zipPath = gpsUploadToHere+"/"+ zipName


    def get_all_file_paths(directory):
        # initializing empty file paths list
        file_paths = []

        # crawling through directory and subdirectories
        for root, directories, files in os.walk(directory):
            for filename in files:
                # join the two strings in order to form the full filepath.
                filepath = os.path.join(root, filename)
                file_paths.append(filepath)

        # returning all file paths
        return file_paths



        # calling function to get all file paths in the directory


    file_paths = get_all_file_paths(AbsolutePath)

    # printing the list of all files to be zipped
    print('Following files will be zipped:')
    for file_name in file_paths:
        print("file_name inside file_paths::" + file_name)


    def zip_files(src, dst, arcname=None):
        print "inside method"
        zip_ = zipfile.ZipFile(dst, 'w')

        print src, dst
        for i in range(len(src)):
            if arcname is None:
                zip_.write(src[i], os.path.basename(src[i]), compress_type=zipfile.ZIP_DEFLATED)
            else:
                zip_.write(src[i], arcname[i], compress_type=zipfile.ZIP_DEFLATED)

        zip_.close()


    zip_files(file_paths, zipPath)

except Exception as e:
    print "Migration Exception:"
    print e

finally:
    print "finally2block"
    sys.exit(1)
