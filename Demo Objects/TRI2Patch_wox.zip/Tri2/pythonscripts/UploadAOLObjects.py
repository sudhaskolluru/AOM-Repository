import StringIO
import fnmatch
import socket
import sys
import time
import select
import shutil
#from turtle import done

import paramiko
import os

try:
        print 'Number of arguments:', len( sys.argv ), ' arguments.'
        #destinationPassword was also getting printed in TRI2 logs so commented the below statement.
        #print 'Argument List:', str( sys.argv )
        actionToBePerformed = sys.argv[1]
        destinationIP       = sys.argv[2]
        destinationuserName = sys.argv[3]
        destinationPassword = sys.argv[4]
        connectToSudoCmd    = sys.argv[5]
        sudoToUser          = sys.argv[6]
        tri2dir             = sys.argv[7]
        issudoUser          = sys.argv[8]
        uploadBaseTargetDir = sys.argv[9]
        migrationRequestNumber  = sys.argv[10]
        migObjectSvnPath        = sys.argv[11]
        targetEnvFileCommand    = sys.argv[12]
        copyToBothFileSystems   = sys.argv[13]
        copyToPatchFileSystem   = sys.argv[14]
        patchFileSystemEnvFile  = sys.argv[15]
        keyFilePath             = sys.argv[16]
        content   = StringIO.StringIO( )
        error     = StringIO.StringIO( )

        print "actionToBePerformed:" + actionToBePerformed
        print "destinationIP:" + destinationIP
        print "destinationuserName:" + destinationuserName
        #print "destinationPassword:" + destinationPassword
        print "connectToSudoCmd:" + connectToSudoCmd
        print "sudoToUser:" + sudoToUser
        print "tri2dir:" + tri2dir
        print "issudoUser:" + issudoUser
        print "uploadBaseTargetDir:" + uploadBaseTargetDir
        print "migrationRequestNumber:" + migrationRequestNumber
        print "migObjectSvnPath:" + migObjectSvnPath
        print "targetEnvFileCommand:" + targetEnvFileCommand
        print "copyToBothFileSystems:" + copyToBothFileSystems
        print "copyToPatchFileSystem:" + copyToPatchFileSystem
        print "patchFileSystemEnvFile:" + patchFileSystemEnvFile
        print "keyFilePath " + keyFilePath
        ssh = paramiko.SSHClient( )
        ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy( ) )
        if destinationPassword == "null":
            print "Connecting to target instance  through keyFile"
            private_key = os.path.expanduser(keyFilePath)
            print private_key
            ssh.connect(destinationIP, username=destinationuserName, key_filename=private_key)
            print "Connected to target instance  through keyFile"
        else:
            print "Connecting to target instance through password"
            ssh.connect(destinationIP, username=destinationuserName, password=destinationPassword)
            print "Connected to target instance  through password"


        def channelCreation(command):
                Channel = ssh.get_transport( ).open_session( )
                Channel.get_pty( )
                Channel.settimeout( 1080 )
                Channel.exec_command( command )
                exit_status = Channel.recv_exit_status( )
                return

        if patchFileSystemEnvFile == "null":
                patchFileSystemEnvFile = ""

        print "actionToBePerformed:" + actionToBePerformed
        if actionToBePerformed == "validateSudoUserDetails":
                print "validateSudoUserDetails block!"
                command = "%s 'whoami;cd /tmp && pwd && echo Validated successfully > validateSudoUser.log 2>&1'" % (
                connectToSudoCmd)
                channelCreation(command)

                remotedir = "/tmp/"
                localdir = tri2dir + "/pythonscripts/"
                print "remotedir final:" + remotedir
                print "localdir final:" + localdir
                sftp = ssh.open_sftp()
                remoteFiles = sftp.listdir(path=remotedir)
                for files in remoteFiles:
                    #print "files final:" + files
                    if fnmatch.fnmatchcase(files, 'validateSudoUser.log'):
                        sftp.get(remotedir + files, localdir + files)
        elif actionToBePerformed == "OAFObjectsMigration":
                print "***************OAFObjectsMigration block....start***************"
                try:
                        try:

                                print "Creating OAFObjectsMigrationFolder in target instance..."
                                command = " pwd; whoami; mkdir -p '" + uploadBaseTargetDir + "/OAFObjectsMigration/" + migrationRequestNumber + "'"
                                channelCreation(command)
                                print "OAFObjectsMigrationFolder created successfully."

                                print "Copying " + migrationRequestNumber + " migration OAF related files to target instance..."
                                sftp = ssh.open_sftp()
                                print sftp
                                sftp.put(migObjectSvnPath + "/OAFObjectsMigration/" + migrationRequestNumber + "/All_OAF_Objects.zip",
                                         uploadBaseTargetDir + "/OAFObjectsMigration/" + migrationRequestNumber + "/All_OAF_Objects.zip")
                                sftp.put(migObjectSvnPath + "/OAFObjectsMigration/" + migrationRequestNumber + "/OAFObjectsMigrationScript.sh",
                                         uploadBaseTargetDir + "/OAFObjectsMigration/" + migrationRequestNumber + "/OAFObjectsMigrationScript.sh")
                                print "Copied all " + migrationRequestNumber + " migration OAF related files to target instance successfully."

                                print "issudoUser:" + issudoUser
                                if  issudoUser == "Yes":
                                        command = " pwd; whoami; chmod 777 '" + uploadBaseTargetDir + "/OAFObjectsMigration/" + migrationRequestNumber + "'"
                                        channelCreation(command)
                                        print "Changed permission to " + migrationRequestNumber + " in temporary folder."

                                if copyToBothFileSystems == "true":
                                        # Copying object to both Run and Patch file systems
                                        print "Copying object to both Run and Patch file systems"
                                        print "*********************Migrating OAF objects to Run File System*********************"
                                        print "Extracting OAF zip file in target instance and executing OAFObjectsMigrationScript.sh for OAF objects migration in target instance..."
                                        if issudoUser == "Yes":
                                            command = " %s ' %s pwd; whoami; cd %s/OAFObjectsMigration/%s; unzip -o All_OAF_Objects.zip -d All_OAF_Objects; sh OAFObjectsMigrationScript.sh'" % (
                                                connectToSudoCmd, targetEnvFileCommand, uploadBaseTargetDir, migrationRequestNumber)
                                            channelCreation(command)
                                        else:
                                                command = targetEnvFileCommand + " pwd; whoami; cd " + uploadBaseTargetDir + "/OAFObjectsMigration/" + migrationRequestNumber + "; unzip -o All_OAF_Objects.zip -d All_OAF_Objects; sh OAFObjectsMigrationScript.sh"
                                                channelCreation(command)
                                        print "Executed OAFObjectsMigrationScript.sh successfully in target instance."
                                        print "*********************Completed migration of OAF objects to Run File System*********************"

                                        print "*********************Migrating OAF objects to Patch File System*********************"
                                        print "Extracting OAF zip file in target instance and executing OAFObjectsMigrationScript.sh for OAF objects migration in target instance..."
                                        if issudoUser == "Yes":
                                                command = " %s ' %s pwd; whoami; %s; cd %s/OAFObjectsMigration/%s; sh OAFObjectsMigrationScript.sh'" % (
                                                        connectToSudoCmd,targetEnvFileCommand,  patchFileSystemEnvFile, uploadBaseTargetDir,
                                                        migrationRequestNumber)
                                                channelCreation(command)
                                        else:
                                                command = targetEnvFileCommand + " pwd; whoami; " + patchFileSystemEnvFile + "; cd " + uploadBaseTargetDir + "/OAFObjectsMigration/" + migrationRequestNumber + "; sh OAFObjectsMigrationScript.sh"
                                                channelCreation(command)
                                        print "Executed OAFObjectsMigrationScript.sh successfully in target instance."
                                        print "*********************Completed migration of OAF objects to Patch File System*********************"

                                elif copyToPatchFileSystem == "true":
                                        # Copying object to Patch file system
                                        print "Copying object to Patch file system"
                                        print "*********************Migrating OAF objects to Patch File System*********************"
                                        print "Extracting OAF zip file in target instance and executing OAFObjectsMigrationScript.sh for OAF objects migration in target instance..."
                                        if issudoUser == "Yes":
                                                command = " %s ' %s pwd; whoami; %s; cd %s/OAFObjectsMigration/%s; unzip -o All_OAF_Objects.zip -d All_OAF_Objects; sh OAFObjectsMigrationScript.sh'" % (
                                                        connectToSudoCmd, targetEnvFileCommand, patchFileSystemEnvFile, uploadBaseTargetDir,
                                                        migrationRequestNumber)
                                                channelCreation(command)
                                        else:
                                                command = targetEnvFileCommand + " pwd; whoami; " + patchFileSystemEnvFile + "; cd " + uploadBaseTargetDir + "/OAFObjectsMigration/" + migrationRequestNumber + "; unzip -o All_OAF_Objects.zip -d All_OAF_Objects; sh OAFObjectsMigrationScript.sh"
                                                channelCreation(command)
                                        print "Executed OAFObjectsMigrationScript.sh successfully in target instance."
                                        print "*********************Completed migration of OAF objects to Patch File System*********************"
                                else:
                                        print "Copying object to normal file system"
                                        # Copying object to normal file system
                                        print "Extracting OAF zip file in target instance and executing OAFObjectsMigrationScript.sh for OAF objects migration in target instance..."
                                        if issudoUser == "Yes":
                                                command = " %s ' pwd; whoami; %s cd %s/OAFObjectsMigration/%s; unzip -o All_OAF_Objects.zip -d All_OAF_Objects; sh OAFObjectsMigrationScript.sh'" % (
                                                        connectToSudoCmd, targetEnvFileCommand, uploadBaseTargetDir,
                                                        migrationRequestNumber)
                                                channelCreation(command)
                                        else:
                                                command = " pwd; whoami; " + targetEnvFileCommand + " cd " + uploadBaseTargetDir + "/OAFObjectsMigration/" + migrationRequestNumber + "; unzip -o All_OAF_Objects.zip -d All_OAF_Objects; sh OAFObjectsMigrationScript.sh"
                                                channelCreation(command)
                                        print "Executed OAFObjectsMigrationScript.sh successfully in target instance."
                        except Exception as migrationException:
                                print "migrationException:" + str(migrationException)
                        finally:
                                print "oafObjectsMigration block finally"

                                try:
                                        print "Copy OAF objects migration logs to TRI2 Server from target instance..."
                                        remotedir = uploadBaseTargetDir + "/OAFObjectsMigration/" + migrationRequestNumber + "/OAFObjectsMigrationLogs/"
                                        localdir = migObjectSvnPath + "/OAFObjectsMigration/" + migrationRequestNumber + "/OAFObjectsMigrationLogs/"
                                        print "remotedir:" + remotedir
                                        print "localdir:" + localdir
                                        sftp = ssh.open_sftp()
                                        remoteFiles = sftp.listdir(path=remotedir)
                                        for files in remoteFiles:
                                                if fnmatch.fnmatch(files, '*.log'):
                                                        sftp.get(remotedir + files, localdir + files)
                                        print "Copied OAF objects migration logs to TRI2 Server."

                                except Exception as migrationException:
                                        print "migrationException:" + str(migrationException)
                                finally:
                                        print "Changing the permission for OAFObjectsMigrationLogs, All_OAF_Objects folders..."
                                        if issudoUser == "Yes":
                                                print "Permission part Sudo User!"
                                                command = " %s ' %s cd %s/OAFObjectsMigration/%s; whoami; pwd; chmod 777 -R OAFObjectsMigrationLogs'" % (
                                                        connectToSudoCmd, targetEnvFileCommand, uploadBaseTargetDir, migrationRequestNumber)
                                                channelCreation(command)
                                                command1 = " %s ' %s cd %s/OAFObjectsMigration/%s; whoami; pwd; chmod 777 -R All_OAF_Objects'" % (
                                                connectToSudoCmd, targetEnvFileCommand, uploadBaseTargetDir, migrationRequestNumber)
                                                channelCreation(command1)

                                        print "Deleting OAFObjectsMigrationFolder in target instance..."
                                        command = "cd " + uploadBaseTargetDir + "/OAFObjectsMigration/; pwd; rm -rf " + migrationRequestNumber
                                        channelCreation(command)
                                        print "Deleted OAFObjectsMigrationFolder successfully in target instance."

                except Exception as migrationException:
                        print "migrationException:" + str(migrationException)
                print "***************oafObjectsMigration block....end!***************"

finally:
    print "finally..."