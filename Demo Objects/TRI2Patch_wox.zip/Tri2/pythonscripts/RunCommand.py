import StringIO
import fnmatch
import socket
import sys
import time
import select
import shutil


import paramiko
import os

try:
    print 'Number of arguments:', len(sys.argv), ' arguments.'
    print 'Argument List:', str(sys.argv)
    instanceIP = sys.argv[1]
    userName = sys.argv[2]
    decryptedPassword = sys.argv[3]
    connectToSudoCmd = sys.argv[4]
    envFileCommand = sys.argv[5]
    isSudoUser = sys.argv[6]
    pythonTarget = sys.argv[7]
    command = sys.argv[8]
    sudoUserName = sys.argv[9]
    tri2Dir = sys.argv[10]
    uploadBaseTarget = sys.argv[11]
    keyFilePath = sys.argv[12]
    content = StringIO.StringIO()
    error = StringIO.StringIO()

    if connectToSudoCmd == "null":
        connectToSudoCmd = ""

    if envFileCommand == "null":
        envFileCommand = ""

    print "instanceIP:" + instanceIP
    print "userName:" + userName
    # print "decryptedPassword:" + decryptedPassword
    print "connectToSudoCmd:" + connectToSudoCmd
    print "envFileCommand:" + envFileCommand
    print "isSudoUser:" + isSudoUser
    print "pythonTarget:" + pythonTarget
    print "command:" + command
    print "sudoUserName:" + sudoUserName
    print "tri2Dir:" + tri2Dir
    print "uploadBaseTarget:" + uploadBaseTarget
    print "key file path: " + keyFilePath
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    if decryptedPassword == "null":
        print "Connecting to target instance  through keyFile"
        private_key = os.path.expanduser(keyFilePath)
        print private_key
        ssh.connect(instanceIP, username=userName, key_filename=private_key)
        print "Connected to target instance  through keyFile"
    else:
        print "Connecting to target instance through password"
        ssh.connect(instanceIP, username=userName, password=decryptedPassword)
        print "Connected to target instance  through password"


    def channelCreation(command):
        try:
            print "command:" + command
            Channel = ssh.get_transport().open_session()
            Channel.get_pty()
            Channel.settimeout(1080)
            Channel.exec_command(command)
            exit_status = Channel.recv_exit_status()
            print "channelCreation  end."
            return exit_status

        except Exception as createChannelAndExecuteCommandException:
            print "Unexpected error while creating channel and executing command :", sys.exc_info()[0]
            exit_status = -1
            return exit_status

    def copyLogFromRemoteToSource(remotedir , localdir, sftp):
        try:
            print "remotedir:" + remotedir
            print "localdir:" + localdir
            remoteFiles = sftp.listdir(path=remotedir)
            for files in remoteFiles:
                if fnmatch.fnmatchcase(files, 'RunCommandLog.log'):
                    sftp.get(remotedir + files, localdir + files)
            print "Closing sftp connection"
            sftp.close();

        except Exception as createChannelAndExecuteCommandException:
            print "Unable to copied the log file from remote instance to local instance", sys.exc_info()[0]
            exit_status = -1
            return exit_status

    print "pythonTarget:" + pythonTarget
    if (pythonTarget == "EXECUTE_COMMAND"):
        print "Inside EXECUTE_COMMAND"
        if isSudoUser != "No":
            print "Inside sudo"
            try:
                command1 = "mkdir -p " + uploadBaseTarget
                exit_status = channelCreation(command1)
                if exit_status == 0:
                    command2 = " %s ' cd /home/%s; %s %s'  > %s/RunCommandLog.log" % (
                        connectToSudoCmd, sudoUserName, envFileCommand , command, uploadBaseTarget)
                    exit_status1 = channelCreation(command2)
                    copyLogFromRemoteToSource(uploadBaseTarget + "/", tri2Dir + "/Temp/", ssh.open_sftp())
                else:
                    print "Unable to create a RunCommandLog.log file in target instance"
            except Exception as createChannelAndExecuteCommandException:
                print "Unexpected error while creating channel and executing command :", sys.exc_info()[0]
        else:
            print "Inside Else"
            print "envFileCommand:" + envFileCommand
            print "command:" + command
            command = "{ " + envFileCommand + command + " } > " + uploadBaseTarget + "/RunCommandLog.log 2>&1"
            channelCreation(command)
            print "Inside Else...after"
            copyLogFromRemoteToSource("/home/" + userName + "/" + uploadBaseTarget + "/",tri2Dir + "/Temp/", ssh.open_sftp())

finally:
    print "finally... block in runcommand.py file"
    print "Closing ssh connection"
    ssh.close()
    sys.exit(0)