import StringIO
import fnmatch
import socket
import sys
import time
import select
import shutil
from turtle import done

import paramiko
import os

try:
        print 'Number of arguments:', len( sys.argv ), ' arguments.'
        #destinationPassword was also getting printed in TRI2 logs so commented the below statement.
        #print 'Argument List:', str( sys.argv )
        appsSchemaPassword      = sys.argv[1]
        systemUserPassword      = sys.argv[2]
        weblogicServerPassword  = sys.argv[3]
        instanceUsername        = sys.argv[4]
        instancePassword        = sys.argv[5]
        instanceIp              = sys.argv[6]
        instancePortNumber      = sys.argv[7]
        logFileName             = sys.argv[8]
        tri2Directory           = sys.argv[9]
        adopPhase               = sys.argv[10]
        isSudoUser              = sys.argv[11]
        sudoToUser              = sys.argv[12]
        uploadBaseTargetDir     = sys.argv[13]
        singleQuotes            = sys.argv[14]
        connectToSudoCmd        = sys.argv[15]
        migrationRequestNumber  = sys.argv[16]
        adopPhaseExecutionFromScheduler = sys.argv[17]

        content   = StringIO.StringIO( )
        error     = StringIO.StringIO( )

        #print "appsSchemaPassword:" + appsSchemaPassword
        #print "systemUserPassword:" + systemUserPassword
        #print "weblogicServerPassword:" + weblogicServerPassword
        print "instanceUsername:" + instanceUsername
        #print "instancePassword:" + instancePassword
        print "instanceIp:" + instanceIp
        print "instancePortNumber:" + instancePortNumber
        print "logFileName:" + logFileName
        print "tri2Directory:" + tri2Directory
        print "adopPhase:" + adopPhase
        print "isSudoUser:" + isSudoUser
        print "sudoToUser:" + sudoToUser
        print "uploadBaseTargetDir:" + uploadBaseTargetDir
        print "singleQuotes:" + singleQuotes
        print "connectToSudoCmd:" + connectToSudoCmd
        print "migrationRequestNumber:" + migrationRequestNumber
        print "adopPhaseExecutionFromScheduler:" + adopPhaseExecutionFromScheduler

        ssh = paramiko.SSHClient( )
        ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy( ) )
        ssh.connect( instanceIp, username=instanceUsername, password=instancePassword )
        migLogFile = open( logFileName, "a" )
        def channelCreation(command):
                Channel = ssh.get_transport( ).open_session( )
                Channel.get_pty( )
                Channel.settimeout( 1080 )
                Channel.exec_command( command )
                exit_status = Channel.recv_exit_status( )
                return

        print "Creating temporary directory for executing adop cycle step..."
        command = "whoami; pwd; . ~/.bash_profile; mkdir -p " + uploadBaseTargetDir
        channelCreation(command)
        print "Created temporary directory for executing adop cycle step!"

        if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                print "Changing the permission for " + uploadBaseTargetDir + " in temporary folder..."
                command = ". ~/.bash_profile; chmod 777 " + uploadBaseTargetDir
                channelCreation(command)
                print "Changed permission to " + uploadBaseTargetDir + " in temporary folder!"

        # adop status phase execution
        if adopPhase == "status":
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                        print "Inside status, inside sudo user..."
                        print "Executing adop -status command in target instance..."
                        command = "%s 'whoami; cd /home/%s; pwd; . ~/.bash_profile; cd %s; { echo %s; } | adop -status 1> adop-status.log 2> adop-error.log'" % (
                        connectToSudoCmd, sudoToUser, uploadBaseTargetDir, appsSchemaPassword)
                        channelCreation(command)
                        print "Executed adop -status command in target instance!"
                        print "Inside status, sudo user completed!"
                else:
                        print "Inside status, inside normal user..."
                        print "Executing adop -status command in target instance..."
                        command = "pwd;. ~/.bash_profile; cd " + uploadBaseTargetDir + "; { echo " + appsSchemaPassword + "; } | adop -status 1> adop-status.log 2> adop-error.log"
                        channelCreation(command)
                        print "Executed adop -status command in target instance!"
                        print "Inside status, normal user completed!"
        else:
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                        print "Inside else, inside sudo user..."
                        print "Executing adop " + adopPhase + " command in target instance..."
                        command = "%s 'whoami; cd /home/%s; pwd; . ~/.bash_profile; cd %s; { echo %s; echo %s; echo %s;} | adop phase=%s 1> adop-%s.log 2> adop-error.log'" % (
                                connectToSudoCmd, sudoToUser, uploadBaseTargetDir, appsSchemaPassword,
                                systemUserPassword, weblogicServerPassword, adopPhase, adopPhase)
                        channelCreation(command)
                        print "Executed adop " + adopPhase + " command in target instance!"
                        print "Inside else, sudo user completed!"
                else:
                        print "Inside else, inside normal user..."
                        print "Executing adop -status command in target instance..."
                        command = "pwd;. ~/.bash_profile; cd " + uploadBaseTargetDir + "; { echo " + appsSchemaPassword + "; echo " + systemUserPassword + "; echo " + weblogicServerPassword + "; } | adop phase=" + adopPhase + " 1> adop-" + adopPhase + ".log 2> adop-error.log"
                        channelCreation(command)
                        print "Executed adop -status command in target instance!"
                        print "Inside else, normal user completed!"


        print "Copying adop-" + adopPhase + ".log, adop-error.log to TRI2 server..."
        if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                remotedir = uploadBaseTargetDir + "/"
        else:
                remotedir = "/home/" + instanceUsername + "/" + uploadBaseTargetDir + "/"
        localdir = tri2Directory + "/"
        if adopPhaseExecutionFromScheduler != "true" and migrationRequestNumber != "null":
                localdir = localdir + "/OnlinePatchingLogs/OnlinePatchingMigrations/" + migrationRequestNumber + "/"
        else:
                localdir = localdir + "/OnlinePatchingLogs/OnlinePatchingCycleStepLogs/"

        print "remotedir final:" + remotedir
        print "localdir final:" + localdir
        sftp = ssh.open_sftp()
        remoteFiles = sftp.listdir(path=remotedir)
        for files in remoteFiles:
                print "files final:" + files
                if fnmatch.fnmatch(files, 'adop*.log'):
                        sftp.get(remotedir + files, localdir + files)
        print "Copied adop-" + adopPhase + ".log, adop-error.log to TRI2 server..."

        print "Deleting adop-" + adopPhase + ".log, adop-error.log in target instance..."
        command = "pwd;. ~/.bash_profile; cd " + uploadBaseTargetDir + "; rm -rf adop*.log"
        channelCreation(command)
        print "Deleted adop-" + adopPhase + ".log, adop-error.log in target instance!"

finally:
    print "finally..."
