import StringIO
import fnmatch
import socket
import sys
import time
import select
import shutil
#from turtle import done

import paramiko
import os

try:

        print 'Number of arguments:', len( sys.argv ), ' arguments.'
        #destinationPassword was also getting printed in TRI2 logs so commented the below statement.
        #print 'Argument List:', str( sys.argv )
        destinationuserName      = sys.argv[1]
        destinationPassword      = sys.argv[2]
        destinationIP            = sys.argv[3]
        destinationPortNumber    = sys.argv[4]
        LogFileName              = sys.argv[5]
        objectDir                = sys.argv[6]
        ldtLocation              = sys.argv[7]
        objectName               = sys.argv[8]
        objectType               = sys.argv[9]
        appsDetails              = sys.argv[10]
        applicationShortName     = sys.argv[11]
        lctName                  = sys.argv[12]
        dbInstanceIP             = sys.argv[13]
        dbInstancePort           = sys.argv[14]
        dbInstanceSID            = sys.argv[15]
        schemaName               = sys.argv[16]
        schemaPassword           = sys.argv[17]
        aolLogFileandLDTDownloadPath = sys.argv[18]
        envFileCommand     = sys.argv[19]
        isSudoUser         = sys.argv[20]
        sudoToUser         = sys.argv[21]
        connectToSudoCmd   = sys.argv[22]
        uploadBaseTarget   = sys.argv[23]
        lobCode            = sys.argv[24]
        lobType            = sys.argv[25]
        xdoFileType        = sys.argv[26]
        language           = sys.argv[27]
        customMode         = sys.argv[28]
        uploadMode         = sys.argv[29]
        workflowUploadMode = sys.argv[30]
        copyToPatchFileSystem  = sys.argv[31]
        patchFileSystemEnvFile = sys.argv[32]
        territory              = sys.argv[33]
        keyFilePath			= sys.argv[34]
        nlsLangSettingValue = sys.argv[35]
        nlsLangRevertSetting = ""
        
        content   = StringIO.StringIO( )
        error     = StringIO.StringIO( )
        connection_status = 0
        exit_status = -1
        ssh = None
        sftp = None
        print "destinationuserName:" + destinationuserName
        #print "destinationPassword:" + destinationPassword
        print "destinationIP:" + destinationIP
        print "destinationPortNumber:" + destinationPortNumber
        print "LogFileName:" + LogFileName
        print "objectDir:" + objectDir
        print "ldtLocation:" + ldtLocation
        print "objectName:" + objectName
        print "objectType:" + objectType
        #print "appsDetails:" + appsDetails
        print "applicationShortName:" + applicationShortName
        print "lctName:" + lctName
        print "dbInstanceIP:" + dbInstanceIP
        print "dbInstancePort:" + dbInstancePort
        print "dbInstanceSID:" + dbInstanceSID
        print "schemaName:" + schemaName
        #print "schemaPassword:" + schemaPassword
        print "aolLogFileandLDTDownloadPath:" + aolLogFileandLDTDownloadPath
        print "envFileCommand:" + envFileCommand
        print "isSudoUser:" + isSudoUser
        print "sudoToUser:" + sudoToUser
        print "connectToSudoCmd:" + connectToSudoCmd
        print "uploadBaseTarget:" + uploadBaseTarget
        print "lobCode:" + lobCode
        print "lobType:" + lobType
        print "xdoFileType:" + xdoFileType
        print "language:" + language
        print "customMode:" + customMode
        print "uploadMode:" + uploadMode
        print "workflowUploadMode:" + workflowUploadMode
        print "copyToPatchFileSystem:" + copyToPatchFileSystem
        print "patchFileSystemEnvFile:" + patchFileSystemEnvFile
        print "territory :" + territory
        print "keyFilePath : " + keyFilePath

        if nlsLangSettingValue != "":
            nlsLangRevertSetting = "export NLS_LANG=\"AMERICAN_AMERICA.UTF8\""

        print("nlsLangRevertSetting::"+nlsLangRevertSetting)

        print "Opening migLogFile to write logs..."
        migLogFile = open(LogFileName, "a")
        print "Opened migLogFile to write logs."
        print "exit_status : ", exit_status

        def createChannelAndExecuteCommand(command):
            try:
                print "createChannelAndExecuteCommand...."
                Channel = ssh.get_transport().open_session()
                Channel.get_pty()
                Channel.settimeout(1080)
                Channel.exec_command(command)
                exit_status = Channel.recv_exit_status()
                print "createChannelAndExecuteCommand end."
                return exit_status
            except Exception as createChannelAndExecuteCommandException:
                print "Unexpected error while creating channel and executing command :", sys.exc_info()[0]
                migLogFile.write("Unexpected error while creating channel and executing command:" + str(sys.exc_info()[0]) + "\n")
                exit_status = -1
                return exit_status

        try:
            print "Creating ssh connection to target instance..."
            migLogFile.write("Creating ssh connection to target instance...\n")
            ssh = paramiko.SSHClient( )
            ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy( ) )
            if destinationPassword == "null":
                print "Connecting to target instance through keyFilePath"
                migLogFile.write("Connecting to target instance through keyFilePath...\n")
                private_key = os.path.expanduser(keyFilePath)
                print private_key
                ssh.connect(destinationIP, username=destinationuserName, key_filename=private_key)
                print "Connected to target instance through keyFilePath"
                migLogFile.write("Connected to target instance through keyFilePath...\n")
            else:
                print "Connecting to target instance through password"
                migLogFile.write("Connecting to target instance through password...\n")
                ssh.connect( destinationIP, username=destinationuserName, password=destinationPassword )
                print "Connected to target instance through password"
                migLogFile.write("Connected to target instance through password...\n")
                exit_status = 0
                print "Created ssh connection to target instance."
                migLogFile.write("Created ssh connection to target instance.\n")
        except paramiko.AuthenticationException:
            print "Authentication Exception"
            migLogFile.write("Authentication Exception\n")
            connection_status = -1
            sys.exit(1)
        except Exception as sshConnectionException:
            exit_status = -1
            print "Unexpected error while opening ssh connection:", sys.exc_info()[0]
            migLogFile.write("Unexpected error while opening ssh connection:" + str(sys.exc_info()[0]) + "\n")
            sys.exit(1)

        try:
            print "Creating folder in target instance to copy object..."
            migLogFile.write("Creating folder in target instance to copy object...\n")
            command = "mkdir -p " + uploadBaseTarget + "/" + objectDir + " "
            exit_status = createChannelAndExecuteCommand(command)
            print "exit_status after creating folder:", exit_status
            if exit_status == 0:
                print "Created folder in target instance to copy object."
                migLogFile.write("Created folder in target instance to copy object.\n")
                try:
                    print "Opening sftp connection to target instance..."
                    migLogFile.write("Opening sftp connection to target instance...\n")
                    sftp = ssh.open_sftp( )
                    print "Opened sftp connection to target instance."
                    migLogFile.write("Opened sftp connection to target instance.\n")
                except Exception as sftpConnectionException:
                    exit_status = -1
                    print "Unexpected error while opening sftp connection:",  sys.exc_info()[0]
                    migLogFile.write("Unexpected error while opening sftp connection:" + str(sys.exc_info()[0]) + "\n")

                try:
                    print "Copying object to target instance..."
                    migLogFile.write("Copying object to target instance...\n")
                    sftp.put( ldtLocation + "/" + objectName, uploadBaseTarget + "/" + objectDir + "/" + objectName )
                    print "Copied object to target instance."
                    migLogFile.write("Copied object to target instance.\n")
                except Exception as copyObjectException:
                    exit_status = -1
                    print "Unexpected error while copying object:", sys.exc_info()[0]
                    migLogFile.write("Unexpected error while copying object:" + str(sys.exc_info()[0]) + "\n")
            else:
                print "Unable to create folder in target instance to copy object."
                migLogFile.write("Unable to create folder in target instance to copy object.\n")

        except Exception as createFolderException:
            exit_status = -1
            print "Unexpected error while creating folder:", sys.exc_info()[0]
            migLogFile.write("Unexpected error while creating folder:" + str(sys.exc_info()[0]) + "\n")

except Exception as Exception:
    exit_status = -1
    print "Unexpected error :", sys.exc_info()[0]
    migLogFile.write("Unexpected error :" + str(sys.exc_info()[0]) + "\n")

try:
    if exit_status == 0:
        if isSudoUser == "Yes":
                command = "pwd; " + envFileCommand + " chmod 777 " + uploadBaseTarget + "/" + objectDir + " "
                print "command:" + command
                exit_status = createChannelAndExecuteCommand(command)
                print "exit_status after providing permissions:", exit_status

        if uploadMode == "Yes":
            uploadMode = "UPLOAD_MODE=REPLACE"
        else:
            uploadMode = ""
        if customMode == "Yes":
            customMode = "CUSTOM_MODE=FORCE"
        else:
            customMode = ""
        if patchFileSystemEnvFile == "null":
            patchFileSystemEnvFile = ""
        if territory == "null":
            territory = ""
        print "patchFileSystemEnvFile after modification:" + patchFileSystemEnvFile

        print "Executing required command to migrate " + objectName + " of object type " + objectType + "..."
        migLogFile.write("Executing required command to migrate " + objectName + " of object type " + objectType + "...\n")

        # DISCOVERER_REPORTS object type
        if objectType == "DISCOVERER_REPORTS":
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                command = "%s 'whoami; cd /home/%s; pwd; %s %s echo $FILE_EDITION; pwd; whoami; cd %s/%s; eulapi -connect %s -import %s -identifier -preserve_workbook_owner -import_rename_mode refresh -auto_refresh -log extractAOLlog.log 2> %s/%s/extractAOLlog.log'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, uploadBaseTarget, objectDir, appsDetails, "\"" + objectName + "\"", uploadBaseTarget, objectDir)
                exit_status = createChannelAndExecuteCommand(command)
            else:
                command = "pwd;" + envFileCommand + " " + patchFileSystemEnvFile + "echo $FILE_EDITION; cd " + uploadBaseTarget + "/" + objectDir + "; eulapi -connect " + appsDetails + " -import \"" + objectName + "\" -identifier -preserve_workbook_owner -import_rename_mode refresh -auto_refresh -log extractAOLlog.log 2> extractAOLlog.log"
                exit_status = createChannelAndExecuteCommand(command)
        # DISCOVERER_BA_FOLDER object type
        elif objectType == "DISCOVERER_BA_FOLDER":
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                command = "%s 'whoami; cd /home/%s; pwd; %s %s echo $FILE_EDITION; pwd; whoami; cd  %s/%s; eulapi -connect %s -import_rename_mode refresh -import %s 2> %s/%s/extractAOLlog.log'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, uploadBaseTarget, objectDir, appsDetails, "\"" + objectName + "\"", uploadBaseTarget, objectDir)
                exit_status = createChannelAndExecuteCommand(command)
            else:
                command = "pwd;" + envFileCommand + " " + patchFileSystemEnvFile + "echo $FILE_EDITION; cd " + uploadBaseTarget + "/" + objectDir + "; eulapi -connect " + appsDetails + " -import_rename_mode refresh -import \"" + objectName + "\" 2> extractAOLlog.log"
                exit_status = createChannelAndExecuteCommand(command)
        # BNE_LAYOUTS,BNE_INTEGRATORS,BNE_CONTENTS,BNE_MAPPINGS object type
        elif objectType == "BNE_MAPPINGS" or objectType == "BNE_INTEGRATORS" or objectType == "BNE_CONTENTS" or objectType == "BNE_LAYOUTS":
            print "Executing objectType :" + objectType
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                command = "%s 'whoami; cd /home/%s; pwd; %s %s echo $FILE_EDITION; pwd; whoami; cd  %s/%s; %s FNDLOAD %s 0 Y UPLOAD  $BNE_TOP/patch/115/import/%s %s 2> %s/%s/extractAOLlog.log;%s'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand,  patchFileSystemEnvFile, uploadBaseTarget, objectDir, nlsLangSettingValue, appsDetails, lctName, "\"" + objectName + "\"", uploadBaseTarget, objectDir, nlsLangRevertSetting)
                exit_status = createChannelAndExecuteCommand(command)
            else:
                command = "pwd;" + envFileCommand + " " + patchFileSystemEnvFile + "echo $FILE_EDITION; cd " + uploadBaseTarget + "/" + objectDir + ";"+nlsLangSettingValue+" FNDLOAD " + appsDetails + " 0 Y UPLOAD  $BNE_TOP/patch/115/import/" + lctName + " \"" + objectName + "\"  2> extractAOLlog.log;"+nlsLangRevertSetting
                exit_status = createChannelAndExecuteCommand(command)
        # BNE_PARAMLIST object type
        elif objectType == "BNE_PARAMLIST":
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                command = "%s 'whoami; cd /home/%s; pwd; %s %s echo $FILE_EDITION; pwd; whoami; cd %s/%s; %s FNDLOAD %s 0 Y UPLOAD  $BNE_TOP/patch/115/import/bneparamlist.lct  %s - %s %s 2> %s/%s/extractAOLlog.log;%s'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, uploadBaseTarget, objectDir, nlsLangSettingValue, appsDetails, lctName, "\"" + objectName + "\"", uploadBaseTarget, uploadMode, customMode, objectDir, nlsLangRevertSetting)
                exit_status = createChannelAndExecuteCommand(command)
            else:
                command = "pwd;" + envFileCommand + " " + patchFileSystemEnvFile + "echo $FILE_EDITION; cd " + uploadBaseTarget + "/" + objectDir + ";"+nlsLangSettingValue+"  FNDLOAD " + appsDetails + " 0 Y UPLOAD  $BNE_TOP/patch/115/import/bneparamlist.lct  \"" + objectName + "\" " + uploadMode + " " + customMode + " 2> extractAOLlog.log;"+nlsLangRevertSetting
                exit_status = createChannelAndExecuteCommand(command)
        # XML_PUB_REPORTS object type
        elif objectType == "XML_PUB_REPORTS":
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                command = "%s 'whoami; cd /home/%s; pwd; %s %s echo $FILE_EDITION; pwd; whoami; cd %s/%s; java oracle.apps.xdo.oa.util.XDOLoader UPLOAD -DB_USERNAME %s -DB_PASSWORD %s -JDBC_CONNECTION %s:%s:%s -LOB_TYPE %s -APPS_SHORT_NAME %s -LOB_CODE %s -LANGUAGE %s %s -XDO_FILE_TYPE %s -FILE_NAME %s -CUSTOM_MODE FORCE > extractAOLlog.log 2>&1'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, uploadBaseTarget, objectDir, schemaName, schemaPassword, dbInstanceIP, dbInstancePort, dbInstanceSID, lobType, applicationShortName, lobCode, language, territory, xdoFileType, "\"" + objectName + "\"")
                exit_status = createChannelAndExecuteCommand(command)
            else:
                command = "pwd;" + envFileCommand + " " + patchFileSystemEnvFile + "echo $FILE_EDITION; cd " + uploadBaseTarget + "/" + objectDir + ";  java oracle.apps.xdo.oa.util.XDOLoader UPLOAD -DB_USERNAME " + schemaName + " -DB_PASSWORD " + schemaPassword + " -JDBC_CONNECTION " + dbInstanceIP + ":" + dbInstancePort + ":" + dbInstanceSID + " -LOB_TYPE " + lobType + " -APPS_SHORT_NAME " + applicationShortName + " -LOB_CODE " + lobCode + " -LANGUAGE " + language + " " + territory + " -XDO_FILE_TYPE " + xdoFileType + " -FILE_NAME \"" + objectName + "\" -CUSTOM_MODE FORCE > extractAOLlog.log 2>&1"
                exit_status = createChannelAndExecuteCommand(command)
        # XDO_DS_DEFINITIONS object type
        elif objectType == "XDO_DS_DEFINITIONS":
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                command = "%s 'whoami; cd /home/%s; pwd; %s %s echo $FILE_EDITION; pwd; whoami; cd %s/%s; %s FNDLOAD %s 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct %s > %s/%s/extractAOLlog.log 2>&1;%s'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, uploadBaseTarget, objectDir, nlsLangSettingValue, appsDetails, "\"" + objectName + "\"", uploadBaseTarget, objectDir, nlsLangRevertSetting)
                exit_status = createChannelAndExecuteCommand(command)
            else:
                command = "pwd;" + envFileCommand + " " + patchFileSystemEnvFile + "echo $FILE_EDITION; cd " + uploadBaseTarget + "/" + objectDir + ";"+nlsLangSettingValue+"  FNDLOAD " + appsDetails + " 0 Y UPLOAD  $XDO_TOP/patch/115/import/xdotmpl.lct  \"" + objectName + "\"  2> extractAOLlog.log;"+nlsLangRevertSetting
                exit_status = createChannelAndExecuteCommand(command)
        # ORACLE_WORKFLOW object type
        elif objectType == "ORACLE_WORKFLOW":
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                command = "%s 'whoami; cd /home/%s; pwd; %s %s echo $FILE_EDITION; pwd; whoami; cd  %s/%s; WFLOAD  %s 0 Y %s %s  2> %s/%s/extractAOLlog.log'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, uploadBaseTarget, objectDir, appsDetails, workflowUploadMode, "\"" + objectName + "\"", uploadBaseTarget, objectDir)
                exit_status = createChannelAndExecuteCommand(command)
            else:
                command = "pwd;" + envFileCommand + " " + patchFileSystemEnvFile + "echo $FILE_EDITION; cd " + uploadBaseTarget + "/" + objectDir + ";  WFLOAD  " + appsDetails + " 0 Y " + workflowUploadMode + " \"" + objectName + "\"  2>  extractAOLlog.log"
                exit_status = createChannelAndExecuteCommand(command)
        # CONCURRENT_PROGRAM_NAME object type
        elif objectType == "CONCURRENT_PROGRAM_NAME":
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                command = "%s 'whoami; cd /home/%s; pwd; %s %s echo $FILE_EDITION; pwd; whoami; cd %s/%s; %s FNDLOAD %s 0 Y UPLOAD  $FND_TOP/patch/115/import/%s  %s - %s %s > %s/%s/extractAOLlog.log 2>&1;%s'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, uploadBaseTarget, objectDir, nlsLangSettingValue, appsDetails, lctName, "\"" + objectName + "\"", uploadMode, customMode, uploadBaseTarget, objectDir, nlsLangRevertSetting)
                exit_status = createChannelAndExecuteCommand(command)
            else:
                command = "pwd;" + envFileCommand + " " + patchFileSystemEnvFile + "echo $FILE_EDITION; cd " + uploadBaseTarget + "/" + objectDir + ";"+nlsLangSettingValue+"  FNDLOAD " + appsDetails + " 0 Y UPLOAD  $FND_TOP/patch/115/import/" + lctName + "  \"" + objectName + "\" - " + uploadMode + "  " + customMode + " > extractAOLlog.log 2>&1;"+nlsLangRevertSetting
                exit_status = createChannelAndExecuteCommand(command)
        # COLLECTION_ELEMENT object type
        elif objectType == "COLLECTION_ELEMENT":
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                command = "%s 'whoami; cd /home/%s; pwd; %s %s echo $FILE_EDITION; pwd; whoami; cd %s/%s; %s FNDLOAD %s 0 Y UPLOAD  $QA_TOP/patch/115/import/%s  %s   - WARNING=YES  %s %s 2> %s/%s/extractAOLlog.log'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, uploadBaseTarget, objectDir, nlsLangSettingValue, appsDetails, lctName, "\"" + objectName + "\"", uploadMode, customMode, uploadBaseTarget, objectDir, nlsLangRevertSetting)
                exit_status = createChannelAndExecuteCommand(command)
            else:
                command = "pwd;" + envFileCommand + " " + patchFileSystemEnvFile + "echo $FILE_EDITION; cd " + uploadBaseTarget + "/" + objectDir + ";"+nlsLangSettingValue+"  FNDLOAD " + appsDetails + " 0 Y UPLOAD  $QA_TOP/patch/115/import/" + lctName + "  \"" + objectName + "\" - WARNING=YES " + uploadMode + " " + customMode + " > extractAOLlog.log 2>&1;"+nlsLangRevertSetting
                exit_status = createChannelAndExecuteCommand(command)
        # COLLECTION_PLAN object type
        elif objectType == "COLLECTION_PLAN":
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                command = "%s 'whoami; cd /home/%s; pwd; %s %s echo $FILE_EDITION; pwd; whoami; cd  %s/%s; %s FNDLOAD %s 0 Y UPLOAD  $QA_TOP/patch/115/import/%s  %s  - WARNING=YES %s %s 2> %s/%s/extractAOLlog.log;%s'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, uploadBaseTarget, objectDir, nlsLangSettingValue, appsDetails, lctName, "\"" + objectName + "\"", uploadMode, customMode, uploadBaseTarget, objectDir, nlsLangRevertSetting)
                exit_status = createChannelAndExecuteCommand(command)
            else:
                command = "pwd;" + envFileCommand + " " + patchFileSystemEnvFile + "echo $FILE_EDITION; cd " + uploadBaseTarget + "/" + objectDir + ";"+nlsLangSettingValue+"  FNDLOAD " + appsDetails + " 0 Y UPLOAD  $QA_TOP/patch/115/import/" + lctName + " \"" + objectName + "\" - WARNING=YES  " + uploadMode + " " + customMode + " > extractAOLlog.log 2>&1;"+nlsLangRevertSetting
                exit_status = createChannelAndExecuteCommand(command)
        # ALERT_NAME object type
        elif objectType == "ALERT_NAME":
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                print "Alert command:" + command
                command = "%s 'whoami; cd /home/%s; pwd; %s %s echo $FILE_EDITION; pwd; whoami; cd  %s/%s; %s FNDLOAD %s 0 Y UPLOAD $ALR_TOP/patch/115/import/%s  %s  %s 2> %s/%s/extractAOLlog.log;%s'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, uploadBaseTarget, objectDir, nlsLangSettingValue,appsDetails, lctName, "\"" + objectName + "\"", customMode, uploadBaseTarget, objectDir, nlsLangRevertSetting)
                exit_status = createChannelAndExecuteCommand(command)
            else:
                command = "pwd;" + envFileCommand + " " + patchFileSystemEnvFile + "echo $FILE_EDITION; cd " + uploadBaseTarget + "/" + objectDir + ";"+nlsLangSettingValue+"  FNDLOAD " + appsDetails + " 0 Y UPLOAD $ALR_TOP/patch/115/import/" + lctName + "  \"" + objectName + "\" " + customMode + " 2> extractAOLlog.log;"+nlsLangRevertSetting
                exit_status = createChannelAndExecuteCommand(command)
        #AME objects migration
        elif objectType.startswith("AME"):
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                command = "%s 'whoami; cd /home/%s; pwd; %s %s echo $FILE_EDITION; pwd; whoami; cd  %s/%s; %s FNDLOAD %s 0 Y UPLOAD $AME_TOP/patch/115/import/%s %s 2> %s/%s/extractAOLlog.log;%s'" % (
                    connectToSudoCmd, uploadBaseTarget, envFileCommand, patchFileSystemEnvFile, objectDir, nlsLangSettingValue, appsDetails, lctName, "\"" + objectName + "\"", uploadBaseTarget, objectDir, nlsLangRevertSetting)
                exit_status = createChannelAndExecuteCommand(command)
            else:
                command = "pwd;" + envFileCommand + " " + patchFileSystemEnvFile + "echo $FILE_EDITION; cd " + uploadBaseTarget + "/" + objectDir + ";"+nlsLangSettingValue+"  FNDLOAD " + appsDetails + " 0 Y UPLOAD $AME_TOP/patch/115/import/" + lctName + "  \"" + objectName + "\" 2> extractAOLlog.log;"+nlsLangRevertSetting
                exit_status = createChannelAndExecuteCommand(command)
        else:
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                command = "%s 'whoami; cd /home/%s; pwd; %s %s echo $FILE_EDITION; pwd; whoami; cd  %s/%s; %s FNDLOAD %s 0 Y UPLOAD  $FND_TOP/patch/115/import/%s  %s %s %s 2> %s/%s/extractAOLlog.log;%s'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, uploadBaseTarget, objectDir, nlsLangSettingValue, appsDetails, lctName, "\"" + objectName + "\"", uploadMode, customMode, uploadBaseTarget, objectDir, nlsLangRevertSetting)
                exit_status = createChannelAndExecuteCommand(command)
            else:
                command = "pwd;" + envFileCommand + " " + patchFileSystemEnvFile + "echo $FILE_EDITION; cd " + uploadBaseTarget + "/" + objectDir + ";"+nlsLangSettingValue+"  FNDLOAD " + appsDetails + " 0 Y UPLOAD  $FND_TOP/patch/115/import/" + lctName + "  \"" + objectName + "\" " + uploadMode + " " + customMode + " 2> extractAOLlog.log;"+nlsLangRevertSetting
                exit_status = createChannelAndExecuteCommand(command)

        if exit_status == 0:
            print "Executed required command to migrate " + objectName + " of object type " + objectType + "."
            migLogFile.write(
                "Executed required command to migrate " + objectName + " of object type " + objectType + ".\n")
        else:
            print "Unable to execute required command to migrate " + objectName + " of object type " + objectType + "."
            migLogFile.write(
                "Unable to execute required command to migrate " + objectName + " of object type " + objectType + ".\n")

        remotedir = uploadBaseTarget + "/" + objectDir + "/"
        localdir = aolLogFileandLDTDownloadPath
        remoteFiles = sftp.listdir(path=remotedir)
        if len(remoteFiles) != 0:
            for files in remoteFiles:
                if fnmatch.fnmatch(files, '*.log'):
                    sftp.get(remotedir + files, localdir + files)

except Exception as migrationException:
    exit_status = -1
    print "Unexpected error while migrating object:", sys.exc_info()[0]
    migLogFile.write("Unexpected error while migrating object:" + str(sys.exc_info()[0]) + "\n")

finally:
        print "finally block!"
        migLogFile.write("finally block!\n")
        if connection_status == 0:
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                print "finally, sudo user!"
                migLogFile.write("finally, sudo user!\n")
                command = "%s whoami; cd /home/%s; pwd; %s rm -rf %s/%s" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, uploadBaseTarget, objectDir)
                exit_status = createChannelAndExecuteCommand(command)
                if exit_status == 0:
                    print "Successfully deleted objectDir"
                    migLogFile.write("Successfully deleted objectDir\n")
                else:
                    print "Unable to delete objectDir"
                    migLogFile.write("Unable to delete objectDir\n")
            else:
                print "finally, normal user!"
                migLogFile.write("finally, normal user!\n")
                command = "pwd;" + envFileCommand + " rm -rf " + uploadBaseTarget + "/" + objectDir + "/"
                exit_status = createChannelAndExecuteCommand(command)
                if exit_status == 0:
                    print "Successfully deleted objectDir"
                    migLogFile.write("Successfully deleted objectDir\n")
                else:
                    print "Unable to delete objectDir"
                    migLogFile.write("Unable to delete objectDir\n")
        else:
            print "Connection not established"
            migLogFile.write("Connection not established\n")
        if sftp:
            sftp.close()
        if ssh:
            ssh.close()
        sys.exit(1)
