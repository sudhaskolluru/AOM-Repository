import StringIO
import fnmatch
import socket
import sys
import time
import select
import shutil
#from turtle import done

import paramiko
import os
import zipfile

try:
    try:
        print 'Number of arguments:', len(sys.argv), 'arguments.'
        #destinationPassword was also getting printed in TRI2 logs so commented the below statement.
        #print 'Argument List:', str(sys.argv)
        objectType            = sys.argv[1]
        applicationTop        = sys.argv[2]
        destinationUserName   = sys.argv[3]
        destinationPassword   = sys.argv[4]
        destinationIP         = sys.argv[5]
        destinationPortNumber = sys.argv[6]
        logFileName           = sys.argv[7]
        downloadBasepath      = sys.argv[8]
        objectName            = sys.argv[9]
        objectDir             = sys.argv[10]
        objectType            = sys.argv[11]
        applicationShortName  = sys.argv[12]
        lctName               = sys.argv[13]
        entityName            = sys.argv[14]
        lobType               = sys.argv[15]
        ldt_FileName          = sys.argv[16]
        schemaName            = sys.argv[17]
        schemaPassword        = sys.argv[18]
        sudoToUser            = sys.argv[19]
        applicationTop        = sys.argv[20]
        ID_FLEX_CODE_0        = sys.argv[21]
        P_STRUCTURE_CODES     = sys.argv[22]
        hiddenplanId          = sys.argv[23]
        hiddenplanId          = sys.argv[24]
        objectType            = sys.argv[25]
        lctName               = sys.argv[26]
        ldt_FileName          = sys.argv[27]
        appsDetails           = sys.argv[28]
        dbInstanceIP          = sys.argv[29]
        dbInstancePortString  = sys.argv[30]
        instanceSID           = sys.argv[31]
        ldtDownloadPath       = sys.argv[32]
        isSudoUser            = sys.argv[33]
        sudoToUser            = sys.argv[34]
        connectToSudoCmd      = sys.argv[35]
        envFileCommand        = sys.argv[36]
        pythonTarget          = sys.argv[37]
        keyFilePath              = sys.argv[38]
        nlsLangSettingValue   = sys.argv[39]
        nlsLangRevertSetting  = ""

        exit_status = -1
        print "objectType:" + objectType
        print "applicationTop:" + applicationTop
        print "destinationUserName:" + destinationUserName
        #print "destinationPassword:" + destinationPassword
        print "destinationPortNumber:" + destinationPortNumber
        print "logFileName:" + logFileName
        print "downloadBasepath:" + downloadBasepath
        print "objectName:" + objectName
        print "objectDir:" + objectDir
        print "objectType:" + objectType
        print "applicationShortName:" + applicationShortName
        print "lctName:" + lctName
        print "entityName:" + entityName
        print "lobType:" + lobType
        print "ldt_FileName:" + ldt_FileName
        print "schemaName:" + schemaName
        #print "schemaPassword:" + schemaPassword
        print "sudoToUser:" + sudoToUser
        print "applicationTop:" + applicationTop
        print "ID_FLEX_CODE_0:" + ID_FLEX_CODE_0
        print "P_STRUCTURE_CODES:" + P_STRUCTURE_CODES
        print "hiddenplanId:" + hiddenplanId
        print "objectType:" + objectType
        print "lctName:" + lctName
        print "ldt_FileName:" + ldt_FileName
        print "appsDetails:" + appsDetails
        print "dbInstanceIP:" + dbInstanceIP
        print "dbInstancePortString:" + dbInstancePortString
        print "instanceSID:" + instanceSID
        print "ldtDownloadPath:" + ldtDownloadPath
        print "isSudoUser:" + isSudoUser
        print "sudoToUser:" + sudoToUser
        print "connectToSudoCmd:" + connectToSudoCmd
        print "envFileCommand:" + envFileCommand
        print "pythonTarget:" + pythonTarget
        print "keyFilePath:" +keyFilePath
        print "nlsLangSettingValue:" + nlsLangSettingValue
        USER_NAME    = "USER_NAME"
        P_LEVEL      = "P_LEVEL"
        P_STRUCTURE_CODE = "P_STRUCTURE_CODE"
        CHAR_ID      = "CHAR_ID"
        QA_CHARS     = "QA_CHARS"
        PLAN_ID      = "PLAN_ID"
        QA_PLANS     = "QA_PLANS"
        RESP_KEY     = "RESP_KEY"
        ID_FLEX_CODE = "ID_FLEX_CODE"
        APPLICATION_SHORT_NAME = "APPLICATION_SHORT_NAME"
        P_LEVEL_VALUE = 'COL_ALL:FQL_ALL:SQL_ALL:STR_ONE:WFP_ALL:SHA_ALL:CVR_ALL:SEG_ALL'

        if nlsLangSettingValue != "":
            nlsLangRevertSetting = "export NLS_LANG=\"AMERICAN_AMERICA.UTF8\""

        print("nlsLangRevertSetting::"+nlsLangRevertSetting)

        #Opening Log file to write required prints
        migLogFile = open(logFileName, "a")
        connection_status = 0
        ssh = None
        sftp = None
        #Opening ssh session to target instance
        print "Creating ssh connection to target instance..."
        migLogFile.write("Creating ssh connection to target instance...\n")
        ssh = paramiko.SSHClient( )
        ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy( ) )
        if destinationPassword == "null":
            print "Connecting to target instance through keyfile"
            migLogFile.write("Connecting to target instance through keyfile...\n")
            private_key = os.path.expanduser(keyFilePath)
            print private_key
            ssh.connect(destinationIP, username=destinationUserName, key_filename=private_key)
            migLogFile.write("Connected to target instance through keyfile...\n")
        else:
            print "Connecting to target instance through password"
            migLogFile.write("Connecting to target instance through password...\n")
            ssh.connect( destinationIP, username=destinationUserName, password=destinationPassword )
            migLogFile.write("Connected to target instance through password...\n")
        print "Created ssh connection to target instance."
        migLogFile.write("Created ssh connection to target instance.\n")
    except paramiko.AuthenticationException:
        print "Authentication Exception"
        migLogFile.write("Authentication Exception\n")
        connection_status = -1
        sys.exit(1)

    except Exception as connectException:
        print "Connect Exception:"
        print connectException
        migLogFile.write("Connect Exception:" + str(connectException) + "\n")
        connection_status = -1
        sys.exit(1)

    def createChannelAndExecuteCommand(command):
        try:
            print "Inside createChannelAndExecuteCommand..."
            migLogFile.write("Inside createChannelAndExecuteCommand...\n")
            Channel = ssh.get_transport( ).open_session( )
            Channel.get_pty( )
            Channel.settimeout( 1080 )
            Channel.exec_command( command )
            exit_status = Channel.recv_exit_status( )
            print "createChannelAndExecuteCommand end."
            migLogFile.write("createChannelAndExecuteCommand end.\n")
            return exit_status
        except Exception as createChannelAndExecuteCommandException:
            print "Unexpected error while creating channel and executing command :", sys.exc_info()[0]
            migLogFile.write("Unexpected error while creating channel and executing command:" + str(sys.exc_info()[0])
                             + "\n")
            exit_status = -1
            return exit_status

    def createDirectory():
        try:
            print "createDirectory...is in Execution..."
            migLogFile.write("createDirectory...is in Execution...\n")
            command = "mkdir -p " + downloadBasepath + "/" + objectDir
            exit_status = createChannelAndExecuteCommand(command)
            if isSudoUser == "Yes":
                    command =  envFileCommand + " chmod -R 777 " + downloadBasepath + "/" + objectDir
                    exit_status = createChannelAndExecuteCommand(command)
            if exit_status == 0:
                print "createDirectory execution is completed."
                migLogFile.write("createDirectory execution is completed.\n")
            else:
                print "Unable to create directory."
                migLogFile.write("Unable to create directory.\n")
        except Exception as createDirectoryException:
            print "Unexpected error while creating directory :", sys.exc_info()[0]
            migLogFile.write("Unexpected error while creating directory :" + str(sys.exc_info()[0]) + "\n")

    def deleteDirectory():
        try:
            print "deleteDirectory...is in Execution..."
            migLogFile.write("deleteDirectory...is in Execution...\n")
            command = "cd " + downloadBasepath + "; rm -rf " + objectDir
            exit_status = createChannelAndExecuteCommand(command)
            if exit_status == 0:
                print "deleteDirectory execution is completed."
                migLogFile.write("deleteDirectory execution is completed.\n")
            else:
                print "Unable to delete Directory"
                migLogFile.write("Unable to delete Directory\n")
        except Exception as deleteDirectoryException:
            print "Unexpected error while deleting directory :", sys.exc_info()[0]
            migLogFile.write("Unexpected error while deleting directory :" + str(sys.exc_info()[0]) + "\n")

    def copy():
        print "copy()...is in Execution..."
        migLogFile.write("copy()...is in Execution...\n")
        # ORACLE_FORMS object type
        if objectType == "ORACLE_FORMS":
            print "Inside ORACLE_FORMS..."
            migLogFile.write("Inside ORACLE_FORMS...\n")
            oracleobjectName = "\"" + objectName + "\"" + ".fmb"
            print "oracleobjectName:" + oracleobjectName
            if sudoToUser != "sudoToUser-no":
                print "Executing with Sudo user..."
                migLogFile.write("Executing with Sudo user...\n")
                command = "%s ' %s pwd; cp %s/%s %s/%s > extractAOLlog.log 2>&1'" % (
                    connectToSudoCmd, envFileCommand, applicationTop, oracleobjectName, downloadBasepath, objectDir)
                exit_status = createChannelAndExecuteCommand(command)
                if exit_status == 0:
                    print "Execution with Sudo user is completed."
                    migLogFile.write("Execution with Sudo user is completed.\n")
            else:
                print "Executing with Normal user..."
                migLogFile.write("Executing with Normal user...\n")
                command = envFileCommand + " cp " + applicationTop + "/" + oracleobjectName + " " + downloadBasepath + "/" + objectDir + " > extractAOLlog.log 2>&1"
                exit_status = createChannelAndExecuteCommand(command)
                if exit_status == 0:
                    print "Execution with Normal user is completed."
                    migLogFile.write("Execution with Normal user is completed.\n")
        # ORACLE_REPORTS object type
        elif objectType == "ORACLE_REPORTS":
            print "Inside ORACLE_REPORTS..."
            migLogFile.write("Inside ORACLE_REPORTS...\n")
            oracleReportObjectName = "\"" + objectName + "\"" + ".rdf"
            print "oracleReportObjectName:" + oracleReportObjectName
            migLogFile.write("oracleReportObjectName:" + oracleReportObjectName + "\n")
            if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cp %s/%s %s/%s; > extractAOLlog.log 2>&1'" % (
                        connectToSudoCmd, envFileCommand, applicationTop, oracleReportObjectName, downloadBasepath, objectDir)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
            else:
                print "Executing with Normal user..."
                migLogFile.write("Executing with Normal user...\n")
                command = envFileCommand + " cp " + applicationTop + "/" + oracleReportObjectName + " " + downloadBasepath + "/" + objectDir +" > extractAOLlog.log 2>&1"
                exit_status = createChannelAndExecuteCommand(command)
                if exit_status == 0:
                    print "Execution with Normal user is completed."
                    migLogFile.write("Execution with Normal user is completed.\n")
        # CONTROL_FILES object Type
        elif objectType == "CONTROL_FILES":
            print "Inside CONTROL_FILES..."
            migLogFile.write("Inside CONTROL_FILES...\n")
            oracleReportObjectName = "\"" + objectName + "\"" + ".ctl"
            print "oracleReportObjectName:" + oracleReportObjectName
            migLogFile.write("oracleReportObjectName:" + oracleReportObjectName + "\n")
            if sudoToUser != "sudoToUser-no":
                print "Executing with Sudo user..."
                migLogFile.write("Executing with Sudo user...\n")
                command = "%s ' %s cp %s/%s %s/%s; > extractAOLlog.log 2>&1'" % (
                    connectToSudoCmd, envFileCommand , applicationTop, oracleReportObjectName, downloadBasepath, objectDir)
                exit_status = createChannelAndExecuteCommand(command)
                if exit_status == 0:
                    print "Execution with Sudo user is completed."
                    migLogFile.write("Execution with Sudo user is completed.\n")
            else:
                print "Executing with Normal user..."
                migLogFile.write("Executing with Normal user...\n")
                command = envFileCommand + " cp " + applicationTop + "/" + oracleReportObjectName + " " + downloadBasepath + "/" + objectDir + " > extractAOLlog.log 2>&1"
                exit_status = createChannelAndExecuteCommand(command)
                if exit_status == 0:
                    print "Execution with Normal user is completed."
                    migLogFile.write("Execution with Normal user is completed.\n")

    print "pythonTarget:" + pythonTarget
    migLogFile.write("pythonTarget:" + pythonTarget + "\n")
    if(pythonTarget == "DOWNLOAD_AOL_OBJECTS"):
            createDirectory()
               # ORACLE_WORKFLOW object type
            if objectType == "ORACLE_WORKFLOW":
                print "Inside ORACLE_WORKFLOW..."
                migLogFile.write("Inside ORACLE_WORKFLOW...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s ; WFLOAD %s 0 Y DOWNLOAD %s %s  > extractAOLlog.log 2>&1'" % (
                        connectToSudoCmd, envFileCommand, sudoToUser, downloadBasepath, objectDir, appsDetails, "\"" + ldt_FileName + "\"", "\"" + objectName + "\"")
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd  " + downloadBasepath + "/" + objectDir + "; WFLOAD " + appsDetails + " 0 Y DOWNLOAD " + "\"" + ldt_FileName +"\"" + " " + "\"" + objectName + "\"" + " > extractAOLlog.log 2>&1"
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                        migLogFile.write("Execution with Normal user is completed.\n")
            # BNE_LAYOUTS object type
            elif objectType == "BNE_LAYOUTS":
                print "Inside BNE_LAYOUTS..."
                migLogFile.write("Inside BNE_LAYOUTS...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s '%s cd /home/%s; cd %s/%s ;%s FNDLOAD %s 0 Y DOWNLOAD $BNE_TOP/patch/115/import/%s %s BNE_LAYOUTS LAYOUT_ASN=%s LAYOUT_CODE=%s  > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand, sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails, lctName, "\"" + ldt_FileName + "\"",applicationShortName, "\"" + objectName + "\"",nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                    migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd " + downloadBasepath + "/" + objectDir + ";"+nlsLangSettingValue+" FNDLOAD " + appsDetails + " 0 Y DOWNLOAD $BNE_TOP/patch/115/import/" + lctName + " " + "\"" + ldt_FileName + "\"" + " BNE_LAYOUTS LAYOUT_ASN=" + applicationShortName + "  LAYOUT_CODE=" + "\"" + objectName + "\"" + " > extractAOLlog.log 2>&1;"+nlsLangRevertSetting
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                    migLogFile.write("Execution with Normal user is completed.\n")
            # BNE_MAPPINGS object type
            elif objectType == "BNE_MAPPINGS":
                print "Inside BNE_MAPPINGS..."
                migLogFile.write("Inside BNE_MAPPINGS...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s ; %s FNDLOAD %s 0 Y DOWNLOAD $BNE_TOP/patch/115/import/%s %s BNE_MAPPINGS MAPPING_ASN=%s MAPPING_CODE=%s  > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand , sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails, lctName,
                        "\"" + ldt_FileName + "\"", applicationShortName, "\"" + objectName + "\"", nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                    migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd " + downloadBasepath + "/" + objectDir + ";"+nlsLangSettingValue+"  FNDLOAD " + appsDetails + " 0 Y DOWNLOAD $BNE_TOP/patch/115/import/" + lctName + " " + "\"" + ldt_FileName + "\"" + " BNE_MAPPINGS MAPPING_ASN=" + applicationShortName + "  MAPPING_CODE=" + "\"" + objectName + "\"" + " > extractAOLlog.log 2>&1;"+nlsLangRevertSetting
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                    migLogFile.write("Execution with Normal user is completed.\n")
            # BNE_INTEGRATORS object type
            elif objectType == "BNE_INTEGRATORS":
                print "Inside BNE_INTEGRATORS..."
                migLogFile.write("Inside BNE_INTEGRATORS...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s ; %s FNDLOAD %s 0 Y DOWNLOAD $BNE_TOP/patch/115/import/%s %s BNE_INTEGRATORS INTEGRATOR_ASN=%s INTEGRATOR_CODE=%s  > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand, sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails, lctName,
                        "\"" + ldt_FileName + "\"", applicationShortName, "\"" + objectName + "\"", nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                    migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd " + downloadBasepath + "/" + objectDir + ";"+nlsLangSettingValue+"  FNDLOAD " + appsDetails + " 0 Y DOWNLOAD $BNE_TOP/patch/115/import/" + lctName + " " + "\"" + ldt_FileName + "\"" + " BNE_INTEGRATORS INTEGRATOR_ASN=" + applicationShortName + "  INTEGRATOR_CODE=" + "\"" + objectName + "\"" + " > extractAOLlog.log 2>&1;"+nlsLangRevertSetting
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                    migLogFile.write("Execution with Normal user is completed.\n")
            # BNE_CONTENTS object type
            elif objectType == "BNE_CONTENTS":
                print "Inside BNE_CONTENTS..."
                migLogFile.write("Inside BNE_CONTENTS...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s ; %s FNDLOAD %s 0 Y DOWNLOAD $BNE_TOP/patch/115/import/%s %s BNE_CONTENTS CONTENT_ASN=%s CONTENT_CODE=%s  > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand , sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails, lctName,
                        "\"" + ldt_FileName + "\"", applicationShortName, "\"" + objectName + "\"", nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                    migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd " + downloadBasepath + "/" + objectDir + ";"+nlsLangSettingValue+"  FNDLOAD " + appsDetails + " 0 Y DOWNLOAD $BNE_TOP/patch/115/import/" + lctName + " " + "\"" + ldt_FileName + "\"" + " BNE_CONTENTS CONTENT_ASN=" + applicationShortName + "  CONTENT_CODE=" + "\"" + objectName + "\"" + " > extractAOLlog.log 2>&1;"+nlsLangRevertSetting
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                    migLogFile.write("Execution with Normal user is completed.\n")
            # XDO_DS_DEFINITIONS object type
            elif objectType == "XDO_DS_DEFINITIONS":
                print "Inside XDO_DS_DEFINITIONS..."
                migLogFile.write("Inside XDO_DS_DEFINITIONS...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s; %s FNDLOAD %s 0 Y DOWNLOAD $XDO_TOP/patch/115/import/%s %s XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME=%s DATA_SOURCE_CODE=%s > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand, sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails, lctName, "\"" + ldt_FileName + "\"", applicationShortName,  "\"" + objectName + "\"",nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd " + downloadBasepath + "/" + objectDir + ";"+nlsLangSettingValue+"  FNDLOAD " + appsDetails + " 0 Y DOWNLOAD $XDO_TOP/patch/115/import/" + lctName + " " + "\"" + ldt_FileName + "\"" + " XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME=" + applicationShortName + " DATA_SOURCE_CODE=" + "\"" + objectName + "\"" + " > extractAOLlog.log 2>&1;"+nlsLangRevertSetting
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                        migLogFile.write("Execution with Normal user is completed.\n")
            # XML_PUB_REPORTS object type
            elif objectType == "XML_PUB_REPORTS":
                print "Inside XML_PUB_REPORTS..."
                migLogFile.write("Inside XML_PUB_REPORTS...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd %s/%s; java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD -DB_USERNAME %s -DB_PASSWORD %s -JDBC_CONNECTION \"(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=%s)(PORT=%s))(CONNECT_DATA=(SERVICE_NAME=%s)))\" -LOB_TYPE %s -LOB_CODE %s -APPS_SHORT_NAME %s -lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct -LOG_FILE migLogFile.log > extractAOLlog.log 2>&1'" % (
                        connectToSudoCmd, envFileCommand , downloadBasepath, objectDir, schemaName, schemaPassword, dbInstanceIP, dbInstancePortString, instanceSID, lobType, "\"" + objectName + "\"", applicationShortName)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd " + downloadBasepath + "/" + objectDir + ";  java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD -DB_USERNAME " + schemaName + " -DB_PASSWORD " + schemaPassword + " -JDBC_CONNECTION '(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=" + dbInstanceIP + ")(PORT=" + dbInstancePortString + "))(CONNECT_DATA=(SERVICE_NAME=" + instanceSID + ")))' -LOB_TYPE " + lobType + " -LOB_CODE " + "\"" + objectName + "\"" + " -APPS_SHORT_NAME " + applicationShortName + " -lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct -LOG_FILE migLogFile.log > extractAOLlog.log 2>&1"
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                        migLogFile.write("Execution with Normal user is completed.\n")
            # CONCURRENT_PROGRAM_NAME/EXECUTABLE_NAME/LOOKUP_TYPE/PROFILE_NAME/MESSAGE_NAME/REQUEST_SET_NAME/FORM_NAME/REQUEST_SET_LINK_NAME/REQUEST_GROUP_NAME object types
            elif objectType == "CONCURRENT_PROGRAM_NAME" or objectType == "EXECUTABLE_NAME" or objectType == "LOOKUP_TYPE" or objectType == "PROFILE_NAME" or  objectType == "MESSAGE_NAME" or objectType == "REQUEST_SET_NAME" or objectType == "FORM_NAME" or objectType == "REQUEST_SET_LINK_NAME" or objectType == "REQUEST_GROUP_NAME":
                print "Inside CONCURRENT_PROGRAM_NAME/EXECUTABLE_NAME/LOOKUP_TYPE/PROFILE_NAME/MESSAGE_NAME/REQUEST_SET_NAME/FORM_NAME/REQUEST_SET_LINK_NAME/REQUEST_GROUP_NAME object types..."
                migLogFile.write("Inside CONCURRENT_PROGRAM_NAME/EXECUTABLE_NAME/LOOKUP_TYPE/PROFILE_NAME/MESSAGE_NAME/REQUEST_SET_NAME/FORM_NAME/REQUEST_SET_LINK_NAME/REQUEST_GROUP_NAME object types...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s; %s FNDLOAD %s 0 Y DOWNLOAD $FND_TOP/patch/115/import/%s %s %s %s=%s %s=%s > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand , sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails,lctName, "\"" + ldt_FileName + "\"" , entityName, APPLICATION_SHORT_NAME, applicationShortName, objectType, "\"" + objectName + "\"",nlsLangRevertSetting )
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd %s/%s; %s FNDLOAD %s 0 Y DOWNLOAD $FND_TOP/patch/115/import/%s %s %s %s=%s %s=%s;> extractAOLlog.log 2>&1;%s" % (
                        downloadBasepath, objectDir, nlsLangSettingValue, appsDetails,lctName, "\"" + ldt_FileName + "\"" , entityName, APPLICATION_SHORT_NAME, applicationShortName, objectType, "\"" + objectName + "\"",nlsLangRevertSetting )
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                        migLogFile.write("Execution with Normal user is completed.\n")
            # FLEX_VALUE_SET_NAME/FLEX_VALUE_SET_VALUE_NAME/MENU_NAME/ENTRY_NAME/PRINTER_STYLE_NAME/FUNCTION_NAMEobject types
            elif objectType == "FLEX_VALUE_SET_NAME" or objectType == "FLEX_VALUE_SET_VALUE_NAME" or objectType == "MENU_NAME" or objectType == "ENTRY_NAME" or objectType == "PRINTER_STYLE_NAME" or objectType == "FUNCTION_NAME":
                print "Inside FLEX_VALUE_SET_NAME/FLEX_VALUE_SET_VALUE_NAME/MENU_NAME/ENTRY_NAME/PRINTER_STYLE_NAME/FUNCTION_NAMEobject types..."
                migLogFile.write("Inside FLEX_VALUE_SET_NAME/FLEX_VALUE_SET_VALUE_NAME/MENU_NAME/ENTRY_NAME/PRINTER_STYLE_NAME/FUNCTION_NAMEobject types...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s; %s FNDLOAD %s 0 Y DOWNLOAD $FND_TOP/patch/115/import/%s %s %s %s=%s  > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand , sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails,lctName,  "\"" + ldt_FileName + "\"", entityName, objectType, "\"" + objectName + "\"", nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd " + downloadBasepath + "/" + objectDir + ";"+nlsLangSettingValue+" FNDLOAD " + appsDetails + " 0 Y DOWNLOAD $FND_TOP/patch/115/import/" + lctName + " " + "\"" + ldt_FileName + "\"" + " " + entityName + " " + objectType + "=" + "\"" + objectName + "\"" + "> extractAOLlog.log 2>&1;"+nlsLangRevertSetting
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                        migLogFile.write("Execution with Normal user is completed.\n")
            # FND_ATTACHMENT_FUNCTIONS object type
            elif objectType == "FND_ATTACHMENT_FUNCTIONS":
                print "Inside FND_ATTACHMENT_FUNCTIONS..."
                migLogFile.write("Inside FND_ATTACHMENT_FUNCTIONS...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s; %s FNDLOAD %s 0 Y DOWNLOAD $FND_TOP/patch/115/import/%s %s %s FUNCTION_NAME=%s APPLICATION_SHORT_NAME= %s  > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand,  sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails,lctName,  "\"" + ldt_FileName + "\"", entityName, "\"" + objectName + "\"", applicationShortName, nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd " + downloadBasepath + "/" + objectDir + ";"+nlsLangSettingValue+"  FNDLOAD  " + appsDetails + " 0 Y DOWNLOAD $FND_TOP/patch/115/import/" + lctName + "  " + "\"" + ldt_FileName + "\"" + " " + entityName + " FUNCTION_NAME="+ "\"" + objectName + "\"" + " APPLICATION_SHORT_NAME= " + applicationShortName + " > extractAOLlog.log 2>&1;"+nlsLangRevertSetting
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                        migLogFile.write("Execution with Normal user is completed.\n")
            # FND_FORM_FUNCTION_NAME object type
            elif objectType == "FND_FORM_FUNCTION_NAME":
                print "Inside FND_FORM_FUNCTION_NAME..."
                migLogFile.write("Inside FND_FORM_FUNCTION_NAME...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s; %s FNDLOAD %s 0 Y DOWNLOAD $FND_TOP/patch/115/import/%s %s %s FUNCTION_NAME=%s > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand , sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails, lctName, "\"" + ldt_FileName + "\"", entityName, "\"" + objectName + "\"",nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd " + downloadBasepath + "/" + objectDir + ";"+nlsLangSettingValue+" FNDLOAD  " + appsDetails + " 0 Y DOWNLOAD $FND_TOP/patch/115/import/" + lctName + " " + "\"" + ldt_FileName + "\"" + " " + entityName + " FUNCTION_NAME= " + "\"" + objectName + "\"" + " > extractAOLlog.log 2>&1;"+nlsLangRevertSetting
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                        migLogFile.write("Execution with Normal user is completed.\n")
            # FND_RESPONSIBILITY_KEY object type
            elif objectType == "FND_RESPONSIBILITY_KEY":
                print "Inside FND_RESPONSIBILITY_KEY..."
                migLogFile.write("Inside FND_RESPONSIBILITY_KEY...")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s; %s FNDLOAD %s 0 Y DOWNLOAD $FND_TOP/patch/115/import/%s %s %s %s=%s > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand , sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails, lctName, "\"" + ldt_FileName + "\"", entityName, RESP_KEY, "\"" + objectName + "\"",nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd " + downloadBasepath + "/" + objectDir + ";"+nlsLangSettingValue+"  FNDLOAD " + appsDetails + " 0 Y DOWNLOAD $FND_TOP/patch/115/import/" + lctName + " " + "\"" + ldt_FileName + "\"" + " " + entityName + " " + RESP_KEY + "=" + "\"" + objectName + "\"" + "> extractAOLlog.log 2>&1;"+nlsLangRevertSetting
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                        migLogFile.write("Execution with Normal user is completed.\n")
            # FND_USER_NAME object type
            elif objectType == "FND_USER_NAME":
                print "Inside FND_USER_NAME..."
                migLogFile.write("Inside FND_USER_NAME...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s; %s FNDLOAD %s 0 Y DOWNLOAD $FND_TOP/patch/115/import/%s %s %s %s=%s > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand, sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails, lctName, "\"" + ldt_FileName + "\"", entityName, USER_NAME, "\"" + objectName + "\"",nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd " + downloadBasepath + "/" + objectDir + ";"+nlsLangSettingValue+" FNDLOAD " + appsDetails + " 0 Y DOWNLOAD $FND_TOP/patch/115/import/" + lctName + " " + "\"" + ldt_FileName + "\"" + " " + entityName + " " + USER_NAME + "=" + "\"" + objectName + "\"" + "> extractAOLlog.log 2>&1;"+nlsLangRevertSetting
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                        migLogFile.write("Execution with Normal user is completed.\n")
            # ID_FLEX_CODE object type
            elif objectType == "ID_FLEX_CODE":
                print "Inside ID_FLEX_CODE..."
                migLogFile.write("Inside ID_FLEX_CODE...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s; %s FNDLOAD %s 0 Y DOWNLOAD $FND_TOP/patch/115/import/%s %s %s %s=%s %s=%s %s=%s %s=%s  > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand, sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails,lctName,  "\"" + ldt_FileName + "\"", entityName, P_LEVEL, P_LEVEL_VALUE, APPLICATION_SHORT_NAME, applicationShortName, ID_FLEX_CODE, ID_FLEX_CODE_0, P_STRUCTURE_CODE, P_STRUCTURE_CODES,nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd " + downloadBasepath + "/" + objectDir + ";"+nlsLangSettingValue+" FNDLOAD " + appsDetails + " 0 Y DOWNLOAD $FND_TOP/patch/115/import/" + lctName + " " + "\"" + ldt_FileName + "\"" + " " + entityName + " P_LEVEL='COL_ALL:FQL_ALL:SQL_ALL:STR_ONE:WFP_ALL:SHA_ALL:CVR_ALL:SEG_ALL' APPLICATION_SHORT_NAME= " + applicationShortName + " ID_FLEX_CODE=" + ID_FLEX_CODE_0 + " P_STRUCTURE_CODE=" + P_STRUCTURE_CODE + " > extractAOLlog.log 2>&1;"+nlsLangRevertSetting
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                        migLogFile.write("Execution with Normal user is completed.\n")
            # DESCRIPTIVE_FLEXFIELD_NAME object type
            elif objectType == "DESCRIPTIVE_FLEXFIELD_NAME":
                print "Inside DESCRIPTIVE_FLEXFIELD_NAME..."
                migLogFile.write("Inside DESCRIPTIVE_FLEXFIELD_NAME...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s; %s FNDLOAD %s 0 Y DOWNLOAD $FND_TOP/patch/115/import/%s %s %s %s=%s %s=%s > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand, sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails, lctName, "\"" + ldt_FileName + "\"", entityName, APPLICATION_SHORT_NAME, applicationShortName, objectType, "\"" + objectName + "\"",nlsLangRevertSetting)
                    print "Command :" + command
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd  " + downloadBasepath + "/" + objectDir + ";"+nlsLangSettingValue+" FNDLOAD " + appsDetails + " 0 Y DOWNLOAD $FND_TOP/patch/115/import/" + lctName + " %s %s %s=%s %s=%s > extractAOLlog.log 2>&1;%s" % (
                        "\"" + ldt_FileName + "\"", entityName, APPLICATION_SHORT_NAME, applicationShortName, objectType, "\"" + objectName + "\"",nlsLangRevertSetting)
                    print "Command :" + command
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                        migLogFile.write("Execution with Normal user is completed.\n")
            # ALERT_NAME object type
            elif objectType == "ALERT_NAME":
                print "Inside ALERT_NAME..."
                migLogFile.write("Inside ALERT_NAME...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s; %s FNDLOAD %s 0 Y DOWNLOAD $ALR_TOP/patch/115/import/%s %s %s %s=%s %s=%s > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand, sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails, lctName,  "\"" + ldt_FileName + "\"", entityName, APPLICATION_SHORT_NAME, applicationShortName, objectType, "\"" + objectName + "\"",nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd " + downloadBasepath + "/" + objectDir + ";"+nlsLangSettingValue+" FNDLOAD " + appsDetails + " 0 Y DOWNLOAD $ALR_TOP/patch/115/import/" + lctName + " %s %s %s=%s %s=%s 2> extractAOLlog.log 2>&1;%s" % (
                        "\"" + ldt_FileName + "\"", entityName, APPLICATION_SHORT_NAME, applicationShortName, objectType, "\"" + objectName + "\"",nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                        migLogFile.write("Execution with Normal user is completed.\n")
            # COLLECTION_PLAN object type
            elif objectType == "COLLECTION_PLAN":
                print "Inside COLLECTION_PLAN..."
                migLogFile.write("Inside COLLECTION_PLAN...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s; %s FNDLOAD %s 0 Y DOWNLOAD $QA_TOP/patch/115/import/%s %s %s %s=%s > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand, sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails,lctName,  "\"" + ldt_FileName + "\"", QA_PLANS, PLAN_ID, hiddenplanId,nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd  " + downloadBasepath + "/" + objectDir + ";"+nlsLangSettingValue+" FNDLOAD " + appsDetails + " 0 Y DOWNLOAD $QA_TOP/patch/115/import/" + lctName + " %s %s %s=%s > extractAOLlog.log 2>&1;%s" % (
                        "\"" + ldt_FileName + "\"", QA_PLANS, PLAN_ID, hiddenplanId,nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                        migLogFile.write("Execution with Normal user is completed.\n")
            # COLLECTION_ELEMENT object type
            elif objectType == "COLLECTION_ELEMENT":
                print "Inside COLLECTION_ELEMENT..."
                migLogFile.write("Inside COLLECTION_ELEMENT...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s; %s FNDLOAD %s 0 Y DOWNLOAD $QA_TOP/patch/115/import/%s %s %s %s=%s > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand, sudoToUser, downloadBasepath, objectDir, nlsLangSettingValue, appsDetails, lctName,  "\"" + ldt_FileName + "\"", QA_CHARS, CHAR_ID, hiddenplanId,nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd " + downloadBasepath + "/" + objectDir + ";"+nlsLangSettingValue+" FNDLOAD " + appsDetails + " 0 Y DOWNLOAD $QA_TOP/patch/115/import/" + lctName + " %s %s %s=%s > extractAOLlog.log 2>&1;%s" % (
                        "\"" + ldt_FileName + "\"", QA_CHARS, CHAR_ID, hiddenplanId,nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                        migLogFile.write("Execution with Normal user is completed.\n")
            # Any other object type
            else:
                print "Inside else..."
                migLogFile.write("Inside else...\n")
                if sudoToUser != "sudoToUser-no":
                    print "Executing with Sudo user..."
                    migLogFile.write("Executing with Sudo user...\n")
                    command = "%s ' %s cd /home/%s; cd %s/%s; %s FNDLOAD " + appsDetails + " 0 Y DOWNLOAD $FND_TOP/patch/115/import/%s %s  > extractAOLlog.log 2>&1;%s'" % (
                        connectToSudoCmd, envFileCommand ,sudoToUser, downloadBasepath, objectDir, nlsLangRevertSetting, appsDetails, lctName, "\"" + objectName + "\"",nlsLangRevertSetting)
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Sudo user is completed."
                        migLogFile.write("Execution with Sudo user is completed.\n")
                else:
                    print "Executing with Normal user..."
                    migLogFile.write("Executing with Normal user...\n")
                    command = envFileCommand + " cd " + downloadBasepath + "/" + objectDir + "; "+nlsLangSettingValue+ "FNDLOAD " + appsDetails + " 0 Y DOWNLOAD $FND_TOP/patch/115/import/" + lctName + " " + "\"" + objectName + "\"" + " > extractAOLlog.log 2>&1;"+nlsLangRevertSetting
                    exit_status = createChannelAndExecuteCommand(command)
                    if exit_status == 0:
                        print "Execution with Normal user is completed."
                        migLogFile.write("Execution with Normal user is completed.\n")
    elif(pythonTarget == "DOWNLOAD_ORACLE_FORMS_AND_REPORTS"):
            try:
                print "Inside DOWNLOAD_ORACLE_FORMS_AND_REPORTS"
                migLogFile.write("Inside DOWNLOAD_ORACLE_FORMS_AND_REPORTS\n")
                createDirectory()
                copy()
                remotedir = downloadBasepath + "/" + objectDir + "/"
                print "remotedir:" + remotedir
                migLogFile.write("remotedir:" + remotedir + "\n")
                localdir = ldtDownloadPath
                print "localdir:" + localdir
                migLogFile.write("localdir:" + localdir + "\n")
                command = "pwd ; whoami > extractAOLlog1.log 2>&1"
                exit_status = createChannelAndExecuteCommand(command)
                if exit_status == 0:
                    #Copying objects from Target instance to TRI2 server
                    sftp = ssh.open_sftp( )
                    remoteFiles = sftp.listdir( path=remotedir )
                    if len(remoteFiles) != 0:
                        print remoteFiles
                        migLogFile.write(str(remoteFiles) + "\n")
                        for files in remoteFiles:
                            #print files
                            if fnmatch.fnmatchcase( files, "\"" + objectName + "\"" ):
                                sftp.get( remotedir + files, localdir + files )
            except Exception as logObjectCopyException:
                print logObjectCopyException
                migLogFile.write("logObjectCopyException : " + str(logObjectCopyException) + "\n")
                print("No objects download at " + downloadBasepath + "/" + objectDir + "/" + "\"" + objectName + "\"")
                migLogFile.write("No objects download at " + downloadBasepath + "/" + objectDir + "/" + "\"" + objectName + "\"" + "\n")

    #Copying objects and log files from Target instance to TRI2 server
    try:
        remotedir = downloadBasepath + "/" + objectDir + "/"
        localdir  = ldtDownloadPath + "/"
        print "remotedir:" + remotedir
        migLogFile.write("remotedir:" + remotedir + "\n")
        print "localdir:" + localdir
        migLogFile.write("localdir:" + localdir + "\n")
        print "Copying object and logs..."
        migLogFile.write("Copying object and logs...\n")
        command = "pwd > extractAOLlog1.log 2>&1"
        exit_status = createChannelAndExecuteCommand(command)
        if exit_status == 0:
            sftp = ssh.open_sftp( )
            remoteFiles = sftp.listdir( path=remotedir )
            if len(remoteFiles) != 0:
                print remoteFiles
                migLogFile.write(str(remoteFiles) + "\n")
                for files in remoteFiles:
                    if fnmatch.fnmatch(files, '*' + objectName + '*.*'):
                        #print "File name in Copying object:" + files
                        sftp.get( remotedir + files, localdir + files )
                    if fnmatch.fnmatch( files,'*.log' ):
                        #print "File name in Copying logs:" + files
                        sftp.get( remotedir + files, localdir + files)
            print "Copied object and logs"
            migLogFile.write("Copied object and logs \n")
    except Exception as copyObjectException:
        print copyObjectException
        migLogFile.write(str(copyObjectException) + "\n")
        print("Problem occur while copying!")
        migLogFile.write("Problem occur while copying!\n")

except Exception as downloadObjectException:
    print "Exception while downloading object:" , downloadObjectException
    migLogFile.write("Exception while downloading object:" + str(downloadObjectException) + "\n")
finally:
    try:
        if connection_status == 0:
            remotedir = downloadBasepath + "/" + objectDir + "/"
            localdir = ldtDownloadPath
            print "remotedir:" + remotedir
            migLogFile.write("remotedir:" + remotedir + "\n")
            print "localdir:" + localdir
            migLogFile.write("localdir:" + localdir + "\n")
            sftp = ssh.open_sftp( )
            remoteFiles = sftp.listdir( path=remotedir )
            if len(remoteFiles) != 0:
                print remoteFiles
                migLogFile.write(str(remoteFiles) + "\n")
                for files in remoteFiles:
                    if fnmatch.fnmatch(files, '*' + "\"" + objectName + "\"" + '*.*'):
                        #print "File name in Copying object:" + files./MIG_TOOL/Download/XXGSI_OEXOEACK_TRI2_TEST/
                        sftp.get( remotedir + files, localdir + files )
            #Deleting directory once all the processing is completed.
            deleteDirectory()
        else:
            print "Connection not established"
            migLogFile.write("Connection not established\n")

        if sftp:
            sftp.close()
        if ssh:
            ssh.close()
    except Exception as e:
            print("No object to download at " + downloadBasepath + "/" + objectDir + "/" + "\"" + objectName + "\"")
            migLogFile.write("No object to download at " + downloadBasepath + "/" + objectDir + "/" + "\"" + objectName + "\"" + "\n")
    if migLogFile:
        migLogFile.close()
    sys.exit(1)
