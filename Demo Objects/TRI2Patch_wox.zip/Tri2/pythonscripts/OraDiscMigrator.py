import StringIO
import fnmatch
import socket
import sys
import time
import select
import shutil

import paramiko
import os


try:
    print 'Number of arguments:', len(sys.argv), 'arguments.'
    #destinationPassword was also getting printed in TRI2 logs so commented the below statement.
    #print 'Argument List:', str(sys.argv)

    objectType = sys.argv[1]
    objVersion = sys.argv[2]
    destinationuserName = sys.argv[3]
    destinationPassword = sys.argv[4]
    destinationIP = sys.argv[5]
    destinationPortNumber = sys.argv[6]
    logFileName = sys.argv[7]
    objectDir = sys.argv[8]
    eexLocation = sys.argv[9]
    objectName = sys.argv[10]
    objectType = sys.argv[11]
    appsDetails = sys.argv[12]
    eulName = sys.argv[13]
    uploadbasetargetDir = sys.argv[14]
    logFilePath = sys.argv[15]
    connectToSudoCmd = sys.argv[16]
    isSudoUser = sys.argv[17]
    sudoToUser = sys.argv[18]
    envFileCommand = sys.argv[19]
    instanceName = sys.argv[20]
    keyFilePath     = sys.argv[21]
    contents = StringIO.StringIO()
    error = StringIO.StringIO()
    logfile = "extractAOLlog.log"
    migrationLogFile = open(logFileName, "a")

    print "objectType:" + objectType + ", objVersion:" + objVersion + ", destinationuserName:" + destinationuserName + ", destinationIP:" + destinationIP + ", destinationPortNumber:" + destinationPortNumber + ", logFileName:" + logFileName + ", objectDir:" + objectDir + ", eexLocation:" + eexLocation + ", objectType:" + objectType + ", objectName:" + objectName + ", appsDetails:" + appsDetails + ", eulName:" + eulName + ", uploadbasetargetDir:" + uploadbasetargetDir + ", logFilePath:" + logFilePath + ", connectToSudoCmd:" + connectToSudoCmd + ", isSudoUser:" + isSudoUser + ", sudoToUser:" + sudoToUser + ", envFileCommand:" + envFileCommand + ", instanceName:" + instanceName
    print "keyFilepath " + keyFilepath
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    if destinationPassword == "null":
        print "Connecting to target instance through keyfile"
        migrationLogFile.write("Connecting to target instance through keyfile...\n")
        private_key = os.path.expanduser(keyFilePath)
        print private_key
        ssh.connect(destinationIP, username=destinationuserName, key_filename=private_key)
        migrationLogFile.write("Connected to target instance through keyfile...\n")
    else:
        print "Connecting to target instance through password"
        migrationLogFile.write("Connecting to target instance through password...\n")
        ssh.connect(destinationIP, username=destinationuserName, password=destinationPassword)
        migrationLogFile.write("Connected to target instance through password...\n")
    print "objectName:" + objectName

    def Copy():
        remotedir = uploadbasetargetDir + "/" + objectDir + "/"
        localdir = logFilePath + "/"
        print "remotedir:" + remotedir + ", localdir:" + localdir
        sftp = ssh.open_sftp()
        remoteFiles = sftp.listdir(path=remotedir)
        for files in remoteFiles:
            if fnmatch.fnmatch(files, "*.log"):
                sftp.get(remotedir + files, localdir + files)

    def CopytoTarget():
        localdir = eexLocation + "/"
        remotedir = uploadbasetargetDir + "/" + objectDir + "/"
        print "remotedir:" + remotedir + ", localdir:" + localdir
        sftp = ssh.open_sftp()
        remoteFiles = sftp.listdir(path=remotedir)
        localFiles = os.listdir(localdir)
        for files in localFiles:
            print "files:" + files
            if fnmatch.fnmatchcase(files, objectName):
                sftp.put(localdir + files, remotedir + files )
    def writingLogs():
        remotedir = uploadbasetargetDir + "/" + objectDir + "/"
        localdir = eexLocation + "/"
        print "remotedir:" + remotedir + ", localdir:" + localdir
        sftp = ssh.open_sftp()
        remoteFiles = sftp.listdir(path=remotedir)
        for files in remoteFiles:
            print "files:" + files
            if fnmatch.fnmatchcase(files, 'importOraDisclog.log'):
                sftp.get(remotedir + files, localdir + files)
        f = open(localdir + "importOraDisclog.log")
        for line in f.readlines():
            migrationLogFile.write(line)
        f.close()

# This method is useful for deleting any files or directories in TRI2 local Directory
    def deleteOraDiscLogFromLocal(path):
        print "path:" + path
        localFiles = os.listdir(path)
        for files in localFiles:
            print "files:" + files
            if fnmatch.fnmatchcase(files, 'importOraDisclog.log'):
                print " inside if "
                os.unlink(path + files)
            else:
                print "Unable to delete importOraDisclog.log:" + path + files

    def deletingLogs():
        command = "rm -rf " + uploadbasetargetDir + "/" + objectDir + "/"
        channelCreation(command)

    def channelCreation(command):
        Channel = ssh.get_transport().open_session()
        Channel.get_pty()
        Channel.settimeout(1080)
        Channel.exec_command(command)
        return Channel.recv_exit_status()

    migrationLogFile.write("Creating object directory " + uploadbasetargetDir + "/" + objectDir + "  and providing chmod 777 permission to object directory. \n")
    print "Creating directory..."
    command = "mkdir -p  " + uploadbasetargetDir + "/" + objectDir + " ; chmod -R 777 " + uploadbasetargetDir + "/" + objectDir + ";whoami"
    channelCreation(command)
    print "Created directory"
    migrationLogFile.write("Object directory is Successfully created and provided chmod 777 permission to object directory.\n")

    print "Copying to Target..."
    migrationLogFile.write("Copying " + objectName + " to " + uploadbasetargetDir + "/" + objectDir + "  \n")
    CopytoTarget()
    migrationLogFile.write("" + objectName + " is Copied Successfully \n")
    print "Copied to Target"

    print "Providing chmod permission to directory"
    migrationLogFile.write("Providing chmod 777 permission to  " + objectName + " \n")
    command = "chmod -R 777 " + uploadbasetargetDir + "/" + objectDir + "/" + objectName + ";whoami"
    channelCreation(command)
    migrationLogFile.write("Provided chmod 777 permission to  " + objectName + " \n \n")

except Exception as copyObjectException:
    print "Exception:"
    print copyObjectException
    migrationLogFile.write(str(copyObjectException))

finally:
    print "Logic entered into finally!"

try:

    if sudoToUser != "null" and sudoToUser != "" and sudoToUser != "null":
        print "Inside Migration Logic, Sudo "
        migrationLogFile.write("..................."+ objectName + " migration started.....................\n\n")
        command = "%s whoami; cd /home/%s; pwd; . .bash_profile;%s eulapi -connect %s  -eul %s -import %s/%s/%s -identifier -preserve_workbook_owner -import_rename_mode refresh -auto_refresh -log  %s/%s/importOraDisclog.log;whoami; %s chmod -R 777 %s/%s/importOraDisclog.log" % (
        connectToSudoCmd, sudoToUser, connectToSudoCmd, appsDetails, eulName, uploadbasetargetDir, objectDir,
        objectName,
        uploadbasetargetDir, objectDir, connectToSudoCmd, uploadbasetargetDir, objectDir)
        exit_status =  channelCreation(command)
        print "exit_status after import:", exit_status
        if exit_status == 0:
            migrationLogFile.write(objectName + " Import Completed...\n")
            migrationLogFile.write("Providing chmod 777 permission to importOraDisclog.log \n")
            command = "%s chmod -R 777 %s/%s/importOraDisclog.log"% (connectToSudoCmd,uploadbasetargetDir, objectDir)
            exit_status = channelCreation(command)
            print "exit_status after Providing chmod 777 permission to importOraDisclog:", exit_status
            if exit_status == 0:
                migrationLogFile.write("Provided chmod 777 permission to importOraDisclog.log \n")
                migrationLogFile.write("Copying Log file to  " + logFilePath + " \n")
                Copy()
                migrationLogFile.write("Logs file copied \n \n")
                migrationLogFile.write("..................." + objectName + " migration completed.....................\n\n")
            else:
                migrationLogFile.write("Unable to provide chmod 777 permission to importOraDisclog.log.")
        else:
            migrationLogFile.write("Unable to Import " + objectName + " Properly in target instance.")

    else:
        print "Inside Migration Logic"
        migrationLogFile.write("..................." + objectName + " migration started.....................\n\n")
        command = "pwd; . .bash_profile; eulapi -connect " + appsDetails + " -eul " + eulName + " -import " + uploadbasetargetDir + "/" + objectDir + "/" + objectName + " -identifier -preserve_workbook_owner -import_rename_mode refresh -auto_refresh -log " + uploadbasetargetDir + "/" + objectDir + "/importOraDisclog.log; chmod -R 777 " + uploadbasetargetDir + "/" + objectDir + "/importOraDisclog.log"
        exit_status = channelCreation(command)
        print "exit_status after import:", exit_status
        if exit_status == 0:
            migrationLogFile.write(objectName + " Import Completed...\n")
            migrationLogFile.write("Providing chmod 777 permission to importOraDisclog.log \n")
            command = "pwd; . .bash_profile; chmod -R 777 " + uploadbasetargetDir + "/" + objectDir + "/importOraDisclog.log"
            exit_status = channelCreation(command)
            print "exit_status after Providing chmod 777 permission to importOraDisclog:", exit_status
            if exit_status == 0:
                migrationLogFile.write("Provided chmod 777 permission to importOraDisclog.log \n")
                migrationLogFile.write("Copying Log file to " + logFilePath + " Directory \n")
                Copy()
                migrationLogFile.write("Log file copied \n \n")
                migrationLogFile.write("..................." + objectName + " migration completed.....................\n\n")
            else:
                migrationLogFile.write("Unable to provide chmod 777 permission to importOraDisclog.log.")
        else:
            migrationLogFile.write("Unable to Import " + objectName + " Properly in target instance.")
except Exception as migrationException:
    print "Migration Exception:"
    print migrationException
    migrationLogFile.write(str(migrationException))

finally:
    print "Executing deletingLogs()...."
    Copy()
    deletingLogs()
    print "Executed deletingLogs()."
    migrationLogFile.close()
    ssh.close()
    sys.exit(1)