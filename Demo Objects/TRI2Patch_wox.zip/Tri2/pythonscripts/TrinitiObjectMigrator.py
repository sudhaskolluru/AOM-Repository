import StringIO
import fnmatch
import socket
import sys
import time
import select
import shutil
#from turtle import done

import paramiko
import os
import zipfile

try:
    print 'Number of arguments:', len(sys.argv), 'arguments.'
    #destinationPassword was also getting printed in TRI2 logs so commented the below statement.
    #print 'Argument List:', str(sys.argv)
    deployPath      = sys.argv[1]
    instanceName    = sys.argv[2]
    destinationuserName = sys.argv[3]
    destinationPassword = sys.argv[4]
    destinationIP       = sys.argv[5]
    instancePortNumber  = sys.argv[6]
    logFilePath         = sys.argv[7]
    targetInstancePath  = sys.argv[8]
    sourceFilePath  = sys.argv[9]
    objectName      = sys.argv[10]
    antTarget       = sys.argv[11]
    objectType      = sys.argv[12]
    objectDir       = sys.argv[13]
    objectNameDir   = sys.argv[14]
    keyFilePath        = sys.argv[15]

    print "deployPath:" + deployPath
    print "instanceName:" + instanceName
    print "destinationuserName:" + destinationuserName
    # print "destinationPassword:" + destinationPassword
    print "destinationIP:" + destinationIP
    print "instancePortNumber:" + instancePortNumber
    print "logFilePath:" + logFilePath
    print "targetInstancePath:" + targetInstancePath
    print "sourceFilePath:" + sourceFilePath
    print "objectName:" + objectName
    print "antTarget:" + antTarget
    print "objectType:" + objectType
    print "objectDir:" + objectDir
    print "objectNameDir: " + objectNameDir
    print "key file path: " + keyFilePath

    # Opening migration notification mail log file to write logs
    migrationLogFile = open(logFilePath, "a")

    # Creating channel and executing passed command
    def createChannelAndExecuteCommand(command):
        Channel = ssh.get_transport().open_session()
        Channel.get_pty()
        Channel.settimeout(1080)
        Channel.exec_command(command)
        Channel.exit_status = Channel.recv_exit_status()
        return Channel.exit_status

    # Writing content of extractAOLlog.log file content to migration notification mail
    def writingLogs():
        remotedir = targetInstancePath + "/"
        localdir = sourceFilePath + "/"

        print  "remotedir:" + remotedir
        print  "localdir:" + localdir

        sftp = ssh.open_sftp()
        remoteFiles = sftp.listdir(path=remotedir)
        for files in remoteFiles:
            #print "files:" + files
            if fnmatch.fnmatchcase(files, 'extractAOLlog.log'):
                sftp.get(remotedir + files, localdir + files)
        f = open(localdir + "extractAOLlog.log")
        for line in f.readlines():
            #print "line:" + line
            migrationLogFile.write(line)
            f.close()

    def errorMessage(Channel):
        while not Channel.exit_status_ready():
            if Channel.recv_ready():
                data = Channel.recv(1024)
                while data:
                    migrationLogFile.write(data)
                    data = Channel.recv(1024)

            if Channel.recv_stderr_ready():
                error_buff = Channel.recv_stderr(1024)
                while error_buff:
                    migrationLogFile.write(error_buff)
                    error_buff = Channel.recv_stderr(1024)
            exit_status = Channel.recv_exit_status()
        return exit_status

    # Deleting extractAOLlog.log file
    def deletingLogs():
        command = "rm -rf " + targetInstancePath + "/extractAOLlog.log"
        exit_status = createChannelAndExecuteCommand(command)
        print "exit_status after deleting log file:" , exit_status

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    if destinationPassword == "null":
        print "Connecting to target instance through keyfile"
        migrationLogFile.write("Connecting to target instance through keyfile...\n")
        private_key = os.path.expanduser(keyFilePath)
        print private_key
        ssh.connect(destinationIP, username=destinationuserName, key_filename=private_key)
        migrationLogFile.write("Connected to target instance through keyfile...\n")
    else:
        print "Connecting through password"
        migrationLogFile.write("Connecting to target instance through password...\n")
        ssh.connect(destinationIP, username=destinationuserName, password=destinationPassword)
        migrationLogFile.write("Connected to target instance through password...\n")
    chan1 = ssh.get_transport().open_session()
    chan1.get_pty()
    chan1.settimeout(1080)
    chan1.exec_command("mkdir -p " + targetInstancePath)
    chan1.exit_status = chan1.recv_exit_status()

    if objectType == "AUTONUMBER":
        absolutePath = targetInstancePath + "/" + objectDir
        print "absolutePath:" + absolutePath
        migrationLogFile.write("Creating " + absolutePath + " in target instance...\n")
        command = "mkdir -p " + absolutePath + " >  " + targetInstancePath + "/extractAOLlog.log 2>&1"
    else:
        command = "mkdir -p " + targetInstancePath + "/GPSPatches/" + objectNameDir + " >  " + targetInstancePath + "/extractAOLlog.log 2>&1"
    exit_status = createChannelAndExecuteCommand(command)
    print "exit_status after calling mkdir command:" , exit_status
    if exit_status == 0:
    	if objectType == "AUTONUMBER":
    		migrationLogFile.write("Created " + absolutePath + " in target instance.\n\n")

    sftp = ssh.open_sftp()
    print sftp
    if objectType == "UPGRADE_PACK":
        sftp.put(sourceFilePath + "/" + objectName, targetInstancePath + "/" + objectName)
        print objectName + " is Copied Successfully."
    if objectType == "AUTONUMBER":
        sftp.put(sourceFilePath + "/" + objectName, absolutePath + "/" + objectName)
    else:
        sftp.put(sourceFilePath + "/" + objectName, targetInstancePath + "/" + objectName)

except Exception as copyObjectException:
    print copyObjectException
    migrationLogFile.write("Exception:")
    migrationLogFile.write(str(copyObjectException))

try:
    if (antTarget == "TRINITI_OBJECTS") and (objectType != "AUTONUMBER"):
        if objectType == "UPGRADE_PACK":
            print "UPGRADE_PACK migration started...\n"
            print objectName + " migration started...\n"
            migrationLogFile.write(objectName + " migration started...\n\n")
            command = "cd " + targetInstancePath + ";  java UpgradePackExecutor " + targetInstancePath + " " + objectName + " >  " + targetInstancePath + "/extractAOLlog.log 2>&1 "
            print "Prepared command:" + command
            exit_status = createChannelAndExecuteCommand(command)
            print "exit_status after calling command for executing of UpgradePackExecutor:" , exit_status
            writingLogs()
            migrationLogFile.write(objectName + " migration completed.\n\n")
            print objectName + " migration completed."
            print "UPGRADE_PACK migration completed."
        else:
            print "TRINITI_OBJECTS migration started..."
            print objectName + " migration started..."
            migrationLogFile.write(objectName + " migration started...\n\n")
            migrationLogFile.write("Deleting " + objectName + " in target instance...\n")
            command = "rm -rf " + targetInstancePath + "/GPSPatches/" + objectNameDir + " > " + targetInstancePath + "/extractAOLlog.log 2>&1"
            exit_status = createChannelAndExecuteCommand(command)
            print "exit_status after deletion:" , exit_status
            writingLogs()
            if exit_status == 0:
            	migrationLogFile.write("Deleted " + objectNameDir + " in target instance \n\n")
            	migrationLogFile.write("Creating " + objectNameDir + " in target instance...\n")
                command = "mkdir -p " + targetInstancePath + "/GPSPatches/" + objectNameDir + " > " + targetInstancePath + "/extractAOLlog.log 2>&1"
                exit_status = createChannelAndExecuteCommand(command)
                print "exit_status after creation:" , exit_status
                writingLogs()
                if exit_status == 0:
                    migrationLogFile.write("Created " + objectNameDir + " in target instance \n\n")
                    migrationLogFile.write("Extracting " + objectName + " in target instance...\n")
                    command = "cd " + targetInstancePath + "/ ; unzip '" + objectName + "' -d " + targetInstancePath + "/GPSPatches/" + objectNameDir + " > " + targetInstancePath + "/extractAOLlog.log 2>&1"
                    exit_status = createChannelAndExecuteCommand(command)
                    print "exit_status after extraction:" , exit_status
                    writingLogs()
                    if exit_status != 0:
                        migrationLogFile.write("Unable to extract " + objectName + " in target instance. \n\n")
                    else:
                        migrationLogFile.write("Extracted " + objectName + " in target instance. \n\n")
                else:
                    migrationLogFile.write("Unable to create " + objectNameDir + " in target instance. \n\n")
            else:
                migrationLogFile.write("Unable to delete " + objectNameDir + " in target instance. \n\n")
            #migrationLogFile.write(objectName + " execution command completed.\n")
            print objectName + " execution command completed."
            print "TRINITI_OBJECTS execution command completed"

    elif antTarget == "TRINITI_PATCH":
        print "TRINITI_PATCH execution command started... "
        print objectName + " execution command started..."
        migrationLogFile.write(objectName + " execution command started...\n\n")
        migrationLogFile.write("Deleting " + objectNameDir + " in target instance \n")
        command = "rm -rf '" + targetInstancePath + "/GPSPatches/" + objectNameDir + "' > " + targetInstancePath + "/extractAOLlog.log 2>&1"
        exit_status = createChannelAndExecuteCommand(command)
        print "exit_status after deletion:" , exit_status
        writingLogs()
        if exit_status == 0:
       	    migrationLogFile.write("Deleted " + objectNameDir + " in target instance. \n\n")
       	    migrationLogFile.write("Creating " + objectNameDir + " in target instance... \n")
            command = "mkdir -p '" + targetInstancePath + "/GPSPatches/" + objectNameDir + "' > " + targetInstancePath + "/extractAOLlog.log 2>&1"
            exit_status = createChannelAndExecuteCommand(command)
            writingLogs()
            print "exit_status after creation:" , exit_status
            if exit_status == 0:
                migrationLogFile.write("Created " + objectNameDir + " in target instance. \n\n")
                migrationLogFile.write("Extracting " + objectName + " in target instance... \n")
                command = ". ~/.bash_profile;cd " + targetInstancePath + "/ ; unzip '" + objectName + "' -d '" + targetInstancePath + "/GPSPatches/" + objectNameDir + "' > " + targetInstancePath + "/extractAOLlog.log 2>&1"
                exit_status = createChannelAndExecuteCommand(command)
                print "exit_status after extraction:" , exit_status
                writingLogs()
                if exit_status == 0:
                    migrationLogFile.write("Extracted " + objectName + " in target instance. \n\n")
                    migrationLogFile.write("Executing build.xml of Triniti patch... \n")
                    command = ". ~/.bash_profile;cd " + targetInstancePath + "/GPSPatches/" + objectNameDir + "; ant -buildfile build.xml -Dbuild.dir='" + targetInstancePath + "/GPSPatches/" + objectNameDir + "' -Ddeploy.path='" + deployPath + "' > " + targetInstancePath + "/extractAOLlog.log 2>&1"
                    exit_status = createChannelAndExecuteCommand(command)
                    print "exit_status after executing build.xml:" , exit_status
                    writingLogs()
                    if exit_status != 0:
                        migrationLogFile.write("Unable to execute build.xml of Triniti patch. \n\n")
                    else:
                        migrationLogFile.write("Executed build.xml of Triniti patch. \n\n")
                else:
                    migrationLogFile.write("Unable to extract " + objectName + " in target instance. \n\n")
            else:
                migrationLogFile.write("Unable to create " + objectNameDir + " in target instance. \n\n")
        else:
            migrationLogFile.write("Unable to delete " + objectNameDir + " in target instance. \n\n")
        #migrationLogFile.write(objectName + " execution command completed.")
        print objectName + " migration completed."
        print "TRINITI_PATCH migration completed."

except Exception as migrationException:
    print migrationException
    migrationLogFile.write("Migration Exception: ")
    migrationLogFile.write(str(migrationException))

finally:
    deletingLogs()
    migrationLogFile.close()
    ssh.close()
    sys.exit(1)