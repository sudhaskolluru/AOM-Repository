import StringIO
import fnmatch
import socket
import sys
import time
import select
import shutil
import traceback


import paramiko
import os

print 'Number of arguments:', len(sys.argv), 'arguments.'
#destinationPassword was also getting printed in TRI2 logs so commented the below statement.
#print 'Argument List:', str(sys.argv)

try:
    instanceName = sys.argv[1]
    objectType   = sys.argv[2]
    formApplicationtop   = sys.argv[3]
    applicationShortName = sys.argv[4]
    formName             = sys.argv[5]
    migReqProjectName    = sys.argv[6]
    oracleReleaseVersion = sys.argv[7]
    password        = sys.argv[8]
    objVersion      = sys.argv[9]
    destinationIP   = sys.argv[10]
    destinationuserName = sys.argv[11]
    destinationPassword = sys.argv[12]
    destinationPort     = sys.argv[13]
    objectName = sys.argv[14]
    schemaName = sys.argv[15]
    schemaPassword = sys.argv[16]
    instaceSid = sys.argv[17]
    isSudoUser = sys.argv[18]
    sudoToUser = sys.argv[19]
    envFileCommand     = sys.argv[20]
    targetInstancePath = sys.argv[21]
    createTargetPathIfNotExists = sys.argv[22]
    DosToUnixConvFlag  = sys.argv[23]
    destination_dbIp   = sys.argv[24]
    destination_dpPort = sys.argv[25]
    destination_dbsid  = sys.argv[26]
    objectDir   = sys.argv[27]
    fileNameStr = sys.argv[28]
    logFilePath = sys.argv[29]
    appsDetails = sys.argv[30]
    copyWithPermissionsAndConversionFlag = sys.argv[31]
    copyWithPermissionsFlag = sys.argv[32]
    copyWithConversionFlag  = sys.argv[33]
    auTopDir         = sys.argv[34]
    connectToSudoCmd = sys.argv[35]
    spaceSeparatedArguments = sys.argv[36]
    copyToPatchFileSystem   = sys.argv[37]
    patchFileSystemEnvFile  = sys.argv[38]
    copyToBothFileSystems   = sys.argv[39]
    glassfishPasswordFileDirectory = sys.argv[40]
    glassfishServerHomePath = sys.argv[41]
    glassfishServerHost     = sys.argv[42]
    glassfishServerPort     = sys.argv[43]
    glassfishServerUserName = sys.argv[44]
    migrationRequestNumber  = sys.argv[45]
    shellScriptFiles = sys.argv[46]
    #lastIndex = envFileCommand.rfind(';')
    #envFileCommand = envFileCommand[0:lastIndex]
    keyFilePath          = sys.argv[47]


    print "instanceName:" + instanceName
    print "objectType:" + objectType
    print "formApplicationtop:" + formApplicationtop
    print "applicationShortName:" + applicationShortName
    print "formName:" + formName
    print "migReqProjectName:" + migReqProjectName
    print "oracleReleaseVersion:" + oracleReleaseVersion
    #print "password:" + password
    print "destinationIP:" + destinationIP
    print "destinationuserName:" + destinationuserName
    #print "destinationPassword:" + destinationPassword
    print "destinationPort:" + destinationPort
    print "objectName:" + objectName
    print "schemaName:" + schemaName
    #print "schemaPassword:" + schemaPassword
    print "instaceSid:" + instaceSid
    print "isSudoUser:" + isSudoUser
    print "sudoToUser:" + sudoToUser
    print "envFileCommand:" + envFileCommand
    print "targetInstancePath:" + targetInstancePath
    print "createTargetPathIfNotExists:" + createTargetPathIfNotExists
    print "DosToUnixConvFlag:" + DosToUnixConvFlag
    print "destination_dbIp:" + destination_dbIp
    print "destination_dpPort:" + destination_dpPort
    print "destination_dbsid:" + destination_dbsid
    print "objectDir:" + objectDir
    print "fileNameStr:" + fileNameStr
    print "logFilePath:" + logFilePath
    print "appsDetails:" + appsDetails
    print "copyWithPermissionsAndConversionFlag:" + copyWithPermissionsAndConversionFlag
    print "copyWithPermissionsFlag:" + copyWithPermissionsFlag
    print "copyWithConversionFlag:" + copyWithConversionFlag
    print "auTopDir:" + auTopDir
    print "connectToSudoCmd:" + connectToSudoCmd
    print "spaceSeparatedArguments:" + spaceSeparatedArguments
    print "copyToPatchFileSystem:" + copyToPatchFileSystem
    print "patchFileSystemEnvFile:" + patchFileSystemEnvFile
    print "copyToBothFileSystems:" + copyToBothFileSystems
    print "glassfishPasswordFileDirectory:" + glassfishPasswordFileDirectory
    print "glassfishServerHomePath:" + glassfishServerHomePath
    print "glassfishServerHost:" + glassfishServerHost
    print "glassfishServerPort:" + glassfishServerPort
    print "glassfishServerUserName:" + glassfishServerUserName
    print "migrationRequestNumber:" + migrationRequestNumber
    print "shellScriptFiles:" + shellScriptFiles
    print "key File path:" + keyFilePath

    default = "defaultFile"
    oraclePatchDefaultFileDirectory = "oraclePatchDefaultFileDirectory"
    contents = StringIO.StringIO()
    error = StringIO.StringIO()
    logfile = "extractAOLlog.log"
    migrationLogFile = open(logFilePath, "a")
    indexOfMigrationResults = logFilePath.index("MigrationResults")
    localInstancePath = logFilePath[0:indexOfMigrationResults]+"shellscripts/"
    softlinkShellScript = "softlink.sh"
    isCopiedSuccessfully = False
    isSoftLinkCreated = False
    targetInstancePathWithoutDot = targetInstancePath.lstrip(".")
    if objectType == "ORACLE_FORM_LIBRARIES":
        auTopDir = "$AU_TOP/resource"

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    print "Creating ssh connection to target instance..."
    if destinationPassword == "null":
        print "Connecting to target instance through keyfile"
        migrationLogFile.write("Connecting to target instance through keyfile...\n")
        private_key = os.path.expanduser(keyFilePath)
        ssh.connect(destinationIP, username=destinationuserName, key_filename=private_key)
        migrationLogFile.write("Connected to target instance through keyfile...\n")
    else:
        print "Connecting to target instance through password"
        migrationLogFile.write("Connecting to target instance through password...\n")
        ssh.connect(destinationIP, username=destinationuserName, password=destinationPassword)
        migrationLogFile.write("Connected to target instance through password...\n")

    # Creating channel and executing passed command
    def createChannelAndExecuteCommand(command):
        Channel = ssh.get_transport().open_session()
        Channel.get_pty()
        Channel.settimeout(1080)
        Channel.exec_command(command)
        Channel.exit_status = Channel.recv_exit_status()
        return Channel.exit_status

    # Creating temporary folder in target instance
    command = "mkdir -p  " + targetInstancePath + "/" + objectDir + "/"
    exit_status =  createChannelAndExecuteCommand(command)

    def writingLogs():
        if objectType == "EXECUTE_SHELL SCRIPT" or objectType == "SOFTLINK":
            remotedir = targetInstancePath + "/" + objectDir + "/"
        else:
         remotedir = targetInstancePath + "/"
        localdir = fileNameStr + "/"
        print "remotedir:" + remotedir + ", localdir:" + localdir
        sftp = ssh.open_sftp()
        remoteFiles = sftp.listdir(path=remotedir)
        for files in remoteFiles:
            #print "files:" + files
            if fnmatch.fnmatchcase(files, 'extractAOLlog.log'):
                sftp.get(remotedir + files, localdir + files)
        f = open(localdir + "extractAOLlog.log")
        for line in f.readlines():
            print "line:" + line
            migrationLogFile.write(line)
        f.close()

    def deletingLogs():
        command = "rm -rf " + targetInstancePath + "/extractAOLlog.log"
        createChannelAndExecuteCommand(command)

    # Copying object from TRI2 server to temporary folder in target instance
    sftp = ssh.open_sftp()
    print sftp
    sftp.put(fileNameStr + "/" + objectName, targetInstancePath + "/" + objectDir + "/" + objectName)
    if objectType == "EAR_FILE":
        sftp.put(glassfishPasswordFileDirectory + "/" + migrationRequestNumber + "_GlassfishServerConfig/GlassfishServerConfig.txt", targetInstancePath + "/" + objectDir + "/" + "GlassfishServerConfig.txt")
    if objectType == "SOFTLINK":
        sftp.put(localInstancePath + softlinkShellScript, targetInstancePath + "/" + objectDir + "/" + softlinkShellScript)

    try:
        if isSudoUser == "Yes":
            command = "pwd; " + envFileCommand + " chmod 777 " + targetInstancePath + "/" + objectDir + "/"
            command2 = "pwd; " + envFileCommand + " chmod 777 " + targetInstancePath
            exit_status = createChannelAndExecuteCommand(" " + command + " " + command2)

        if spaceSeparatedArguments == "null":
            spaceSeparatedArguments = ""
        print "spaceSeparatedArguments after modification from null to empty:" + spaceSeparatedArguments

        #IS091768 -Shellscript is not getting executed as expected when input arguments are provided through AOM tool
        if spaceSeparatedArguments.startswith("\"") and spaceSeparatedArguments.endswith("\""):
            spaceSeparatedArguments = spaceSeparatedArguments[1:(len(spaceSeparatedArguments) - 1)]
        print "spaceSeparatedArguments after removing double quotes in both ends:" + spaceSeparatedArguments

        if envFileCommand == "null":
            envFileCommand = ""
        print "envFileCommand after modification:" + envFileCommand

        if patchFileSystemEnvFile == "null":
            patchFileSystemEnvFile = ""
        print "patchFileSystemEnvFile after modification:" + patchFileSystemEnvFile

        if copyToBothFileSystems == "null":
            copyToBothFileSystems = ""
        print "copyToBothFileSystems after modification:" + copyToBothFileSystems

        # IS091926 - Migration is getting failed for Copy, Copy and Extract objects if target path contains space and Create Target Path If Not Exists option is selected (If Target Path is not available).
        # "COPY" object type
        if objectType == "COPY":
            print "createTargetPathIfNotExists:" + createTargetPathIfNotExists
            if createTargetPathIfNotExists == "Y":
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "inside createTargetPathIfNotExists, if block...."
                    command = " %s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; mkdir -p %s > %s/%s 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"", "\"" + formApplicationtop + "\"" , targetInstancePath, logfile)
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside createTargetPathIfNotExists, if block completed!"
                else:
                    print "inside createTargetPathIfNotExists, else block...."
                    command = " pwd; " + envFileCommand + " pwd; whoami; echo \"" + formApplicationtop + "\"; mkdir -p \"" + formApplicationtop + "\" > " + targetInstancePath + "/" + logfile + " 2>&1 "
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside createTargetPathIfNotExists, else block completed!"

            print "copyWithPermissionsAndConversionFlag:" + copyWithPermissionsAndConversionFlag
            print "copyWithPermissionsFlag:" + copyWithPermissionsFlag
            print "copyWithConversionFlag:" + copyWithConversionFlag
            if copyWithPermissionsAndConversionFlag == "true":
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "inside copyWithPermissionsAndConversionFlag, if block....sudo user...."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; cp %s/%s/%s  %s > %s/%s 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"", targetInstancePath, objectDir, "\"" + objectName + "\"", "\"" + formApplicationtop + "\"", targetInstancePath, logfile)
                    exit_status = createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside copyWithPermissionsAndConversionFlag,sudo user command is completed!"
                    if exit_status == 0:
                        command2 = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; cd %s; chmod 777 %s; dos2unix %s  && echo %s is Copied Successfully. >  %s/%s 2>&1'" % (
                            connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"", "\"" + objectName + "\"", "\"" + objectName + "\"", "\"" + objectName + "\"", targetInstancePath, logfile)
                        createChannelAndExecuteCommand(command2)
                        writingLogs()
                        print "inside copyWithPermissionsAndConversionFlag,sudo user command2 is completed!"
                    print "inside copyWithPermissionsAndConversionFlag, if block sudo user completed!"
                else:
                    print "inside copyWithPermissionsAndConversionFlag, else block....normal user...."
                    command = "pwd; " + envFileCommand + " echo \"" + formApplicationtop + "\"; cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\" \"" + formApplicationtop + "\" > " + targetInstancePath + "/" + logfile + " 2>&1 "
                    exit_status = createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside copyWithPermissionsAndConversionFlag,normal user command is completed!"
                    if exit_status == 0:
                        command2 = "pwd; " + envFileCommand + " cd \"" + formApplicationtop + "\"; chmod 777 \"" + objectName + "\"; dos2unix \"" + objectName + "\" && echo \"" + objectName + "\" is Copied Successfully. > " + targetInstancePath + "/" + logfile + " 2>&1 "
                        createChannelAndExecuteCommand(command2)
                        writingLogs()
                        print "inside copyWithPermissionsAndConversionFlag,normal user command2 is completed!"
                    print "inside copyWithPermissionsAndConversionFlag, else block normal user completed!"
            elif copyWithPermissionsFlag == "true":
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "inside copyWithPermissionsFlag, if block....sudo user...."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; cp %s/%s/%s  %s >  %s/%s 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"", targetInstancePath, objectDir, "\"" + objectName + "\"", "\"" + formApplicationtop + "\"", targetInstancePath, logfile)
                    exit_status = createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside copyWithPermissionsFlag,sudo user command is completed!"
                    if exit_status == 0:
                        command2 = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; cd %s; chmod 777 %s && echo %s is Copied Successfully. > %s/%s 2>&1'" % (
                            connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"", "\"" + objectName + "\"", "\"" + objectName + "\"", targetInstancePath, logfile)
                        createChannelAndExecuteCommand(command2)
                        writingLogs()
                        print "inside copyWithPermissionsFlag,sudo user command2 is completed!"
                    print "inside copyWithPermissionsFlag, if block sudo user completed!"
                else:
                    print "inside copyWithPermissionsFlag, else block....normal user..."
                    command = "pwd; " + envFileCommand + " echo \"" + formApplicationtop + "\"; cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\" \"" + formApplicationtop + "\";  > " + targetInstancePath + "/" + logfile + " 2>&1"
                    exit_status = createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside copyWithPermissionsFlag,normal user command is completed!"
                    if exit_status == 0:
                        command2 = "pwd; " + envFileCommand + " cd \"" + formApplicationtop + "\"; chmod 777 \"" + objectName + "\" && echo \"" + objectName + "\" is Copied Successfully. > $HOME/" + targetInstancePath + "/" + logfile + " 2>&1 "
                        createChannelAndExecuteCommand(command2)
                        writingLogs()
                        print "inside copyWithPermissionsFlag,normal user command2 is completed!"
                    print "inside copyWithPermissionsFlag, else block normal user completed!"
            elif copyWithConversionFlag == "true":
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "inside copyWithConversionFlag, if block....sudo user...."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; cp %s/%s/%s %s > %s/%s 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"", targetInstancePath, objectDir, "\"" + objectName + "\"", "\"" + formApplicationtop + "\"", targetInstancePath, logfile)
                    exit_status = createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside copyWithConversionFlag,sudo user command is completed!"
                    if exit_status == 0:
                        command2 = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; cd %s; dos2unix %s && echo %s is Copied Successfully. > %s/%s 2>&1'" % (
                            connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"", "\"" + formApplicationtop + "\"", "\"" + objectName + "\"", "\"" + objectName + "\"", targetInstancePath, logfile)
                        createChannelAndExecuteCommand(command2)
                        writingLogs()
                        print "inside copyWithConversionFlag,sudo user command2 is completed!"
                    print "inside copyWithConversionFlag, if block sudo user completed!"
                else:
                    print "inside copyWithConversionFlag, else block....normal user...."
                    command = "pwd; " + envFileCommand + " echo \"" + formApplicationtop + "\"; cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\" \"" + formApplicationtop + "\" > $HOME/" + targetInstancePath + "/" + logfile + " 2>&1"
                    exit_status = createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside copyWithConversionFlag,normal user command is completed!"
                    if exit_status ==0:
                        command2 = "pwd; " + envFileCommand + " cd \"" + formApplicationtop + "\"; dos2unix \"" + objectName + "\" && echo \"" + objectName + "\" is Copied Successfully. > $HOME/" + targetInstancePath + "/" + logfile + " 2>&1 "
                        createChannelAndExecuteCommand(command2)
                        writingLogs()
                        print "inside copyWithConversionFlag, normal user command2 is completed!"
                    print "inside copyWithConversionFlag, else block normal user completed!"
            else:
                print "else block in COPY object type"
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "inside COPY, sudo user..."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; cp %s/%s/%s %s > %s/%s 2>&1 && echo %s is Copied Successfully.  >  %s/%s  2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"", targetInstancePath, objectDir, "\"" + objectName + "\"", "\"" + formApplicationtop + "\"", targetInstancePath, logfile  ,"\"" + objectName + "\"", targetInstancePath, logfile)
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside COPY, sudo user completed!"
                else:
                    print "inside COPY, normal user..."
                    command = envFileCommand + " echo \"" + formApplicationtop + "\"; cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\" \"" + formApplicationtop + "\" > " + targetInstancePath + "/" + logfile + " 2>&1 && echo \"" + objectName + "\" is Copied Successfully. > " + targetInstancePath + "/" + logfile + " 2>&1"
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside COPY, normal user completed!"

        # IS091926 - Migration is getting failed for Copy, Copy and Extract objects if target path contains space and Create Target Path If Not Exists option is selected (If Target Path is not available).
        # "COPY AND EXTRACT" object type
        elif objectType == "COPY AND EXTRACT":
            print "inside COPY AND EXTRACT ...."
            if createTargetPathIfNotExists == "Y":
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; mkdir -p %s > %s/%s'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand,  "\"" + formApplicationtop + "\"", "\"" + formApplicationtop + "\"" , targetInstancePath, logfile)
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                else:
                    command = "pwd; " + envFileCommand + " pwd; whoami; echo \"" + formApplicationtop + "\";  mkdir -p \"" + formApplicationtop + "\" > " + targetInstancePath + "/" + logfile + " 2>&1"
                    createChannelAndExecuteCommand(command)
                    writingLogs()
            if copyWithPermissionsFlag == "true":
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "inside copyWithPermissionsFlag, sudo user..."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; cp %s/%s/%s %s >  %s/%s 2>&1 '" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"", targetInstancePath, objectDir, "\"" + objectName + "\"", "\"" + formApplicationtop + "\"", targetInstancePath, logfile)
                    exit_status = createChannelAndExecuteCommand(command)
                    print "Exit Status after copying the Object :", exit_status
                    writingLogs()
                    print "Command1 : ", command
                    print "inside copyWithPermissionsFlag, sudo user command is completed!"
                    if exit_status == 0:
                        command2 = "%s 'whoami; cd /home/%s; pwd; %s cd %s; chmod 777 %s; unzip -o %s; rm -rf %s && echo %s is Copied and extracted Successfully. >  %s/%s 2>&1 '" % (
                            connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"", "\"" + objectName + "\"", "\"" + objectName + "\"", "\"" + objectName + "\"", "\"" + objectName + "\"", targetInstancePath, logfile)
                        createChannelAndExecuteCommand(command2)
                        writingLogs()
                        print "Command2 : ", command2
                        print "inside copyWithPermissionsFlag,sudo user command2 is completed!"
                    print "inside copyWithPermissionsFlag, if block sudo user completed!"
                else:
                    print "inside copyWithPermissionsFlag, else block....normal user..."
                    command = envFileCommand + " echo \"" + formApplicationtop + "\" ; cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\"  \"" + formApplicationtop + "\" > " + targetInstancePath + "/" + logfile + " 2>&1"
                    exit_status = createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "Command1 : ", command
                    print "inside copyWithPermissionsFlag,normal user command is completed!"
                    if exit_status == 0:
                        command2 = envFileCommand + " cd \"" + formApplicationtop + "\" ; chmod 777 \"" + objectName + "\" ; unzip -o \"" + objectName + "\" ;  rm -rf \"" + objectName + "\" ; cd $HOME && echo \"" + objectName + "\" is Copied and extracted Successfully. > " + targetInstancePath + "/" + logfile + " 2>&1"
                        createChannelAndExecuteCommand(command2)
                        writingLogs()
                        print "Command2 : ", command2
                        print "inside copyWithPermissionsFlag,normal user command2 is completed!"
                    print "inside copyWithPermissionsFlag, else block normal user completed!"
            else:
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "inside COPY AND EXTRACT, sudo user..."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; cp %s/%s/%s %s >  %s/%s 2>&1 '" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"", targetInstancePath, objectDir, "\"" + objectName + "\"", "\"" + formApplicationtop + "\"", targetInstancePath, logfile)
                    exit_status = createChannelAndExecuteCommand(command)
                    print "Exit Status after copying the Object :", exit_status
                    writingLogs()
                    print "Command1 : ", command
                    print "inside COPY AND EXTRACT,sudo user command is completed!"
                    if exit_status == 0:
                        command2 = "%s 'whoami; cd /home/%s; pwd; %s cd %s; unzip -o %s; rm -rf %s && echo %s is Copied and extracted Successfully. >  %s/%s 2>&1 '" % (
                            connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"", "\"" + objectName + "\"", "\"" + objectName + "\"", "\"" + objectName + "\"", targetInstancePath, logfile)
                        createChannelAndExecuteCommand(command2)
                        writingLogs()
                        print "Command2 : ", command2
                        print "inside COPY AND EXTRACT, sudo user command2 is completed!"
                    print "inside COPY AND EXTRACT, sudo user completed!"
                else:
                    print "inside COPY AND EXTRACT, normal user..."
                    command = envFileCommand + " echo \"" + formApplicationtop + "\" ; cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\"  \"" + formApplicationtop + "\" > " + targetInstancePath + "/" + logfile + " 2>&1"
                    exit_status = createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "Exit Status after copying the Object :", exit_status
                    print "inside COPY AND EXTRACT,normal user command is completed!"
                    print "Command1 : ", command
                    if exit_status == 0:
                        command2 = envFileCommand + " cd \"" + formApplicationtop + "\"; unzip -o \"" + objectName + "\"; rm -rf \"" + objectName + "\" ; cd $HOME && echo \"" + objectName + "\" is Copied and extracted Successfully. > " + targetInstancePath + "/" + logfile + " 2>&1"
                        createChannelAndExecuteCommand(command2)
                        writingLogs()
                        print "Command2 : ", command2
                        print "inside COPY AND EXTRACT,normal user command2 is completed!"
                    print "inside COPY AND EXTRACT, normal user completed!"

        # "EAR_FILE" object type
        elif objectType == "EAR_FILE":
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                print "inside EAR_FILE, sudo user..."
                command = "%s 'whoami; cd /home/%s; pwd; %s %s/bin/asadmin --host %s --port %s --user %s --passwordfile %s/%s/GlassfishServerConfig.txt --interactive=false deploy --force=true %s/%s/%s >  %s/%s'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, glassfishServerHomePath, glassfishServerHost, glassfishServerPort, glassfishServerUserName, targetInstancePath, objectDir, targetInstancePath, objectDir, objectName, targetInstancePath, logfile)
                createChannelAndExecuteCommand(command)
                writingLogs()
                print "inside EAR_FILE, sudo user completed!"
            else:
                print "inside EAR_FILE, normal user...."
                command = envFileCommand + " " + glassfishServerHomePath + "/bin/asadmin --host " + glassfishServerHost + " --port " + glassfishServerPort + " --user " + glassfishServerUserName + " --passwordfile " + targetInstancePath + "/" + objectDir + "/GlassfishServerConfig.txt --interactive=false deploy --force=true " + targetInstancePath + "/" + objectDir + "/" + objectName + " > " + targetInstancePath + "/" + logfile + " 2>&1"
                createChannelAndExecuteCommand(command)
                writingLogs()
                print "inside EAR_FILE, normal user completed!"

        elif objectType == "COPY_Default_FILE":
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                command = "%s 'whoami; cd /home/%s; pwd; %s pwd;whoami; mkdir -p %s/%s >  %s/%s 2>&1'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, targetInstancePath, objectDir, logFilePath, logfile)
            else:
                command = " pwd; " + envFileCommand + " pwd; whoami; echo " + formApplicationtop + "; mkdir -p " + targetInstancePath + "/" + objectDir + "  > " + targetInstancePath + "/" + logfile + "  2>&1"
            sftp.put(fileNameStr + "/" + objectName, targetInstancePath + "/" + objectDir + "/" + objectName)

        # "EXECUTE_SHELL SCRIPT" object type
        elif objectType == "EXECUTE_SHELL SCRIPT":
            if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                print "Inside EXECUTE_SHELL SCRIPT, inside sudo user..."
                command2 = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; cd %s/%s; dos2unix %s; chmod 777 %s; sh %s %s > %s/%s/extractAOLlog.log 2>&1 && echo \"BUILD SUCCESSFUL\" >> %s/%s/extractAOLlog.log 2>&1'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, targetInstancePath, objectDir, "\"" + objectName + "\"", "\"" + objectName + "\"", "\"" + objectName + "\"",
                    spaceSeparatedArguments, targetInstancePath, objectDir, targetInstancePath, objectDir)
                createChannelAndExecuteCommand(command2)
                writingLogs()
                print "Inside EXECUTE_SHELL SCRIPT, inside sudo user completed!"
            else:
                print "Inside EXECUTE_SHELL SCRIPT, inside normal user..."
                command2 = "pwd; " + envFileCommand + " cd " + targetInstancePath + "/" + objectDir + "; dos2unix \"" + objectName + "\"; chmod 777 \"" + objectName + "\"; sh \"" + objectName + "\" " + spaceSeparatedArguments + ">> $HOME/" + targetInstancePath + "/" + objectDir + "/" + logfile + " 2>&1" + " && echo 'BUILD SUCCESSFUL' >> $HOME/" + targetInstancePath + "/" + objectDir + "/" + logfile + " 2>&1"
                createChannelAndExecuteCommand(command2)
                writingLogs()
                print "Inside EXECUTE_SHELL SCRIPT, inside normal user completed!"

            #IS091768-Shellscript is not getting executed as expected when input arguments are provided through AOM tool
            objectDirPathInTargetInstance = targetInstancePath + "/" + objectDir + "/"
            print "objectDirPathInTargetInstance:" + objectDirPathInTargetInstance
            print "shellScriptFiles:" + shellScriptFiles
            sftp = ssh.open_sftp()
            remoteFiles = sftp.listdir(path=objectDirPathInTargetInstance)
            for files in remoteFiles:
                if fnmatch.fnmatch(files, '*.log'):
                    sftp.get(objectDirPathInTargetInstance + files, shellScriptFiles + files)

        # "ORACLE_FORMS" object type
        elif objectType == "ORACLE_FORMS":
            print "copyToBothFileSystems:" + copyToBothFileSystems + ", copyToPatchFileSystem:" + copyToPatchFileSystem
            if copyToBothFileSystems == "true":
                print "########## copyToBothFileSystems == true ##########"
                # Need to copy files to both file systems
                print "*********************Migrating " + objectName + " to Run File System*********************"
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "Inside ORACLE_FORMS, sudo user..."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; cp %s/%s/%s %s  > %s/extractAOLlog.log 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, auTopDir, targetInstancePath, objectDir, "\"" + objectName + "\"",
                        auTopDir,targetInstancePath)
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "Inside ORACLE_FORMS, sudo user executing main command..."
                    command2 = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami;  cd %s; frmcmp_batch module= %s/%s output_file=%s/%s.fmx  userid=%s module_type=form compile_all=special && echo Form created. Completed %s migration to Run File System > %s/extractAOLlog.log 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, auTopDir, auTopDir, "\"" + objectName + "\"", formApplicationtop,
                        formName, appsDetails, "\"" + objectName + "\"", targetInstancePath)
                    createChannelAndExecuteCommand(command2)
                    writingLogs()
                    print "Inside OF, sudo user completed!"
                else:
                    print "Inside ORACLE_FORMS, normal user..."
                    command = envFileCommand + "echo " + auTopDir + ";  cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\"  " + auTopDir + " > " + targetInstancePath + "/" + logfile + " 2>&1"
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "Inside ORACLE_FORMS, normal user executing main command..."
                    command2 = envFileCommand + " cd " + auTopDir + "; frmcmp_batch module=" + auTopDir + "/\"" + objectName + "\" output_file=" + formApplicationtop + "/" + formName + ".fmx  userid=" + appsDetails + " module_type=form compile_all=special ; cd $HOME && echo Form created. Completed \"" + objectName + "\" migration to Run File System > " + targetInstancePath + "/" + logfile + " 2>&1"
                    createChannelAndExecuteCommand(command2)
                    writingLogs()
                    print "Inside OF, normal user completed!"
                print "*********************Completed " + objectName + " migration to Run File System*********************"
                print "*********************Migrating " + objectName + " to Patch File System*********************"
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "Inside ORACLE_FORMS, sudo user..."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; %s echo %s; cp %s/%s/%s %s  > %s/extractAOLlog.log 2>&1'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, auTopDir, targetInstancePath, objectDir, "\"" + objectName + "\"", auTopDir, targetInstancePath)
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "Inside ORACLE_FORMS, sudo user execcuting main command..."
                    command2 = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; %s cd %s; frmcmp_batch module= %s/%s output_file=%s/%s.fmx  userid=%s module_type=form compile_all=special && echo Form created. Completed %s migration to Patch File System > %s/extractAOLlog.log 2>&1'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, auTopDir, auTopDir, "\"" + objectName + "\"", formApplicationtop,
                        formName, appsDetails, "\"" + objectName + "\"", targetInstancePath)
                    createChannelAndExecuteCommand(command2)
                    writingLogs()
                    print "Inside ORACLE_FORMS, sudo user completed!"
                else:
                    print "Inside ORACLE_FORMS, normal user..."
                    command = envFileCommand + " " + patchFileSystemEnvFile + "echo " + auTopDir + ";  cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\"  " + auTopDir + " > " + targetInstancePath + "/" + logfile + " 2>&1"
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "Inside ORACLE_FORMS, normal user execcuting main command..."
                    command2 = envFileCommand + " " + patchFileSystemEnvFile + " cd " + auTopDir + "; frmcmp_batch module= " + auTopDir + "/\"" + objectName + "\"  output_file=" + formApplicationtop + "/" + formName + ".fmx  userid=" + appsDetails + " module_type=form compile_all=special ; cd $HOME  && echo Form created. Completed \"" + objectName + "\" migration to Patch File System > " + targetInstancePath + "/" + logfile + " 2>&1"
                    createChannelAndExecuteCommand(command2)
                    writingLogs()
                    print "Inside ORACLE_FORMS, normal user completed!"
                print "*********************Completed " + objectName + " migration to Patch File System*********************"
            elif copyToPatchFileSystem == "true":
                print "########## copyToPatchFileSystem == true ##########"
                # Need to copy files to Patch file system
                print "*********************Migrating " + objectName + " to Patch File System*********************"
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "Inside ORACLE_FORMS, sudo user..."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; %s echo %s; cp %s/%s/%s %s  > %s/extractAOLlog.log 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, auTopDir, targetInstancePath, objectDir,
                        "\"" + objectName + "\"", auTopDir, targetInstancePath)
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "Inside ORACLE_FORMS, sudo user execcuting main command..."
                    command2 = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; %s cd %s; frmcmp_batch module= %s/%s output_file=%s/%s.fmx  userid=%s module_type=form compile_all=special && echo Form created. Completed %s migration to Patch File System > %s/extractAOLlog.log 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, auTopDir, auTopDir, "\"" + objectName + "\"",
                        formApplicationtop, formName, appsDetails, "\"" + objectName + "\"", targetInstancePath)
                    createChannelAndExecuteCommand(command2)
                    writingLogs()
                    print "Inside ORACLE_FORMS, sudo user completed!"
                else:
                    print "Inside ORACLE_FORMS, normal user..."
                    command =  envFileCommand + " " + patchFileSystemEnvFile + "echo " + auTopDir + ";  cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\"  " + auTopDir + " > " + targetInstancePath + "/" + logfile + " 2>&1"
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "Inside ORACLE_FORMS, normal user execcuting main command..."
                    command2 =  envFileCommand + " " + patchFileSystemEnvFile + " cd " + auTopDir + "; frmcmp_batch module=" + auTopDir + "/\"" + objectName + "\"  output_file=" + formApplicationtop + "/" + formName + ".fmx  userid=" + appsDetails + " module_type=form compile_all=special ; cd $HOME  && echo Form created. Completed \"" + objectName + "\" migration to Patch File System > " + targetInstancePath + "/" + logfile + " 2>&1"
                    createChannelAndExecuteCommand(command2)
                    writingLogs()
                    print "Inside ORACLE_FORMS, normal user completed!"
                print "*********************Completed " + objectName + " migration to Patch File System*********************"
            else:
                # Copying object to normal file system
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami;  echo %s; cp %s/%s/%s %s  > %s/extractAOLlog.log 2>&1 '" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, auTopDir, targetInstancePath, objectDir, "\"" + objectName + "\"",
                        auTopDir, targetInstancePath)
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    command2 = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami;  cd %s; frmcmp_batch module=%s/%s output_file=%s/%s.fmx  userid=%s module_type=form compile_all=special > %s/extractAOLlog.log 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, auTopDir, auTopDir, "\"" + objectName + "\"", formApplicationtop,
                        formName, appsDetails, targetInstancePath)
                    createChannelAndExecuteCommand(command2)
                    writingLogs()
                else:
                    command = envFileCommand + "echo " + auTopDir + ";  cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\"  " + auTopDir + " > " + targetInstancePath + "/" + logfile + " 2>&1"
                    print "ORACLE_FORMS MIGRATION COMMAND:::" + command
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    command2 = envFileCommand + " cd " + auTopDir + "; frmcmp_batch module=" + auTopDir + "/\"" + objectName + "\" output_file=" + formApplicationtop + "/" + formName + ".fmx userid=" + appsDetails + " module_type=form compile_all=special > $HOME/" + targetInstancePath + "/" + logfile + " 2>&1"
                    print "ORACLE_FORMS MIGRATION COMMAND2:::" + command2
                    createChannelAndExecuteCommand(command2)
                    writingLogs()

        # "ORACLE_REPORTS" object type
        elif objectType == "ORACLE_REPORTS":
            print "copyToBothFileSystems:" + copyToBothFileSystems + ", copyToPatchFileSystem:" + copyToPatchFileSystem
            if copyToBothFileSystems == "true":
                print "########## copyToBothFileSystems == true ##########"
                # Need to copy files to both file systems
                print "*********************Migrating " + objectName + " to Run File System*********************"
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "Run, sudo user!"
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd;whoami; echo %s; cp %s/%s/%s %s && echo %s is Migrated Successfully. Completed %s migration to Run File System > %s/extractAOLlog.log 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, formApplicationtop, targetInstancePath, objectDir,
                        "\"" + objectName + "\"", formApplicationtop, "\"" + objectName + "\"",
                        "\"" + objectName + "\"", targetInstancePath)
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    # command2  = "%s whoami; cd /home/%s; pwd; " + envFileCommand + "pwd;whoami; echo %s; rwconverter userid=%s/%s  source=%s/%s  dest=%s/%s; stype=rdffile dtype=rdffile overwrite=yes batch=yes compile_all=yes && echo %s is Migrated Successfully.> %s/extractAOLlog.log 2>&1 " % (
                    # connectToSudoCmd, sudoToUser, formApplicationtop,schemaName, schemaPassword, formApplicationtop, objectName, formApplicationtop, objectName, objectName, targetInstancePath)
                    # createChannelAndExecuteCommand(command2)
                    print objectName + " is Migrated Successfully."
                else:
                    print "Run, normal user!"
                    command = "pwd; " + envFileCommand + "" + " echo " + formApplicationtop + "; cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\" " + formApplicationtop + " && echo \"" + objectName + "\" is Migrated Successfully. Completed \"" + objectName + "\" migration to Run File System  > " + targetInstancePath + "/" + logfile + " 2>&1"
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    # command2 = "pwd; " + envFileCommand + " echo " + formApplicationtop + ";  rwconverter userid=" + schemaName + "/" + schemaPassword +" source=" + formApplicationtop + "/" + objectName + " dest=" + formApplicationtop + "/" + objectName + "; stype=rdffile dtype=rdffile overwrite=yes batch=yes compile_all=yes && echo " + objectName + " is Migrated Successfully. > " + targetInstancePath + "/" + logfile + " 2>&1"
                    # createChannelAndExecuteCommand(command2)
                    print objectName + " is Migrated Successfully."
                print "*********************Completed " + objectName + " migration to Run File System*********************"
                print "*********************Migrating " + objectName + " to Patch File System*********************"
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "Patch, sudo user!"
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd;whoami; %s echo %s; cp %s/%s/%s %s && echo %s is Migrated Successfully. Completed %s migration to Patch File System > %s/extractAOLlog.log 2>&1'" % (
                    connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, formApplicationtop, targetInstancePath, objectDir, "\"" + objectName + "\"",
                        formApplicationtop, "\"" + objectName + "\"", "\"" + objectName + "\"", targetInstancePath)
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    # command2  = "%s whoami; cd /home/%s; pwd; " + envFileCommand + "pwd;whoami; echo %s; rwconverter userid=%s/%s  source=%s/%s  dest=%s/%s; stype=rdffile dtype=rdffile overwrite=yes batch=yes compile_all=yes && echo %s is Migrated Successfully.> %s/extractAOLlog.log 2>&1 " % (
                    # connectToSudoCmd, sudoToUser, formApplicationtop,schemaName, schemaPassword, formApplicationtop, objectName, formApplicationtop, objectName, objectName, targetInstancePath)
                    # createChannelAndExecuteCommand(command2)
                    print objectName + " is Migrated Successfully."
                else:
                    print "Patch, normal user!"
                    command = "pwd; " + envFileCommand + "" + patchFileSystemEnvFile + " echo " + formApplicationtop + "; cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\" " + formApplicationtop + " && echo \"" + objectName + "\" is Migrated Successfully. Completed \"" + objectName + "\" migration to Patch File System > " + targetInstancePath + "/" + logfile + " 2>&1"
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    # command2 = "pwd; " + envFileCommand + " echo " + formApplicationtop + ";  rwconverter userid=" + schemaName + "/" + schemaPassword +" source=" + formApplicationtop + "/" + objectName + " dest=" + formApplicationtop + "/" + objectName + "; stype=rdffile dtype=rdffile overwrite=yes batch=yes compile_all=yes && echo " + objectName + " is Migrated Successfully. > " + targetInstancePath + "/" + logfile + " 2>&1"
                    # createChannelAndExecuteCommand(command2)
                    print objectName + " is Migrated Successfully."
                print "*********************Completed " + objectName + " migration to Patch File System*********************"
            elif copyToPatchFileSystem == "true":
                print "########## copyToPatchFileSystem == true ##########"
                # Need to copy files to Patch file system
                print "*********************Migrating " + objectName + " to Patch File System*********************"
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "Patch, sudo user!"
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd;whoami; %s echo %s; cp %s/%s/%s %s && echo %s is Migrated Successfully. Completed %s migration to Patch File System > %s/extractAOLlog.log 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand,  patchFileSystemEnvFile, formApplicationtop, targetInstancePath,
                        objectDir, "\"" + objectName + "\"",
                        formApplicationtop, "\"" + objectName + "\"", "\"" + objectName + "\"", targetInstancePath)
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    # command2  = "%s whoami; cd /home/%s; pwd; " + envFileCommand + "pwd;whoami; echo %s; rwconverter userid=%s/%s  source=%s/%s  dest=%s/%s; stype=rdffile dtype=rdffile overwrite=yes batch=yes compile_all=yes && echo %s is Migrated Successfully.> %s/extractAOLlog.log 2>&1 " % (
                    # connectToSudoCmd, sudoToUser, formApplicationtop,schemaName, schemaPassword, formApplicationtop, objectName, formApplicationtop, objectName, objectName, targetInstancePath)
                    # createChannelAndExecuteCommand(command2)
                    print objectName + " is Migrated Successfully."
                else:
                    print "Patch, normal user!"
                    command = "pwd; " + envFileCommand + " " + patchFileSystemEnvFile + " echo " + formApplicationtop + "; cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\" " + formApplicationtop + " && echo \"" + objectName + "\" is Migrated Successfully. Completed \"" + objectName + "\" migration to Patch File System > " + targetInstancePath + "/" + logfile + " 2>&1"
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    # command2 = "pwd; " + envFileCommand + " echo " + formApplicationtop + ";  rwconverter userid=" + schemaName + "/" + schemaPassword +" source=" + formApplicationtop + "/" + objectName + " dest=" + formApplicationtop + "/" + objectName + "; stype=rdffile dtype=rdffile overwrite=yes batch=yes compile_all=yes && echo " + objectName + " is Migrated Successfully. > " + targetInstancePath + "/" + logfile + " 2>&1"
                    # createChannelAndExecuteCommand(command2)
                    print objectName + " is Migrated Successfully."
                print "*********************Completed " + objectName + " migration to Patch File System*********************"
            else:
                # Copying object to normal file system
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd;whoami; echo %s; cp %s/%s/%s %s && echo %s is Migrated Successfully. > %s/extractAOLlog.log 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, formApplicationtop, targetInstancePath, objectDir,
                        "\"" + objectName + "\"", formApplicationtop, "\"" + objectName + "\"", targetInstancePath)
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    # command2  = "%s whoami; cd /home/%s; pwd; " + envFileCommand + "pwd;whoami; echo %s; rwconverter userid=%s/%s  source=%s/%s  dest=%s/%s; stype=rdffile dtype=rdffile overwrite=yes batch=yes compile_all=yes && echo %s is Migrated Successfully.> %s/extractAOLlog.log 2>&1 " % (
                    # connectToSudoCmd, sudoToUser, formApplicationtop,schemaName, schemaPassword, formApplicationtop, objectName, formApplicationtop, objectName, objectName, targetInstancePath)
                    # createChannelAndExecuteCommand(command2)
                    print objectName + " is Migrated Successfully."
                else:
                    command = "pwd;" + envFileCommand + " echo " + formApplicationtop + "; cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\" " + formApplicationtop + " && echo \"" + objectName + "\" is Migrated Successfully. > " + targetInstancePath + "/" + logfile + " 2>&1"
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    # command2 = "pwd; " + envFileCommand + " echo " + formApplicationtop + ";  rwconverter userid=" + schemaName + "/" + schemaPassword +" source=" + formApplicationtop + "/" + objectName + " dest=" + formApplicationtop + "/" + objectName + "; stype=rdffile dtype=rdffile overwrite=yes batch=yes compile_all=yes && echo " + objectName + " is Migrated Successfully. > " + targetInstancePath + "/" + logfile + " 2>&1"
                    # createChannelAndExecuteCommand(command2)
                    print objectName + " is Migrated Successfully."


        # "ORACLE_FORM_LIBRARIES" object type
        # IS097480 - Provision to migrate oracle form libraries (custom.pll) through AOM
        elif objectType == "ORACLE_FORM_LIBRARIES":
            print "ORACLE_FORM_LIBRARIES object type block in FRMMigrator.py file"
            print "copyToBothFileSystems:" + copyToBothFileSystems + ", copyToPatchFileSystem:" + copyToPatchFileSystem
            if copyToBothFileSystems == "true":
                print "########## copyToBothFileSystems == true ##########"
                # Need to copy files to both file systems
                print "*********************Migrating " + objectName + " to Run File System*********************"
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "Inside ORACLE_FORM_LIBRARIES, sudo user..."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; cp %s/%s/%s %s  > %s/extractAOLlog.log 2>&1'" % (connectToSudoCmd, sudoToUser, envFileCommand, auTopDir, targetInstancePath, objectDir, "\"" + objectName + "\"",auTopDir,targetInstancePath)
                    #print "command : " + command
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "Inside ORACLE_FORM_LIBRARIES, sudo user executing main command..."
                    command2 = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami;  cd %s; frmcmp_batch module=%s output_file=%s/%s.plx  userid=%s module_type=LIBRARY compile_all=special batch=yes && echo ORACLE_FORM_LIBRARIES created. Completed %s migration to Run File System > %s/extractAOLlog.log 2>&1'" % (connectToSudoCmd, sudoToUser, envFileCommand, auTopDir , objectName, formApplicationtop,"CUSTOM", appsDetails, "\"" + objectName + "\"", targetInstancePath)
                    #print "command2 " + command2
                    createChannelAndExecuteCommand(command2)
                    writingLogs()
                    print "Inside ORACLE_FORM_LIBRARIES, sudo user completed!"
                else:
                    print "Inside ORACLE_FORM_LIBRARIES, normal user..."
                    command = envFileCommand + "echo " + auTopDir + ";  cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\""  + auTopDir + "> " + targetInstancePath + "/" + logfile + " 2>&1"
                    #print "command : " +  command
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "Inside ORACLE_FORM_LIBRARIES, normal user executing main command..."
                    command2 = envFileCommand + " cd " + auTopDir +"; frmcmp_batch module="+objectName+" output_file=" + formApplicationtop + "/" + "CUSTOM" + ".plx userid=" + appsDetails + " module_type=LIBRARY compile_all=special batch=yes; cd $HOME && echo ORACLE_FORM_LIBRARIES created. Completed \"" + objectName + "\" migration to Run File System > " + targetInstancePath + "/" + logfile + " 2>&1"
                    #print "command2 : " + command2
                    createChannelAndExecuteCommand(command2)
                    writingLogs()
                    print "Inside ORACLE_FORM_LIBRARIES, normal user completed!"
                print "*********************Completed " + objectName + " migration to Run File System*********************"
                print "*********************Migrating " + objectName + " to Patch File System*********************"
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "Inside ORACLE_FORM_LIBRARIES, sudo user..."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; %s echo %s; cp %s/%s/%s %s  > %s/extractAOLlog.log 2>&1'" % (connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, auTopDir, targetInstancePath, objectDir, "\"" + objectName + "\"",auTopDir, targetInstancePath)
                    #print "command : " + command
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "Inside ORACLE_FORM_LIBRARIES, sudo user executing main command..."
                    command2 = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; %s cd %s; frmcmp_batch module=%s output_file=%s/%s.plx  userid=%s module_type=LIBRARY compile_all=special batch=yes && echo ORACLE_FORM_LIBRARIES created. Completed %s migration to Patch File System > %s/extractAOLlog.log 2>&1'" % (connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, auTopDir ,objectName, formApplicationtop,"CUSTOM", appsDetails, "\"" + objectName + "\"", targetInstancePath)
                    #print "command2 : " +  command2
                    createChannelAndExecuteCommand(command2)
                    writingLogs()
                    print "Inside ORACLE_FORM_LIBRARIES, sudo user completed!"
                else:
                    print "Inside ORACLE_FORM_LIBRARIES, normal user..."
                    command = envFileCommand + " " + patchFileSystemEnvFile + "echo " + auTopDir + ";  cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\""  + auTopDir + " > " + targetInstancePath + "/" + logfile + " 2>&1"
                    #print "command : " + command
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "Inside ORACLE_FORM_LIBRARIES, normal user executing main command..."
                    command2 = envFileCommand + " " + patchFileSystemEnvFile + " cd " + auTopDir + "; frmcmp_batch module="+objectName+" output_file=" + formApplicationtop + "/" + "CUSTOM" + ".plx  userid=" + appsDetails + " module_type=LIBRARY compile_all=special batch=yes ; cd $HOME  && echo ORACLE_FORM_LIBRARIES created. Completed \"" + objectName + "\" migration to Patch File System > " + targetInstancePath + "/" + logfile + " 2>&1"
                    #print "command2 : " + command2
                    createChannelAndExecuteCommand(command2)
                    writingLogs()
                    print "Inside ORACLE_FORM_LIBRARIES, normal user completed!"
                print "*********************Completed " + objectName + " migration to Patch File System*********************"
            elif copyToPatchFileSystem == "true":
                print "########## copyToPatchFileSystem == true ##########"
                # Need to copy files to Patch file system
                print "*********************Migrating " + objectName + " to Patch File System*********************"
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "Inside ORACLE_FORM_LIBRARIES, sudo user..."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; %s echo %s; cp %s/%s/%s %s  > %s/extractAOLlog.log 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, auTopDir, targetInstancePath, objectDir,
                            "\"" + objectName + "\"", auTopDir, targetInstancePath)
                    #print "command : " + command
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "Inside ORACLE_FORM_LIBRARIES, sudo user executing main command..."
                    command2 = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; %s cd %s; frmcmp_batch module=%s output_file=%s/%s.plx  userid=%s module_type=LIBRARY compile_all=special batch=yes && echo ORACLE_FORM_LIBRARIES created. Completed %s migration to Patch File System > %s/extractAOLlog.log 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, patchFileSystemEnvFile, auTopDir,objectName + "\"",
                        formApplicationtop, "CUSTOM", appsDetails, "\"" + objectName + "\"", targetInstancePath)
                    #print "command2 : " + command2
                    createChannelAndExecuteCommand(command2)
                    writingLogs()
                    print "Inside ORACLE_FORM_LIBRARIES, sudo user completed!"
                else:
                    print "Inside ORACLE_FORM_LIBRARIES, normal user..."
                    command =  envFileCommand + " " + patchFileSystemEnvFile + "echo " + auTopDir + ";  cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\"" + auTopDir + " > " + targetInstancePath + "/" + logfile + " 2>&1"
                    #print "command : " + command
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "Inside ORACLE_FORM_LIBRARIES, normal user executing main command..."
                    command2 =  envFileCommand + " " + patchFileSystemEnvFile + " cd " + auTopDir + "; frmcmp_batch module="+objectName+" output_file="+formApplicationtop+ "/" + "CUSTOM" + ".plx  userid=" + appsDetails + " module_type=LIBRARY compile_all=special batch=yes; cd $HOME  && echo ORACLE_FORM_LIBRARIES created. Completed \"" + objectName + "\" migration to Patch File System > " + targetInstancePath + "/" + logfile + " 2>&1"
                    #print "command2 : " + command2
                    createChannelAndExecuteCommand(command2)
                    writingLogs()
                    print "Inside ORACLE_FORM_LIBRARIES, normal user completed!"
                print "*********************Completed " + objectName + " migration to Patch File System*********************"
            else:
                print "entered in else block for ORACLE_FORM_LIBRARIES file"
                # Copying object to normal file system
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami;  echo %s; cp %s/%s/%s %s  > %s/extractAOLlog.log 2>&1 '" % (connectToSudoCmd, sudoToUser, envFileCommand, auTopDir, targetInstancePath, objectDir, "\"" + objectName + "\"",auTopDir, targetInstancePath)
                    #print "command : " + command
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    command2 = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami;  cd %s; frmcmp_batch module=%s output_file=%s/%s.plx  userid=%s module_type=LIBRARY compile_all=special batch=yes && echo ORACLE_FORM_LIBRARIES created > %s/extractAOLlog.log 2>&1'" % (connectToSudoCmd, sudoToUser, envFileCommand, auTopDir, objectName, formApplicationtop,"CUSTOM", appsDetails, targetInstancePath)
                    #print "command2 : " + command2
                    createChannelAndExecuteCommand(command2)
                    writingLogs()
                else:
                    command = envFileCommand + "echo " + auTopDir + ";  cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\"  " + auTopDir + " > " + targetInstancePath + "/" + logfile + " 2>&1"
                    #print "command : " + command
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    command2 =  envFileCommand + " cd " + auTopDir + "; frmcmp_batch module="+objectName+ " output_file=" + formApplicationtop + "/" + "CUSTOM" + ".plx  userid=" + appsDetails + " module_type=LIBRARY compile_all=special batch=yes ; cd $HOME  && echo ORACLE_FORM_LIBRARIES created > " + targetInstancePath + "/" + logfile + " 2>&1"
                    #print "command2 : " + command2
                    createChannelAndExecuteCommand(command2)
                    writingLogs()
        
        # IS109799 - Provision for softlink migration through AOM
        # "SOFTLINK" object type
        if objectType == "SOFTLINK":
            print "createTargetPathIfNotExists:" + createTargetPathIfNotExists
            if createTargetPathIfNotExists == "y":
                if sudoToUser != "sudoToUser-no" and sudoToUser != "" and sudoToUser != "null":
                    print "inside createTargetPathIfNotExists, if block...."
                    command = " %s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; mkdir -p %s > %s/%s 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"",
                        "\"" + formApplicationtop + "\"", targetInstancePath, logfile)
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside createTargetPathIfNotExists, if block completed!"
                else:
                    print "inside createTargetPathIfNotExists, else block...."
                    command = " pwd; " + envFileCommand + " pwd; whoami; echo \"" + formApplicationtop + "\";  mkdir -p \"" + formApplicationtop + "\" > " + targetInstancePath + "/" + logfile + " 2>&1 "
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside createTargetPathIfNotExists, else block completed!"

            print "copyWithPermissionsAndConversionFlag:" + copyWithPermissionsAndConversionFlag
            print "copyWithPermissionsFlag:" + copyWithPermissionsFlag
            print "copyWithConversionFlag:" + copyWithConversionFlag

            if copyWithPermissionsAndConversionFlag == "true":
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "inside copyWithPermissionsAndConversionFlag, if block....sudo user...."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; cp %s/%s/%s  %s > %s/%s/%s 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"",
                        targetInstancePath, objectDir, "\"" + objectName + "\"", "\"" + formApplicationtop + "\"",
                        targetInstancePath, objectDir, logfile)
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside copyWithPermissionsAndConversionFlag,sudo user command is completed!"
                    command2 = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; cd %s; chmod 777 %s; dos2unix %s  && echo %s is Copied Successfully. >  %s/%s/%s 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"",
                        "\"" + objectName + "\"", "\"" + objectName + "\"", "\"" + objectName + "\"",
                        targetInstancePath, objectDir, logfile)
                    exitStatus = createChannelAndExecuteCommand(command2)
                    writingLogs()
                    if exitStatus == 0:
                        isCopiedSuccessfully = True
                    print "inside copyWithPermissionsAndConversionFlag,sudo user command2 is completed!"
                    print "inside copyWithPermissionsAndConversionFlag, if block sudo user completed!"
                else:
                    print "inside copyWithPermissionsAndConversionFlag, else block....normal user...."
                    command = "pwd; " + envFileCommand + " echo \"" + formApplicationtop + "\"; cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\" \"" + formApplicationtop + "\" > $HOME/" + targetInstancePath + "/" + objectDir + "/" + logfile + " 2>&1 "
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside copyWithPermissionsAndConversionFlag,normal user command is completed!"
                    command2 = "pwd; " + envFileCommand + " cd \"" + formApplicationtop + "\"; chmod 777 \"" + objectName + "\" dos2unix \"" + objectName + "\" && echo \"" + objectName + "\" is Copied Successfully. > $HOME/" + targetInstancePath + "/" + objectDir + "/" + logfile + " 2>&1 "
                    exitStatus = createChannelAndExecuteCommand(command2)
                    writingLogs()
                    if exitStatus == 0:
                        isCopiedSuccessfully = True
                    print "inside copyWithPermissionsAndConversionFlag,normal user command2 is completed!"
                    print "inside copyWithPermissionsAndConversionFlag, else block normal user completed!"
            elif copyWithPermissionsFlag == "true":
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "inside copyWithPermissionsFlag, if block....sudo user...."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; cp %s/%s/%s %s >  %s/%s/%s 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"",
                        targetInstancePath, objectDir, "\"" + objectName + "\"", "\"" + formApplicationtop + "\"",
                        targetInstancePath, objectDir, logfile)
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside copyWithPermissionsFlag,sudo user command is completed!"
                    command2 = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; cd %s; chmod 777 %s && echo %s is Copied Successfully. > %s/%s/%s 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"",
                        "\"" + objectName + "\"", "\"" + objectName + "\"", targetInstancePath, objectDir, logfile)
                    exitStatus = createChannelAndExecuteCommand(command2)
                    writingLogs()
                    if exitStatus == 0:
                        isCopiedSuccessfully = True
                    print "inside copyWithPermissionsFlag,sudo user command2 is completed!"
                    print "inside copyWithPermissionsFlag, if block sudo user completed!"
                else:
                    print "inside copyWithPermissionsFlag, else block....normal user..."
                    command = "pwd; " + envFileCommand + " echo \"" + formApplicationtop + "\"; cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\" \"" + formApplicationtop + "\";  > " + targetInstancePath + "/" + objectDir + "/" + logfile + " 2>&1"
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside copyWithPermissionsFlag,normal user command is completed!"
                    command2 = "pwd; " + envFileCommand + " cd \"" + formApplicationtop + "\"; chmod 777 \"" + objectName + "\" && echo \"" + objectName + "\" is Copied Successfully. > $HOME/" + targetInstancePath + "/" + objectDir + "/" + logfile + " 2>&1 "
                    exitStatus = createChannelAndExecuteCommand(command2)
                    writingLogs()
                    if exitStatus == 0:
                        isCopiedSuccessfully = True
                    print "inside copyWithPermissionsFlag,normal user command2 is completed!"
                    print "inside copyWithPermissionsFlag, else block normal user completed!"
            elif copyWithConversionFlag == "true":
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "inside copyWithConversionFlag, if block....sudo user...."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; cp %s/%s/%s %s > %s/%s/%s 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"",
                        targetInstancePath, objectDir, "\"" + objectName + "\"", "\"" + formApplicationtop + "\"",
                        targetInstancePath, objectDir, logfile)
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside copyWithConversionFlag,sudo user command is completed!"
                    command2 = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; cd %s; dos2unix %s && echo %s is Copied Successfully. > %s/%s/%s 2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"",
                        "\"" + formApplicationtop + "\"", "\"" + objectName + "\"", "\"" + objectName + "\"",
                        targetInstancePath, objectDir, logfile)
                    exitStatus = createChannelAndExecuteCommand(command2)
                    writingLogs()
                    if exitStatus == 0:
                        isCopiedSuccessfully = True
                    print "inside copyWithConversionFlag,sudo user command2 is completed!"
                    print "inside copyWithConversionFlag, if block sudo user completed!"
                else:
                    print "inside copyWithConversionFlag, else block....normal user...."
                    command = "pwd; " + envFileCommand + " echo \"" + formApplicationtop + "\"; cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\" \"" + formApplicationtop + "\" > $HOME/" + targetInstancePath + "/" + objectDir + "/" + logfile + " 2>&1"
                    createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "inside copyWithConversionFlag,normal user command is completed!"
                    command2 = "pwd; " + envFileCommand + " cd \"" + formApplicationtop + "\"; dos2unix \"" + objectName + "\" && echo \"" + objectName + "\" is Copied Successfully. > $HOME/" + targetInstancePath + "/" + objectDir + "/" + logfile + " 2>&1 "
                    exitStatus = createChannelAndExecuteCommand(command2)
                    writingLogs()
                    if exitStatus == 0:
                        isCopiedSuccessfully = True
                    print "inside copyWithConversionFlag, normal user command2 is completed!"
                    print "inside copyWithConversionFlag, else block normal user completed!"
            else:
                print "else block in SOFTLINK object type"
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "inside SOFTLINK, sudo user..."
                    command = "%s 'whoami; cd /home/%s; pwd; %s pwd; whoami; echo %s; cp %s/%s/%s %s > %s/%s/%s 2>&1 && echo %s is Copied Successfully.  >  %s/%s/%s  2>&1'" % (
                        connectToSudoCmd, sudoToUser, envFileCommand, "\"" + formApplicationtop + "\"",
                        targetInstancePath, objectDir, "\"" + objectName + "\"", "\"" + formApplicationtop + "\"",
                        targetInstancePath, objectDir, logfile, "\"" + objectName + "\"", targetInstancePath, objectDir,
                        logfile)
                    exitStatus = createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "exitStatus inside Sofltink Copy:", exitStatus
                    if exitStatus == 0:
                        isCopiedSuccessfully = True
                    print "inside SOFTLINK, sudo user completed!"

                else:
                    print "inside SOFTLINK, normal user..."
                    command = envFileCommand + " echo \"" + formApplicationtop + "\"; cp " + targetInstancePath + "/" + objectDir + "/\"" + objectName + "\" \"" + formApplicationtop + "\" > " + targetInstancePath + "/" + objectDir + "/" + logfile + " 2>&1 && echo \"" + objectName + "\" is Copied Successfully. > " + targetInstancePath + "/" + objectDir + "/" + logfile + " 2>&1"
                    exitStatus = createChannelAndExecuteCommand(command)
                    writingLogs()
                    print "exitStatus inside Sofltink Copy:", exitStatus
                    if exitStatus == 0:
                        isCopiedSuccessfully = True
                    print "inside SOFTLINK, normal user completed!"

            # "EXECUTE_SHELL SCRIPT" object type(SOFTLINK) if Object Copied only
            if isCopiedSuccessfully :
                if sudoToUser != "sudoToUser-No" and sudoToUser != "" and sudoToUser != "null":
                    print "Inside EXECUTE_SHELL SCRIPT, inside sudo user..."
                    command2 = "%s 'whoami; pwd; %s pwd; whoami; cd %s/%s; dos2unix %s; chmod 777 %s; sh %s %s %s %s > %s/%s/extractAOLlog.log 2>&1 && echo \"BUILD SUCCESSFUL\" >> %s/%s/extractAOLlog.log 2>&1'" % (
                        connectToSudoCmd, envFileCommand, targetInstancePath, objectDir,
                        "\"" + softlinkShellScript + "\"", "\"" + softlinkShellScript + "\"",
                        "\"" + softlinkShellScript + "\"", formApplicationtop, objectDir, objectName,
                        targetInstancePath, objectDir, targetInstancePath, objectDir)
                    exitStatus = createChannelAndExecuteCommand(command2)
                    writingLogs()
                    print "exitStatus inside Shell Script:", exitStatus
                    if exitStatus == 0:
                        isSoftLinkCreated = True
                    print "Inside EXECUTE_SHELL SCRIPT, inside sudo user completed!"
                else:
                    print "Inside EXECUTE_SHELL SCRIPT, inside normal user..."
                    command2 = "pwd; " + envFileCommand + " cd " + targetInstancePath + "/" + objectDir + "; dos2unix \"" + softlinkShellScript + "\"; chmod 777 \"" + softlinkShellScript + "\"; sh \"" + softlinkShellScript + "\" " + formApplicationtop + " " + objectDir + " " + objectName + " > /home/" + destinationuserName + "/" + targetInstancePathWithoutDot + "/" + objectDir + "/" + logfile + " 2>&1 && echo 'BUILD SUCCESSFUL' >> /home/" + destinationuserName + "/" + targetInstancePathWithoutDot + "/" + objectDir + "/" + logfile + " 2>&1"
                    exitStatus = createChannelAndExecuteCommand(command2)
                    print "exitStatus inside Shell Script:", exitStatus
                    writingLogs()
                    if exitStatus == 0:
                        isSoftLinkCreated = True
                    print "Inside EXECUTE_SHELL SCRIPT, inside normal user completed!"

                # Shellscript is not getting executed as expected when input arguments are provided through AOM tool
                objectDirPathInTargetInstance = targetInstancePath + "/" + objectDir + "/"
                print "objectDirPathInTargetInstance:" + objectDirPathInTargetInstance
                print "shellScriptFiles:" + shellScriptFiles
                sftp = ssh.open_sftp()
                remoteFiles = sftp.listdir(path=objectDirPathInTargetInstance)
                for files in remoteFiles:
                    if fnmatch.fnmatch(files, '*.log'):
                        sftp.get(objectDirPathInTargetInstance + files, shellScriptFiles + files)

            print "isCopiedSuccessfully :", isCopiedSuccessfully, "isSoftLinkCreated:", isSoftLinkCreated
            if isCopiedSuccessfully and not isSoftLinkCreated :
                print "Problem in Creating the Softlink"
                writingLogs()
                migrationLogFile.write("Softlink Not Created")
        
    except Exception as migrationException:
        if (objectType == "EXECUTE"):
            migrationLogFile.write("BUILD FAILED")
        print "Migration Exception:"
        print migrationException
        migrationLogFile.write(str(migrationException))

    finally:
        command = "rm -rf " + targetInstancePath + "/" + objectDir + "/"
        exit_status = createChannelAndExecuteCommand(command)
        # writingLogs()
        deletingLogs()
        sftp.close()

except Exception as copyObjectException:
    print "Exception:"
    print copyObjectException
    print(traceback.print_exc())
    migrationLogFile.write(str(copyObjectException))
    migrationLogFile.write("\n")

finally:
    migrationLogFile.close()
    ssh.close()
    sys.exit(0)
