var flag=false;
var count=0;
var updateflag=false;
var functionFlag=false;
function setPopupHiddenField(txtField,valueField)
{
    flag=false;
    updateflag=false;
    popupValueField = txtField;
    popupHiddenField=valueField;
}

function setPopupField(valueField)
{
    flag=false;
    updateflag=false;
    popupHiddenField=valueField;
}

function setFunctionFlag()
{
	functionFlag=true;
}

function setTwoField(txt1field,txt2field,txtvalue1,txtvalue2,myflag,myvalue)
{
   count=2;
   flag=true;
   firstField=txt1field;
   secondfield=txt2field;
   firstFieldValue=txtvalue1;
   secondfieldValue=txtvalue2;
   updateflag=myflag;
   checkvalue=myvalue;
}
function setThreeField(txt1field,txt2field,txt3field,txtvalue1,txtvalue2,txtvalue3)
{
   count=3;
   flag=true;
   firstField=txt1field;
   secondfield=txt2field;
   thirdfield=txt3field;
   firstFieldValue=txtvalue1;
   secondfieldValue=txtvalue2;
   thirdfieldValue=txtvalue3;
}
function SelObj(formname,selname,textname,radioname,str)
{
	this.formname = formname;
	this.selname = selname;
	this.textname = textname;
	this.radioname = radioname;
	this.select_str = str || '';
	this.selectArr = new Array();
	this.initialize = initialize;
	this.bldInitial = bldInitial;
	this.bldUpdate = bldUpdate;
	this.bldUpdateGroup = bldUpdateGroup;
}

function initialize()
{
	if (this.select_str =='')
	{
		for(var i=0;i<document.forms[this.formname][this.selname].options.length;i++) 
		{
			this.selectArr[i] = document.forms[this.formname][this.selname].options[i];
			this.select_str += document.forms[this.formname][this.selname].options[i].value+":"+
			document.forms[this.formname][this.selname].options[i].text+",";
   		}
	}
	else 
	{
		var tempArr = this.select_str.split(',');
		for(var i=0;i<tempArr.length;i++) 
		{
			var prop = tempArr[i].split(':');
			this.selectArr[i] = new Option(prop[1],prop[0]);
   		}
	}
	return;
}

function bldInitial() 
{
	this.initialize();
	for(var i=0;i<this.selectArr.length;i++)
	document.forms[this.formname][this.selname].options[i] = this.selectArr[i];
	document.forms[this.formname][this.selname].options.length = this.selectArr.length;
	return;
}

function bldUpdate() 
{
	var str = document.forms[this.formname][this.textname].value.replace('^\\s*','');
	if(str == '') {this.bldInitial();return;}
	this.initialize();
	var j = 0;
	pattern1 = new RegExp("^"+str,"i");
	for(var i=0;i<this.selectArr.length;i++)
	if(pattern1.test(this.selectArr[i].text))
	document.forms[this.formname][this.selname].options[j++] = this.selectArr[i];
	document.forms[this.formname][this.selname].options.length = j;
	if(j==1)
	{
		document.forms[this.formname][this.selname].options[0].selected = true;
		//document.forms[this.formname][this.textname].value = document.forms[this.formname][this.selname].options[0].text;
   	}
}

function bldUpdateGroup() 
{
	var str = document.forms[this.formname][this.textname].value.replace('^\\s*','');
	if(str == '') {this.bldInitial();return;}
	this.initialize();
	var j = 0;
	pattern1 = new RegExp("^"+str,"i");
	for(var i=0;i<this.selectArr.length;i++)
	{
		var splitPattern = this.selectArr[i].text;
		if(document.forms[this.formname][this.radioname][0].checked)
		{
			testPattern = splitPattern.split('|');	
			splitPattern = testPattern[0];
		}
		else if(document.forms[this.formname][this.radioname][1].checked)
		{
			testPattern = splitPattern.split('|');	
			splitPattern = testPattern[1];
		}
		if(pattern1.test(splitPattern))
		{
			document.forms[this.formname][this.selname].options[j++] = this.selectArr[i];
		}
	}
	document.forms[this.formname][this.selname].options.length = j;
	if(j==1)
	{
		document.forms[this.formname][this.selname].options[0].selected = true;
		//document.forms[this.formname][this.textname].value = document.forms[this.formname][this.selname].options[0].text;
   	}
}

function setUp() 
{
	obj1 = new SelObj('menuform','itemlist','entry','bygroup');
	// menuform is the name of the form you use
	// itemlist is the name of the select pulldown menu you use
	// entry is the name of text box you use for typing in
	obj1.bldInitial();
}
//  End 


function sendValue(s)
{
	if(s.selectedIndex!=-1)
	{
		var selvalue = s.options[s.selectedIndex].value;
		var selText=s.options[s.selectedIndex].text;
		popupValueField.value=selText;
		popupHiddenField.value=selvalue;
		
	}
	if(functionFlag)
	{
		myuserfunction();
		functionFlag=false;
	}
	popupValueField.focus();
	//window.opener.document.popupform.choice.value = selvalue;
	//window.close();
	top.newWin.close();
}

function sendValueOnly(s)
{
	if(s.selectedIndex!=-1)
	{
		var selvalue = s.options[s.selectedIndex].value;
		popupHiddenField.value=selvalue;
		
		if(flag && trim(selvalue)!='')
		{
			if(firstField!=null)
			{
				if(firstFieldValue=='currentdate')
				{
					currentDate(firstField);
				}
				else
				{
					firstField.value=firstFieldValue;
				}
			}
			if(count>1 && secondfield!=null)
			{
				if(updateflag && selvalue==checkvalue)
				{
					if(secondfieldValue=='currentdate')
					{
						currentDate(secondfield);
					}
					else
					{
						secondfield.value=secondfieldValue;
					}
				}
				else if(updateflag==false)
				{
					if(secondfieldValue=='currentdate')
					{
						currentDate(secondfield);
					}
					else
					{
						secondfield.value=secondfieldValue;
					}
				}
				else
				{
					secondfield.value="";
				}
					
			}
			if(count>2 && thirdfield!=null)
			{
				if(thirdfieldValue=='currentdate')
				{
					currentDate(thirdfield);
				}
				else
				{
					thirdfield.value=thirdfieldValue;
				}
			}
		}
	}
	if(functionFlag)
	{
		myuserfunction();
		functionFlag=false;
	}
	popupHiddenField.focus();
	top.newWin.close()
	
}

//  End -->
