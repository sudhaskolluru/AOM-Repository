jQuery.expr[':'].Contains = function(a,i,m){
		return (a.textContent || a.innerText || "").toUpperCase().indexOf(m[3].toUpperCase())>=0; 
		};
	
$(function()
	{
	var rows = $(".display");
	var questions = $(".questions");
	$("#filter").click(function () {
		questions.hide();
		rows.hide();
		var trigger = $("#tags").val();
		var action = $("div p:Contains("+trigger.toUpperCase()+")").filter(function() {
	        return true;
	    }).closest("p").show("slow");	
		
		var search =  $("div table tr td:Contains("+trigger.toUpperCase()+")").filter(function() {
	        return true;
	    }).closest("td").show("slow");	
		
	});
	});
	
$(function()
	{
	var rows = $(".display");
	var questions = $(".questions");
	$("#sh_all").click(function () {
		$("#tags").val("");
		rows.show("slow");
		questions.show("slow");
	});
	});
	