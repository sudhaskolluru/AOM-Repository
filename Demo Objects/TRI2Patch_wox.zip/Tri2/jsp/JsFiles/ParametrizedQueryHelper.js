

function getBindVarValue(obj,str,queryTypeField)
{
   
  var varValue = obj.value
  // var indexOfSymbol = varValue.indexOf('&');
  var indexOfSymbol = -1;
  if (varValue.charAt(0) == '&') { indexOfSymbol = 0; }
  var res = "";
  if (indexOfSymbol != -1)
  {
     res = prompt("Value of Bind Variable1 "+str,"");     
     //res = varValue.substring(0,indexOfSymbol)+res;     
      //document.menu.querytype.value = "2";
      //alert("queryTypeField value : "+queryTypeField.value);
      if (queryTypeField != null && queryTypeField.value != "2")
         queryTypeField.value = "2";
  } 
  return res;
}

