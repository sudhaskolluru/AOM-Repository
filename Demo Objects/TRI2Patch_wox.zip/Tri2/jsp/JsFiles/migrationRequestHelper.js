var selectedValuesList = new Array();
var index = 0;

function sendMultipleValues(fromList,toList)
{
	for (var i=0; i < fromList.options.length; i++)
	{
		var o = fromList.options[i];
		if (o.selected)
		{
			var flag = 0;
			for(var j= 0; j < toList.options.length ; j++ )
			{
				if(  o.value == toList.options[j].value )
				{

					o.value="";
					o.text="";
					//from.remove(i);
					flag = 1;
				}
			}
			if(flag == 0)
			{				
				var anOption = document.createElement("OPTION") ;
				anOption.text = o.text;
				anOption.value =o.value;
				toList.options.add(anOption);
				o.value="";
				o.text="";
				flag = 1;
				fromList.remove(i);
				i--;
			}
			
		}
	}
}


function updateSelectedObjects(selectedObjects , availableObjects)
{
//alert('in updateselected objects ');
    var selectedObjectsIndex = 0;  
var removedIndex = 0;

      for( var selectedValuesListindex = 0;selectedValuesListindex < selectedValuesList.length; selectedValuesListindex++)
      {
         if(selectedObjects.options[selectedValuesListindex] != null)
         {
//            alert(' selected value is '+selectedObjects.options[selectedValuesListindex]);
              var o = selectedObjects.options[selectedValuesListindex];
              o.value="";
		o.text="";
		selectedObjects .remove(removedIndex);
              removedIndex++;       
         }
            
       }
 
    for( var selectedValuesListindex = 0;selectedValuesListindex < selectedValuesList.length; selectedValuesListindex++)
    {
                 
        if(selectedValuesList[selectedValuesListindex] != null && selectedValuesList[selectedValuesListindex] != "")
        { 
              var anOption = document.createElement("OPTION") ;
		anOption.text = selectedValuesList[selectedValuesListindex];
		anOption.value =selectedValuesList[selectedValuesListindex];
		
              selectedObjects.options[selectedObjectsIndex] = anOption;
              selectedObjectsIndex++;
        }                
     }
     resetRFilterValue();
       
}






function addToSelectedList(availableObjects)
{
   for (var i=0; i < availableObjects.length; i++)
    {
		var o = availableObjects.options[i];
		if (o.selected)
		{
                  selectedValuesList[index]=o.value;
                  index++;
              }
	}

}


function removeFromSelectedList(selectedObjects)
{
    for(var index=0;index<selectedValuesList.length;index++)
    {   
        for(var selectedObjectsIndex = 0;selectedObjectsIndex<selectedObjects.length; selectedObjectsIndex++)
	 { 
	       var option = selectedObjects.options[selectedObjectsIndex];
    		if (option.selected && option.value == selectedValuesList[index])
    		{
                    selectedValuesList[index] = "";
              }
        }
   }
}


function updateAvailableObjects(availableObjects, selectedObjects)
{
    var availableObjectsIndex = 0;
    var found = 0;
   // document.dbObjectsForm.lFilter = "";

            for(var index = 0;index < totalValuesArray.length;index++)
             {                  
              for(var selectedObjectsIndex = 0 ;selectedObjectsIndex < selectedObjects.options.length ; selectedObjectsIndex++)
              {

                         if(selectedObjects.options[selectedObjectsIndex].value == totalValuesArray[index].value)
                         {

                            
                           if(totalValuesArray[index] != null && totalValuesArray[index].value != "")
                            { 
                              

                                var found = 1;
                                break;
                            }
                         }      
              }
               if(found == 0)
               {
                    if(totalValuesArray[index].value != "")
                    {
                        availableObjects.options[availableObjectsIndex] = totalValuesArray[index]; 
                         availableObjectsIndex++;
                    }
               }
                             
           }
             
     resetFilterValue();
 
 }