addEvent(window, "load", sortables_init);

var SORT_COLUMN_INDEX;
var ts_getInnerText_common;
var noSortingColumns; // Added by raghavendra on 21st Dec, 2006  To disable sorting for "NO SORTING" columns.
	//noSortingColumns should be initilaised with an array of column indices which dont require sorting.
var functionArray;
var index;
var sortfn ;
var itemValueIndex;
var cellValues;

function sortables_init() 
{
    // Find all tables with class sortable and make them sortable
    if (!document.getElementsByTagName) return;
    tbls = document.getElementsByTagName("table");
    for (ti=0;ti<tbls.length;ti++) 
    {
        thisTbl = tbls[ti];
        if (((' '+thisTbl.className+' ').indexOf("sortable") != -1) && (thisTbl.id)) 
        {
            //initTable(thisTbl.id);
            ts_makeSortable(thisTbl);
        }
    }
   if(typeof functionAfterSorting == 'function')
   {
   		functionAfterSorting();
   }
}

function ts_makeSortable(table) 
{
    //window.alert('ts_makeSortable function ');
    if (table.rows && table.rows.length > 0) 
    {
        var firstRow = table.rows[0];
    }
    if (!firstRow) return;
    functionArray = new Array();
    // We have a first row: assume it's the header, and make its contents clickable links
    for (var i=0;i<firstRow.cells.length;i++) 
    {
    	if(sortingRequired(i))
    	{
    		var cell = firstRow.cells[i];
	        var txt = cell.innerHTML;
	        //alert('ts_makeSortable txt>'+txt);
	        cell.innerHTML = '<a href="#" class="sortheader" onClick="ts_resortTable(this);return false;">'+txt+'<span class="sortarrow">&nbsp;&nbsp;&nbsp;</span></a>';
	    }
    }
}
function sortingRequired(columnIndex)
{
	//var noSortingColumns = Array(1,2);
	if(noSortingColumns != null)
	{
		for(i= 0 ; i < noSortingColumns.length ; i++ )
		{
			//alert('noSortingColumns['+i+']> '+noSortingColumns[i]);
			if(columnIndex == eval(noSortingColumns[i]))
			{
				return false;
			}
		}
	}
	return true;
}
 
function ts_resortTable(lnk) 
{
	noFunctionAssignedFlag = false;
	var  start = new Date();
	var startTime = start.getTime();
	//alert('startTime>'+startTime);
	//window.alert('lnk lnk.innerHTML>>> ' + lnk.innerHTML);
    var span;
    //alert('ts_resortTable');
    var temp = '0';
    for (var ci=0;ci<lnk.childNodes.length;ci++) 
    {
	    if (lnk.childNodes[ci].tagName && lnk.childNodes[ci].tagName.toLowerCase() == 'span')
	    {
     		span = lnk.childNodes[ci];
	    }
    }
    var td = lnk.parentNode;
    var column = td.cellIndex;
    var table = getParent(td,'TABLE');
    if (table.rows.length <= 1) return;
    //alert('SORT_COLUMN_INDEX>'+SORT_COLUMN_INDEX);
    if(SORT_COLUMN_INDEX == column)
    {
    	ts_makeReverse(span,table);
    	SORT_COLUMN_INDEX = column;
    } 
    else
    {
    	if(typeof SORT_COLUMN_INDEX != "undefined")
    	{
    		var SPANs = table.rows[0].getElementsByTagName('span');
    		if(SPANs[SORT_COLUMN_INDEX] && (noSortingColumns && noSortingColumns[0] != '0')||!noSortingColumns)
    		{
    			SPANs[SORT_COLUMN_INDEX].setAttribute('sortdir','');
	    	}
	    	else
	    	{
	    		SPANs[SORT_COLUMN_INDEX-1].setAttribute('sortdir','');
	    	}
    	}
	    
	    SORT_COLUMN_INDEX = column;
    	ts_getInnerText_common = null;
    	cellValues  = new Array();
	    ts_componentFunction(table,column);
		
		if(ts_getInnerText_common != 'No function assigned') // if no function has been assigned (which indicates that there are no components in the column).
	    {
	    	//getting Cell values
	    	cellValues = ts_getCellValues(table,column,index);
	    	var item = cellValues[itemValueIndex];
	    	
	    	ts_sortFunction(item);
	    	
	    	// Sorting Rows.
		    ts_sortRows(table,cellValues,sortfn);
		    
		    //restore the class names.
		    ts_restoreClassNames(table);
	    }
	    //Setting Arrows.
	    
	    
	    if(typeof functionWithInSorting == 'function')
	   	{
	   		try
	   		{
	   			functionWithInSorting();
	   		}
	   		catch(everything)
	   		{
	   			//alert('Exception');
	   		}
	   	}
   	}
   	ts_setArrows(span,table);
   	var  end = new Date();
	var endTime = end.getTime();
	//alert(" It took" + eval(endTime-startTime)/1000 + " milliseconds");
}

function ts_sortFunction(itm)
{
	//alert('ts_sortFunction itm>'+itm);
	sortfn = ts_sort_caseinsensitive;
    if (itm.match(/^\d\d[\/-]\d\d[\/-]\d\d\d\d$/)) sortfn = ts_sort_date;
    if (itm.match(/^\d\d[\/-]\d\d[\/-]\d\d$/)) sortfn = ts_sort_date;
    //if (itm.match(/^\d\d[\/-]\d\d[\/-]\d\d$/)) sortfn = ts_sort_date;
    // Added by Rekha to sort date in US format
    if (itm.match(/^\d\d[\/-]\d\d[\/-]\d\d[\s]\d\d[:]\d\d[:]\d\d$/)) sortfn = ts_sort_date_USFormat ;
   
    if (itm.match(/^\d\d[\/-]\w\w\w[\/-]\d\d$/)) sortfn = ts_sort_date_MONFormat ;
    
    if (itm.match(/^[?$]/)) sortfn = ts_sort_currency;
    //if (itm.match(/^[0-9,$]/)) sortfn = ts_sort_numbers;
    //if (itm.match(/^[\d\,$]/)) sortfn = ts_sort_numbers;/,/g
    //if (itm.match(/^(?:\d+,){9}\d+$/)) sortfn = ts_sort_numbers;
    //if (itm.match(/^[0-9,$]/)) sortfn = ts_sort_numbers;
    if (itm.match(/^[0-9,]+$/)) sortfn = ts_sort_numbers;
    if (itm.match(/^[\d\.]+$/)) sortfn = ts_sort_numeric;
   
}
 
function ts_componentFunction(table,column)
{
	//alert('ts_componentFunction');
	index = 1 ;
	cellValues = new Array();
	cellValues[0] = '';// not considering header values
	if(!functionArray[column])
	{
		for(  ; index < table.rows.length ; index++)
	    {	
	    	element = table.rows[index].cells[column];
			while(element.hasChildNodes()) 
			{
				element = element.childNodes[0];
			}
			//alert('ts_componentFunction after while element.nodeName>'+element.nodeName+' element.nodeType>'+element.nodeType);
			if( (element.tagName && element.tagName =='TD') 
			     || element.nodeName == 'SPAN')
			{
				cellValues[index] = '~';
				//alert('ts_componentFunction cellValues['+index+']>'+cellValues[index]);
				continue;
			}
			else if(element.parentNode && element.parentNode.tagName =='SELECT')
			{
				//alert('ts_componentFunction ts_getInnerText_select');
				ts_getInnerText_common = ts_getInnerText_select;
				functionArray[column] = ts_getInnerText_select;
				break;
			}
			else if(element.nodeType == 3)
			{
				//alert('ts_componentFunction ts_getInnerText_text');
				ts_getInnerText_common = ts_getInnerText_text;
				functionArray[column] = ts_getInnerText_text;
				break;
			}
			else if(element.tagName == 'IMG')
			{
				//alert('ts_componentFunction  ts_getInnerText_image');
				ts_getInnerText_common = ts_getInnerText_image;
				functionArray[column] = ts_getInnerText_image;
				break;
			}
			
			else if(element.tagName =='INPUT')
			{
				if(element.type == 'text')
				{
					//alert('ts_componentFunction ts_getInnerText_inputText');
					functionArray[column] = ts_getInnerText_inputText;
					ts_getInnerText_common = ts_getInnerText_inputText;
					break;
				}
				else if(element.type == 'checkbox')
				{
					//alert('ts_componentFunction ts_getInnerText_checkbox');
					ts_getInnerText_common = ts_getInnerText_checkbox;
					functionArray[column] = ts_getInnerText_checkbox;
					break; 
				}
				else if(element.type == 'radio')
				{
					//alert('ts_componentFunction ts_getInnerText_radioButton');
					ts_getInnerText_common = ts_getInnerText_radioButton;
					functionArray[column] = ts_getInnerText_radioButton;
					break;
				}
			}
		}
		if(index == table.rows.length)
		{
			//alert( 'No function assigned');
			ts_getInnerText_common = 'No function assigned';
		}
	}
	else
	{
		//alert('in else');
		ts_getInnerText_common  = functionArray[column];
	}
} 

function ts_getCellValues(table,column,index)
{
	cellValues[0] = '';// not considering header values
	//alert('ts_getCellValues index>'+index);
	for (var m = index ; m < table.rows.length ; m++)
	{
		element = table.rows[m].cells[column];
		while(element.hasChildNodes()) 
		{
			element = element.childNodes[0];
		}
		if( (element.tagName && element.tagName =='TD') 
		     || element.nodeName == 'SPAN')
		{
			cellValues[m] = '~';
		}
		else
		{
			cellValues[m] = ts_getInnerText_common(element);
			itemValueIndex = m; //itemValueIndex is a global variable.
		}
		//alert('ts_getCellValues cellValues['+m+']>'+cellValues[m]);
	}
	return cellValues;
}

function ts_sortRows(table,cellValues,sortfn)
{	
	var cellValuesLength = cellValues.length;
	//alert('ts_sortRows cellValuesLength>'+cellValuesLength);
	for(var k = 1 ; k < cellValuesLength-1 ; k++)
	{
		for(var p = k+1 ; p < cellValuesLength ; p++)
		{
			//alert('cellValues['+k+']> '+cellValues[k]+' cellValues['+p+']> '+cellValues[p]);
			var sortValue = sortfn(cellValues[k],cellValues[p]);
			if(sortValue == 1)
			{
				 var tempVal;
				 tempVal = cellValues[k];
			     cellValues[k] = cellValues[p];
			     cellValues[p] = tempVal;
			     customSwapNodes(table.rows[k],table.rows[p]);
		     }
		}
	}
}

function ts_makeReverse(span,table)
{
	//alert('ts_makeReverse>');
	 var newRows = new Array();
	for (j = 0 ; j < table.rows.length ; j++) 
    { 
		newRows[j] = table.rows[j];
    }
    //Calling a predefined method reverse to reverse rows.
	newRows.reverse();
	
	var rowslength = newRows.length;
    for (i = 1 ; i < rowslength-1 ; i++) 
    { 
    	table.tBodies[0].appendChild(newRows[i]);
	}
}

function ts_setArrows(span,table)
{
	// Deleting arrows if exists.
    var SPANs = table.rows[0].getElementsByTagName('span');
    //alert('SPANs.length'+SPANs.length);
    for(var ci = 0; ci < SPANs.length ; ci++)
    {
    	if(SPANs[ci].className == 'sortarrow')
    	{
    		SPANs[ci].innerHTML = '&nbsp;&nbsp;&nbsp;';
    	}
    }
    
	if (span.getAttribute("sortdir") == 'down') 
    {
    	ARROW = '&nbsp;&nbsp;&uarr;';
 		span.setAttribute('sortdir','up');
    }
    else 
    {
    	ARROW = '&nbsp;&nbsp;&darr;';
        span.setAttribute('sortdir','down');
    }
    
    // Setting Arrow
    span.innerHTML = ARROW;
}

function ts_restoreClassNames(table)
{
	var rows = table.rows;
	var l = rows.length;
	var classval ;
	for (var i = 1; i < l; i++) 
	{
		classval = i % 2 ? "odd" : "even";
		if(classval == "odd")
		{
			rows[i].className = "table-odd-row";
		}
		else
		{
			rows[i].className = "table-even-row";
		}
	}
}


function getParent(element, pTagName) {
	if (element == null) return null;
	else if (element.nodeType == 1 && element.tagName.toLowerCase() == pTagName.toLowerCase())	// Gecko bug, supposed to be uppercase
		return element;
	else
		return getParent(element.parentNode, pTagName);
}
function ts_sort_date(a,b) {
    // y2k notes: two digit years less than 50 are treated as 20XX, greater than 50 are treated as 19XX
    if (a.length == 10) {
        dt1 = a.substr(6,4)+a.substr(3,2)+a.substr(0,2);
    } else {
        yr = a.substr(6,2);
        if (parseInt(yr) < 50) { yr = '20'+yr; } else { yr = '19'+yr; }
        dt1 = yr+a.substr(3,2)+a.substr(0,2);
    }
    if (b.length == 10) {
        dt2 = b.substr(6,4)+b.substr(3,2)+b.substr(0,2);
    } else {
        yr = b.substr(6,2);
        if (parseInt(yr) < 50) { yr = '20'+yr; } else { yr = '19'+yr; }
        dt2 = yr+b.substr(3,2)+b.substr(0,2);
    }
    if (dt1==dt2) return 0;
    if (dt1<dt2) return -1;
    return 1;
}
// added by Rekha to sort US date format
function ts_sort_date_USFormat(a,b) 
{
	//window.alert('ts_sort_date_USFormat');    
	//window.alert('a.length >' + a.length);
    	//window.alert('b.length >' + b.length);
    	if(a.length == 17)
    	{
    		dt1 = '20'+ a.substr(6,2)+a.substr(0,2)+a.substr(3,2)+a.substr(9,2)+a.substr(12,2)+a.substr(15,2);
    		//window.alert('dt1 >> ' + dt1)
    	}
    	if(b.length == 17)
	{
		dt2 = '20'+ b.substr(6,2)+b.substr(0,2)+b.substr(3,2)+b.substr(9,2)+b.substr(12,2)+b.substr(15,2);
		//window.alert('dt2 >> ' + dt2)
    	}
    	if (dt1==dt2) return 0;
    	if (dt1<dt2) return -1;
	return 1;
}
function ts_sort_date_MONFormat(a,b)
{
	//alert('ts_sort_date_MONFormat');
	if(a.length == 9)
	{
		yr = a.substr(7,2);
		if (parseInt(yr) < 50) 
		{ 
			yr = '20'+yr; 
		} 
		else 
		{ 
			yr = '19'+yr; 
		}
    	if(a.substr(3,3).match("JAN")) { mm = '01'; }
    	if(a.substr(3,3).match("FEB")) { mm = '02'; }
    	if(a.substr(3,3).match("MAR")) { mm = '03'; }
    	if(a.substr(3,3).match("APR")) { mm = '04'; }
    	if(a.substr(3,3).match("MAY")) { mm = '05'; }
    	if(a.substr(3,3).match("JUN")) { mm = '06'; }
    	if(a.substr(3,3).match("JUL")) { mm = '07'; }
    	if(a.substr(3,3).match("AUG")) { mm = '08'; }
    	if(a.substr(3,3).match("SEP")) { mm = '09'; }
    	if(a.substr(3,3).match("OCT")) { mm = '10'; }
    	if(a.substr(3,3).match("NOV")) { mm = '11'; }
    	if(a.substr(3,3).match("DEC")) { mm = '12'; }

    	dt1 = yr+mm+a.substr(0,2);
	}
	if(b.length == 9)
{
	yr = b.substr(7,2);
	if (parseInt(yr) < 50) 
	{ 
		yr = '20'+yr; 
	} 
	else 
	{ 
		yr = '19'+yr; 
	}
	if(b.substr(3,3).match("JAN")) { mm = '01'; }
	if(b.substr(3,3).match("FEB")) { mm = '02'; }
	if(b.substr(3,3).match("MAR")) { mm = '03'; }
	if(b.substr(3,3).match("APR")) { mm = '04'; }
	if(b.substr(3,3).match("MAY")) { mm = '05'; }
	if(b.substr(3,3).match("JUN")) { mm = '06'; }
	if(b.substr(3,3).match("JUL")) { mm = '07'; }
	if(b.substr(3,3).match("AUG")) { mm = '08'; }
	if(b.substr(3,3).match("SEP")) { mm = '09'; }
	if(b.substr(3,3).match("OCT")) { mm = '10'; }
	if(b.substr(3,3).match("NOV")) { mm = '11'; }
	if(b.substr(3,3).match("DEC")) { mm = '12'; }

	dt2 = yr+mm+b.substr(0,2);
}
	if (dt1==dt2) return 0;
	if (dt1<dt2) return -1;
	return 1;
}
function ts_sort_currency(a,b) 
{ 
    aa = a.replace(/[^0-9.]/g,'');
    bb = a.replace(/[^0-9.]/g,'');
    return parseFloat(aa) - parseFloat(bb);
}

function ts_sort_numeric(a,b) 
{ 
	//alert('ts_sort_numeric');
    aa = parseFloat(a);
    //if (isNaN(aa)) aa = 0;
    bb = parseFloat(b); 
    //if (isNaN(bb)) bb = 0;
    if (aa==bb) return 0;
    if (aa<bb) return -1;
    return 1;
    //return aa-bb;
}
// Added by Rekha to provide number sorting
function ts_sort_numbers(a,b) 
{ 
	//alert('ts_sort_numbers');
    //aa = a.toLowerCase().replace(/[^0-9]/g,'');
    //bb = b.toLowerCase().replace(/[^0-9]/g,'');
    
    aa = a.toLowerCase().replace(/,/g,'');
    bb = b.toLowerCase().replace(/,/g,'');
    //alert(aa);
    //alert(bb);
    num1 = parseInt(aa);
    num2 = parseInt(bb);
    //alert(num1);
    //alert(num2);
    
    
    if (num1==num2) return 0;
    if (num1<num2) return -1;
    return 1;
    
}
function ts_sort_caseinsensitive(a,b) 
{
	
	//alert('ts_sort_caseinsensitive');
	aa = a.toLowerCase();
	//alert('a'+a);
	//alert('b'+b);
    bb = b.toLowerCase();
    if (aa==bb) return 0;
    if (aa<bb) return -1;
    return 1;
}

function ts_sort_default(a,b) 
{
	//alert('ts_sort_default');
    if (a==b) return 0;
    if (a<b) return -1;
    return 1;
}

function ts_getInnerText_select(element)
{
	//alert('ts_getInnerText_select el.tagName>'+element.tagName);
	element = element.parentNode;
	var OPTION = element.options[element.selectedIndex];
	if(OPTION)
	{
		//alert('ts_getInnerText_select OPTION.innerText>'+OPTION.innerText);
		return OPTION.innerText;
	}
	return '~';
}
function ts_getInnerText_checkbox(element)
{
	//alert('ts_getInnerText_checkbox element.checked>'+element.checked);
	if(element.checked)
	{
		return 'A'+element.checked;
	}
	return 'B'+element.checked;
}

function ts_getInnerText_text(element)
{
	//alert('ts_getInnerText_text element.nodeValue>'+element.nodeValue);
	if(element.nodeValue != null)
	{
		return ''+element.nodeValue;
	}
	return "~";
}

function ts_getInnerText_image(element)
{
	//alert('ts_getInnerText_image element.alt>'+element.alt);
	if(element.alt)
	{
		return'A'+element.alt;
	}
	return "~";
}

function ts_getInnerText_inputText(element)
{
	//alert('ts_getInnerText_inputText> element.value>'+element.value);
	if(element && element.value != null);
	{
		return ''+element.value;
	}
	return "~";
}

function ts_getInnerText_radioButton(element)
{
	//alert('ts_getInnerText_radioButton> element.parentNode.tagName>'+element.parentNode.parentNode.parentNode.tagName);
	INPUTs = element.parentNode.parentNode.parentNode.getElementsByTagName('input');
	//alert('INPUTs.length'+INPUTs.length);
	for(var i = 0 ; i < INPUTs.length ; i++)
	{
		if(INPUTs[i].checked == true)
		{
			return 'A'+INPUTs[i].value;
		}
		else
		{
			return 'B'+INPUTs[i].value;
		}
	}
}

function addEvent(elm, evType, fn, useCapture)
// addEvent and removeEvent
// cross-browser event handling for IE5+,  NS6 and Mozilla
// By Scott Andrew
{
  if (elm.addEventListener)
  {
    elm.addEventListener(evType, fn, useCapture);
    return true;
  } else if (elm.attachEvent)
  {
    var r = elm.attachEvent("on"+evType, fn);
    return r;
  } else 
  {
    alert("Handler could not be removed");
  }
} 

function customSwapNodes(item1,item2) 
{
	var itemtmp = item1.cloneNode(1);
	var parent = item1.parentNode;
	item2 = parent.replaceChild(itemtmp,item2);
	parent.replaceChild(item2,item1);
	parent.replaceChild(item1,itemtmp);
	itemtmp = null;
}
