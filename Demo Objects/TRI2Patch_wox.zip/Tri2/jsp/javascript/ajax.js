function getXhr()
{
	if (window.XMLHttpRequest)
	{
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}

  	return xmlhttp;
}

function ajxGetXMLDocument(url)
{
	var responseText = ajxGetResponseText(url);
	var xmlDoc;
	if(responseText != null)
	{
		try //Internet Explorer
		{
			xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
			xmlDoc.async="false";
			xmlDoc.loadXML(responseText);
		}
		catch(e)
		{
			try //Firefox, Mozilla, Opera, etc.
			{
				parser=new DOMParser();
				xmlDoc=parser.parseFromString(responseText,"text/xml");
			}
			catch(e)
			{
				alert(e.message)
			}
		}
	}
	
	return xmlDoc;
}


