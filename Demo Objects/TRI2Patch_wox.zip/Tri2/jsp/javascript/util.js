var browser = navigator.appName;
function fixedTableHeader(tableId, divId)
{
	//alert("called");
	if(browser != "Microsoft Internet Explorer")
	{
		var TABLE = document.getElementById(tableId);
		if(TABLE)
		{
			var TRs = TABLE.rows;
		    var Ths = TRs[0].getElementsByTagName('th');
		    var divPosValue = document.getElementById(divId).scrollTop - 2;
			for(var x=0; x<Ths.length; x++)
			{
			    //Ths[x].style.top = divPosValue;
			    //Ths[x].style.position = "relative";
				var divObj = Ths[x].getElementsByTagName('div');
				divObj[0].style.position = "relative";
				divObj[0].style.top = divPosValue;
			}
		}
	}
}	
function insertDivElements(tableId,divId)
{
	//var browser = navigator.appName;
	//alert(browser);
	if(browser != "Microsoft Internet Explorer")
	{
		var TABLE = document.getElementById(tableId);//"exectpageform:exectionpageTableid");
		//alert(TABLE);
		if(TABLE)
		{
			var TRs = TABLE.rows;
		    var Ths = TRs[0].getElementsByTagName('th');
		    //alert(Ths.length);
			for(i =0; i<Ths.length; i++)
			{
				var data = Ths[i].innerHTML;
				//alert(data);
				Ths[i].innerHTML = "<div>"+data+"</div>";
				
				var divObj = Ths[i].getElementsByTagName('div');
				divObj[0].style.backgroundColor = "#6C6D58";
				divObj[0].style.borderCollapse="collapse";
				divObj[0].style.fontFamily = "Verdana, Arial, sans-serif";
				divObj[0].style.fontSize = "11px";
				divObj[0].style.textAlign = "center";
				divObj[0].style.color = "white";
				divObj[0].style.height = "100%";
				divObj[0].style.width = "100%";
				divObj[0].style.position = "relative";
				divObj[0].style.top = document.getElementById(divId).scrollTop - 2;
				//alert(Ths[i].innerHTML);
			}
		}
	}
}

	