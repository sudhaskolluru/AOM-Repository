function setPopupField(txtField,valueField)
{
    popupValueField = txtField;
    popupValue = txtField.value;
    popupHiddenField=valueField;
    popupHidden=valueField.value;
    
}


function SelObj(formname,selname,textname,str)
{
	this.formname = formname;
	this.selname = selname;
	this.textname = textname;
	this.select_str = str || '';
	this.selectArr = new Array();
	this.initialize = initialize;
	this.bldInitial = bldInitial;
	this.bldUpdate = bldUpdate;
}

function initialize()
{
	if (this.select_str =='') 
	{
		for(var i=0;i<document.forms[this.formname][this.selname].options.length;i++) 
		{
			this.selectArr[i] = document.forms[this.formname][this.selname].options[i];
			this.select_str += document.forms[this.formname][this.selname].options[i].value+":"+
			document.forms[this.formname][this.selname].options[i].text+",";
   		}
	}
	else 
	{
		var tempArr = this.select_str.split(',');
		for(var i=0;i<tempArr.length;i++) 
		{
			var prop = tempArr[i].split(':');
			this.selectArr[i] = new Option(prop[1],prop[0]);
   		}
	}
	return;
}

function bldInitial() 
{
	this.initialize();
	for(var i=0;i<this.selectArr.length;i++)
	document.forms[this.formname][this.selname].options[i] = this.selectArr[i];
	document.forms[this.formname][this.selname].options.length = this.selectArr.length;
	return;
}

function bldUpdate() 
{
	var str = document.forms[this.formname][this.textname].value.replace('^\\s*','');
	if(str == '') {this.bldInitial();return;}
	alert ( str);
	this.initialize();
	var j = 0;
	pattern1 = new RegExp("^"+str,"i");
	for(var i=0;i<this.selectArr.length;i++)
	if(pattern1.test(this.selectArr[i].text))
	document.forms[this.formname][this.selname].options[j++] = this.selectArr[i];
	document.forms[this.formname][this.selname].options.length = j;
	if(j==1)
	{
		document.forms[this.formname][this.selname].options[0].selected = true;
		//document.forms[this.formname][this.textname].value = document.forms[this.formname][this.selname].options[0].text;
   	}
}

function bldUpdateGroup() 
{
	var str = document.forms[this.formname][this.textname].value.replace('^\\s*','');
	if(str == '') {this.bldInitial();return;}
	this.initialize();
	var j = 0;
	pattern1 = new RegExp("^"+str,"i");
	for(var i=0;i<this.selectArr.length;i++)
	{
		var splitPattern = this.selectArr[i].text;
		if(document.forms[this.formname][this.radioname][0].checked)
		{
			testPattern = splitPattern.split('|');	
			splitPattern = testPattern[0];
		}
		else if(document.forms[this.formname][this.radioname][1].checked)
		{
			testPattern = splitPattern.split('|');	
			splitPattern = testPattern[1];
		}
		if(pattern1.test(splitPattern))
		{
			document.forms[this.formname][this.selname].options[j++] = this.selectArr[i];
		}
	}
	document.forms[this.formname][this.selname].options.length = j;
	if(j==1)
	{
		document.forms[this.formname][this.selname].options[0].selected = true;
		//document.forms[this.formname][this.textname].value = document.forms[this.formname][this.selname].options[0].text;
   	}
}



function setUp() 
{
	obj1 = new SelObj('menuform','itemlist','entry');
	// menuform is the name of the form you use
	// itemlist is the name of the select pulldown menu you use
	// entry is the name of text box you use for typing in
	obj1.bldInitial();
}
//  End


function sendValue(s)
{
	var selvalue = s.options[s.selectedIndex].value;
	var selText=s.options[s.selectedIndex].text;
	popupValueField.value=selText;
	popupHiddenField.value=selvalue;
	popupValueField.focus();
	//window.opener.document.popupform.choice.value = selvalue;
	//window.close();
	top.newWin.close();
}





