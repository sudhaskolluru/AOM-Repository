var agent_isIE = true;
var agent_isNS = 0;
var agent_isMac = 0;
var agent_isAOL = 0;
var H_URL_BASE = "http://help.msn.com/EN_US";
var L_OLC_Text = "Online Contacts";
var L_MessBud_Text = "Messenger Buddies";
var L_More_Text = " more...";
var L_NoContacts_Text = "No contacts currently online.";
var L_LogOn_Text = "Sign in to MSN Messenger";
var L_SignIn_Text = "Click here to sign in";
var L_IsOnline_Text = " is Online.";
var L_IsOffline_Text = " is Offline.";
var L_IsBusy_Text = " is Online, but currently Busy.";
var L_IsAway_Text = " is Online, but currently Away.";
var L_Add_Text = "Add ";
var L_ContactList_Text = " to My Messenger Buddies.";
var L_MyMessList_Text = " to <b>My Messenger Buddies</b>";
var L_AddToMy_Text = "Add to my <br>Messenger Buddies";
var L_NoBudOnline_Text = "No buddies currently online.";
var L_BudOnline_Text = "Buddies Currently Online";
var L_BudOffline_Text = "Buddies Not Online";
var WatchCount = "";
UserAdd = new Object();
AllUsers = new Object();
UserNotOn = new Object();
UserArr = new Array();
function DotheObject()
{
//MsgrObj = new ActiveXObject("Messenger.MsgrObject");
//MsgrApp = new ActiveXObject("Messenger.MessengerApp");
divMsgrObject.innerHTML = "<OBJECT classid='clsid:F3A614DC-ABE0-11d2-A441-00C04F795683' codeType='application/x-oleobject' height='1' id='MsgrObj' width='1'></OBJECT><OBJECT classid='clsid:FB7199AB-79BF-11d2-8D94-0000F875C541' codeType='application/x-oleobject' height='1' id='MsgrApp' width='1'></OBJECT>";
}
function isStateOnline(state)
{
var ret;
switch (state)
{
case 2:
//online
case 6:	
//invisible
case 10:
//busy
case 14:
//be right back
case 18:
//idle
case 34:
//away
case 50:
//on the phone
case 66:
//out to lunch
ret = true;
break;
default:
ret = false;
break;
}
return ret;
}
function getUserWithState(nUser,Page)
{
var ret;
var pUsers;
var pUser;
var img;
var msg;
var UState;
pUsers = MsgrObj.List(0);
pUser = pUsers.Item(nUser);
UState = pUser.State;
switch (UState)
{
case 1:
// Offline
img = 'src="http://64.4.16.24/icon_messenger1.gif"';
msg = L_IsOffline_Text;
break;
case 2:
// Online
img = 'src="http://64.4.16.24/icon_messenger0.gif"';
msg = L_IsOnline_Text;
break;
case 10:
// Busy
img = 'src="http://64.4.16.24/icon_messenger3.gif"';
msg = L_IsBusy_Text;
break;	
case 14:
// Be Right Back
img = 'src="http://64.4.16.24/icon_messenger2.gif"';
msg = L_IsAway_Text;
break;	
case 18:
// Away
img = 'src="http://64.4.16.24/icon_messenger2.gif"';
msg = L_IsAway_Text;
break;
case 34:
// Away
img = 'src="http://64.4.16.24/icon_messenger2.gif"';
msg = L_IsAway_Text;
break;
case 50:
// On the Phone
img = 'src="http://64.4.16.24/icon_messenger3.gif"';
msg = L_IsBusy_Text;
break;	
case 66:
// Out To Lunch
img = 'src="http://64.4.16.24/icon_messenger2.gif"';
msg = L_IsAway_Text;
break;
}
if (Page=="CONF")
{
ret = '<tr valign="middle"><td><A HREF="JavaScript:instantMessage(%22' + nUser + '%22)"><IMG alt="" ' + img + ' border=0></A></td><td><A HREF="JavaScript:instantMessage(%22' + nUser + '%22)" style="text-decoration:none;"><font class="s" color="#000000">' + HTMLencode(pUser.FriendlyName) + '</font></A></td></tr>';
}
else if (Page=="CONF_OFF")
{
ret = '<tr valign="middle"><td><IMG alt="" ' + img + ' border=0></td><td><font class="s" color="#000000">' + HTMLencode(pUser.FriendlyName) + '</font></td></tr>';
}
else if (Page=="IB")
{
ret = '<span style="position:relative;width:21px;top:2px;"><A HREF="JavaScript:instantMessage(%22' + nUser + '%22)"><IMG alt="" '+img+' border=0></a></span>';
}
else if (Page=="RM")
{
ret = '<table border=0 cellspacing=0 cellpadding=0><tr valign="middle"><td><A HREF="JavaScript:instantMessage(%22' + nUser + '%22)"><IMG alt="" '+ img +' border=0></a></td><td>&nbsp;<font class="f" size=2><A HREF="JavaScript:instantMessage(%22'+ nUser + '%22)">' + document.all.msgFromName.value +'</a>' + msg +'</font></td></tr></table>';
}
else
{	
ret = '<table border=0 cellspacing=0 cellpadding=0><tr valign="middle"><td><A HREF="JavaScript:instantMessage(%22' + nUser + '%22)"><IMG alt="" '+ img +' border=0></></td><td>&nbsp;<A HREF="JavaScript:instantMessage(%22' + nUser + '%22)"><font class="s" color="#000000">' + HTMLencode(pUser.FriendlyName) + '</font></a></td></tr></table>';
}
return ret;
}
function IsEmailInMsgrBuddy(strEmail)
{
var AllUsers = new Array();
var BuddyList = MsgrObj.List(0);
var nUser=0;
for (nUser=0; nUser<BuddyList.Count; nUser++)
{
if (BuddyList.Item(nUser).EmailAddress == strEmail)
{	
switch (BuddyList.Item(nUser).State)
{
case 1:
return 1;	// emailAddress is in buddy list but not online
default:
return 2;	// emailAddress is in buddy list and online
}
}
}
return 0;	// emailAddress is NOT in the buddy list
}
function DoInboxIM()
{
CA(); //Check the States
var DataTable;
var State = MsgrObj.LocalState;
if (isStateOnline(State))
{
DoUsers();
DataTable = document.all.MsgTable;	
for (i=1; i<DataTable.rows.length; i++)
{
if (DataTable.rows[i].cells.length>=6)
{
var E = DataTable.rows[i].cells[0].name;
E = E.replace(/\n/g,"");
if (UserAdd[E] != null)
{
DataTable.rows[i].cells[2].innerHTML = '<table cellpadding=0 cellspacing=0 style="position:relative;"><tr><td nowrap style="border:none">'+DataTable.rows[i].cells[2].innerHTML+'</td><td width="100%"></td><td style="border:none">'+getUserWithState(UserAdd[E],"IB")+'</td></tr></table>'
}
else if ( (UserNotOn[E] != null) && (DataTable.rows[i].cells[2].children[0].tagName=="TABLE"))
{
DataTable.rows[i].cells[2].innerHTML = DataTable.rows[i].cells[2].children[0].rows[0].cells[0].innerHTML;
}	
}
}
}
}
function DoAddressesSubmit()
{
if ("undefined" == typeof(MsgrObj))
{	//the object wasn't created
return;
}
var DataTAble;
var State = MsgrObj.LocalState;
if (isStateOnline(State))
{
DoUsers();
DataTable = document.all.msngrdata;
for (i=0;i<=2;i++)
{
if ( (DataTable.rows[i].cells[3].children[0].checked) && (DataTable.rows[i].cells[3].children[0].disabled==false) && (AllUsers[DataTable.rows[i].cells[2].children[0].value]==null))
{
DoSilentAdd(DataTable.rows[i].cells[2].children[0].value)
}
}
}
}
function CheckAddressInput()
{
var CB = this.parentElement.parentElement.cells[3].children[0];
if (ValidateEmail(this.value))
{
if (AllUsers[this.value] == null)
{
CB.disabled=0;
}
else
{
CB.disabled=1;
}
}
else
{
CB.disabled=1;
}
}
function DoAddresses()
{
var DataTable;
var State = MsgrObj.LocalState;
var strEmail = "";
var activeFlag =0;
if (isStateOnline(State))
{
document.all.msngrH.innerHTML='<font class="sb"><b>'+L_AddToMy_Text+'</b>';
DataTable = document.all.msngrdata;
for (i=0;i<=2;i++)
{
DataTable.rows[i].cells[2].children[0].onchange=CheckAddressInput;
strEmail = DataTable.rows[i].cells[2].children[0].value;
activeFlag = IsEmailInMsgrBuddy(strEmail);
if (strEmail)
{
if (activeFlag>0) // already in the buddy list (can be online or offline)
{
DataTable.rows[i].cells[3].innerHTML='<input type=checkbox checked name="msngr'+i+'" value="">';
}
else // not in the buddy list (not yet)
{
DataTable.rows[i].cells[3].innerHTML='<input type=checkbox name="msngr'+i+'" value="">';
}
}
else
{
DataTable.rows[i].cells[3].innerHTML='<input type=checkbox name="msngr'+i+'" value="" disabled checked>';
}
}
}
document.addr.alias.focus();
}
function DoSaveAddress()
{
var DataTAble;
var State = MsgrObj.LocalState;
if (isStateOnline(State))
{
DoUsers();
DataTable = document.all.msngrdata;
for (i=1;i<DataTable.rows.length;i++)
{
var E = DataTable.rows[i].cells[0].children[0].rows[0].cells[2].id;
var from = DataTable.rows[i].cells[0].children[0].rows[0].cells[0].id;
if (AllUsers[E] == null)
{
MyRow = DataTable.rows[i].cells[0].children[0].insertRow(4);
MyRow.insertCell();
MyRow.cells[0].colSpan=4;
MyRow.cells[0].style.backgroundColor="#DBEAF5";
MyRow.cells[0].align = "center";
MyRow.cells[0].innerHTML = '<font class="f" size=2><input type="checkbox" name="msngr'+E+'" value="'+E+'"'+from+' onClick="CheckCheckAll();"> '+L_Add_Text+E+L_MyMessList_Text+'</font>'+'';
}
}
}
}
function DoNotJunkMail()
{
var DataTAble;
var State = MsgrObj.LocalState;
if (isStateOnline(State))
{
DoUsers();
DataTable = document.all.msngrdata;
var E = DataTable.rows[0].cells[1].id;
if (AllUsers[E] == null)
{
MyRow = DataTable.insertRow(4);
MyRow.insertCell();
MyRow.cells[0].colSpan=4;
MyRow.cells[0].align = "left";
MyRow.cells[0].innerHTML = '<font class="f" size=2><input type="checkbox" name="msngr'+E+'" value="'+E+'" checked> '+L_Add_Text+E+L_MyMessList_Text+'</font>';
}
}
}
function DoNotJunkMailSubmit()
{
if ("undefined" != typeof(MsgrObj))
{	
if (isStateOnline(MsgrObj.LocalState))
{
for (var i=0;i<document.addtoaddressbook.elements.length;i++)
{
var e = document.addtoaddressbook.elements[i];
if ( (e.name != 'allbox') && (e.name.match(/msngr/)) && (e.checked) )
{
DoSilentAdd(e.value);
}
}
}
}
}
function DoSaveAddressSubmit()
{
if ("undefined" != typeof(MsgrObj) && document.domsgaddresses)
{	
if (isStateOnline(MsgrObj.LocalState))
{
for (var i=0;i<document.domsgaddresses.elements.length;i++)
{
var e = document.domsgaddresses.elements[i];
if ( (e.name != 'allbox') && (e.name.match(/msngr/)) && (e.checked) )
{
DoSilentAdd(e.value);
}
}
}
}
}
function DoSilentAdd(email)
{
var list = MsgrObj.List(0);
var services = MsgrObj.Services
var NewUser = MsgrObj.CreateUser(email,services.Item(0));
list.Add(NewUser);
}
function DoABIM()
{
var DataTable;
var State = MsgrObj.LocalState;
if (isStateOnline(State))
{
DoUsers();
DataTable = document.all.ListTable;	
for (i=2; i<DataTable.rows.length; i++)
{
if (DataTable.rows[i].cells.length==4)
{
var E = DataTable.rows[i].cells[3].children[0].innerHTML;
if (AllUsers[E] != null)
{
DataTable.rows[i].cells[2].innerHTML = '<table cellpadding=0 cellspacing=0 style="position:relative;"><tr><td nowrap style="border:none;">'+DataTable.rows[i].cells[2].innerHTML+'</td><td width="100%" ></td><td style="border:none;">'+getUserWithState(AllUsers[E],"IB")+'</td></tr></table>'
}
}
}
}
}
function DoQuickListMsngr()
{
var qlt;
var State = MsgrObj.LocalState;
if (isStateOnline(State))
{
DoUsers();
qlt = document.all.quicklist;
for (i=1; i<qlt.rows.length; i++)
{
Data = qlt.rows[i].cells[5];
if ("undefined" != typeof(Data.name))
{
if ( (Data.name.indexOf(",") == -1) && (Data.name.indexOf("@") != -1) && (Data.name !="" ))
{
var Address = Data.name.match(/(\w+@.+\.\w+)/);
var U = Address[1];
if (AllUsers[U] != null)
{
Data.innerHTML = '<table cellpadding=0 cellspacing=0 style="position:relative;"><tr><td style="border-bottom:none;" nowrap>'+Data.innerHTML+'</td><td width="100%"></td><td style="border-bottom:none;">'+getUserWithState(AllUsers[U],"IB")+'</td></tr></table>'
}
}
}
}
}
}
function DoConfirmHome()
{
var content = "";
var TabH = 0;
var CliH = 0;
var FatH = 0;
var Ph = 0;
var LocState = MsgrObj.LocalState;
document.all.msngrheading.innerHTML = "&nbsp;<font color='#eff7ff' ><b>" + L_MessBud_Text + "</b></font>"	
if (isStateOnline(LocState))
{
document.all.msngrcontent.style.textAlign="left";
content = DoFullList(false);
document.all.msngrblock.children[4].innerHTML=content;
CliH = document.all.msngrblock.children[4].clientHeight;
TabH = document.all.msngrcontent.parentElement.parentElement.clientHeight;
FatH = document.all.msngrblock.children[0].clientHeight+document.all.msngrblock.children[3].clientHeight;
if (CliH > TabH - FatH)
{	
document.all.msngrcontent.style.height = TabH + 40 - FatH;
document.all.msngrpush.style.height = TabH + 40 - FatH;
}
}
else if (LocState != null)
{
content = '<A HREF="JavaScript:DoMsngrLink()"><font class="f"><p><b>' + L_SignIn_Text + '</b></font></A>';
CliH = document.all.msngrblock.children[4].clientHeight;
TabH = document.all.msngrcontent.parentElement.parentElement.clientHeight;
FatH = document.all.msngrblock.children[0].clientHeight+document.all.msngrblock.children[3].clientHeight;
if (CliH>TabH-FatH)
{
document.all.msngrpush.style.height= TabH + 40 - FatH;
document.all.msngrcontent.style.height= TabH + 40 - FatH;
}
}
document.all.msngrblock.children[2].innerHTML=content;
document.all.msngrcontent.innerHTML=content;
}
function DoNoMsngrConformHome()
{
if (eval(WatchCount) == 1)
content = '<font class="f" size="1">' + L_WCS_Text + MsgrLink +'</font>';
else if (eval(WatchCount)>=1)
content = '<font class="f" size="1">' + WCP + MsgrLink +'</font>';
else
content = '<font class="f" size="1">' + RandMsg() +'</font>' + '&nbsp;';
document.all.msngrblock.children[2].innerHTML = content;
document.all.msngrcontent.innerHTML= content;
}
function DoConfirm()
{
var content = "";
var TabH = 0;
var CliH = 0;
var FatH = 0;
var LocState = MsgrObj.LocalState;
if (isStateOnline(LocState))
{
document.all.msngrcontent.style.textAlign="left";
content = DoFullList(true);
document.all.msngrblock.children[4].innerHTML=content;
CliH = document.all.msngrblock.children[4].clientHeight;
TabH = document.all.msngrcontent.parentElement.parentElement.clientHeight;
FatH = document.all.msngrblock.children[0].clientHeight+document.all.msngrblock.children[3].clientHeight;
if (CliH>TabH-FatH)
{	
document.all.msngrcontent.style.height=TabH+-(FatH+35);
document.all.msngrpush.style.height=TabH+-(FatH+35);
}
document.all.msngrkey.style.visibility="visible";
}
else if (LocState != null)
{
document.all.msngrcontent.style.textAlign="left";
content = '<A HREF="JavaScript:DoMsngrLink()"><font class="f" size=2><p><b>' + L_SignIn_Text + '</b></font></A>';
CliH = document.all.msngrblock.children[4].clientHeight;
TabH = document.all.msngrcontent.parentElement.parentElement.clientHeight;
FatH = document.all.msngrblock.children[0].clientHeight+document.all.msngrblock.children[3].clientHeight;
if (CliH>TabH-FatH)
{
document.all.msngrpush.style.height=TabH+-(FatH+35);
document.all.msngrcontent.style.height=TabH+-(FatH+35);
}
}
document.all.msngrblock.children[2].innerHTML=content;
document.all.msngrcontent.innerHTML=content;
}
function DoNoMsngrConform()
{
if (eval(WatchCount)==1)
content = '<font class="f" size=2>' + L_WCS_Text + MsgrLink +'</font>';
else if (eval(WatchCount) > 1)
content = '<font class="f" size=2>' + WCP + MsgrLink +'</font>';
else
content = '<font class="f" size=2>' + RandMsg() +'</font>';
document.all.msngrblock.children[2].innerHTML=content;
document.all.msngrcontent.innerHTML=content
}
function DoFullList(displayOnlineHeader)
{
var ret="";
var Off="";
var On="";
var OnC=0;
var OffC=0;
OffA = new Array();
OnA = new Array();
var list = MsgrObj.List(0);
for (i=0; i<list.Count; i++)
{
switch (list.Item(i).State)
{
case 1:
OffA[OffC]=list.Item(i).FriendlyName + ':&:' +i;
OffC++;
break;
default:
OnA[OnC]=list.Item(i).FriendlyName + ':&:' +i;
OnC++;
break;
}
}
OnA.sort(function (a,b){ var nA=a.toLowerCase(),nB=b.toLowerCase(); if(nA>nB) return 1; if (nA<nB) return -1; return 0;});
OffA.sort(function (a,b) { var nA=a.toLowerCase(),nB=b.toLowerCase(); if(nA>nB) return 1; if (nA<nB) return -1; return 0;});
for (i=0; i<OnA.length;i++)
{
tmpA = OnA[i].split(/:&:/);
On += getUserWithState(tmpA[1],"CONF");
}
for (i=0;i<OffA.length;i++)
{
tmpA = OffA[i].split(/:&:/);
Off += getUserWithState(tmpA[1],"CONF_OFF");
}
if (displayOnlineHeader)
{
if (On.length==0)
On = '<tr><td colspan=2>&nbsp;&nbsp;<font class="f" size=2>' +L_NoBudOnline_Text + '</font></td></tr>';
On = '<tr valign="middle"><td><img src="http://64.4.16.24/icon_messenger5.gif"></td><td><font class="f" size=2><b>' + L_BudOnline_Text + '</b></font></td></tr>' + On;
}
else
{
if (On.length==0)
On = '<tr><td colspan=2><font class="f" size=2>' +L_NoBudOnline_Text + '</font></td></tr>';
}
if (Off.length!=0)
Off = '<tr valign="middle"><td><img src="http://64.4.16.24/icon_messenger6.gif"></td><td><font class="f" size=2><b>' + L_BudOffline_Text + '</b></font></td></tr>' + Off;
ret = '<table border=0 cellspacing=3 cellpadding=0>' + On + '<tr><td>&nbsp;</td></tr>' + Off + '</table>';
return ret;
}
function CheckForOnline()
{
var State = MsgrObj.LocalState;
if (isStateOnline(State))
{
var strFromText = document.all.FromText.value;
DoUsers();
if (document.all.MsgHeaders.rows[1].cells[0].id == "From")
{
if ( (AllUsers[strFromText] != null) && (strFromText != null))
{
var TheHtml = getUserWithState(AllUsers[strFromText],"RM");
DoTheRow(TheHtml);
}
else
{
DoImdom();
DoNotList();
var results = strFromText.match(/(.+)@(.+)/);
if ((IMdom[results[2]]) && (NotList[strFromText]==null) && (UserNotOn[strFromText]==null) )
{
var TheHtml = '<font class="m"><A HREF="'+ SaveAddLink +'">' + L_Add_Text + strFromText + '</a>' + L_ContactList_Text;
DoTheRow(TheHtml);
}
}
}
}
}
function DoNotList()
{
var NotAdd = ["tlakshminarayana","offershelp","viod","web_communities","staff","_esc_costarica","_esc_manila","_esc_mla_sykesredmond","_esc_policy_sunnyvale","_esc_tech_sunnyvale","abuse","Addressbook_Abuse","Addressbook_esc_Manila","Addressbook_Privacy","Addressbook_ts","bugreporter","datfix","DT_Hotmail","DT_MSN_Addressbook","HM_InternalEsc","hotmail_training","Hotmailprivacy","Hotmailprivacy_esc","microsoftcom_contactus","mmssupport","msncom_ca_en","msncom_us","passport","postmaster","premium_x","service_x","support_x","Hotmailprivacy","oebeta","sales","forgotpass","ycache","support","whatispp","invalidpass","changepass","createacct","formatadd","changeacct","yperson","prefopt","closeacct","whatismms","helpsend","howcheck","howfolder","saveprint","set_remind","addressbook","memdir","attachhelp","notifi","deletehelp","popmail","sighelp","mwdict","classify_2000","e_greetings","wchelp","hmoex","bulk_mail","hotmailalert","intruslog","whomd","acctsize","blockdom","speedissue","misdirect","mailprob","multsend","webtvhelp","maillisthelp","dnsprob","poperr","othererrors","abouthm","anti_viruses","adtag","teltext","helplink","frame_nframe","timestamp","homepagehelp","welchome","contactpartn","howsecure","commentquest"];
NotList = new Object();
for (No=0; No<NotAdd.length; No++)
{
var Ad = NotAdd[No] + "@hotmail.com";
NotList[Ad] = No;
}
NotList[MsgrObj.LocalLogonName.toLowerCase()] = 1;
}
function DoTheRow(TheJist)
{
MyTable = document.all.MsgHeaders;
//Since We are not handeling any events, don't need to check for the ID
MyRow = MyTable.insertRow();
MyRow.insertCell();
MyRow.cells[0].innerHTML=TheJist;
}
function DoImdom()
{
IMdom = new Object();
IMdom["hotmail.com"] = "1";
IMdom["msn.com"] = "1";
}
function DoUsers()
{
UserAdd = new Object();
UserNotOn = new Object();
AllUsers = new Object();
var lnout = "";
var State = MsgrObj.LocalState;
var nUser = 0;
var nOnlineUsers = 0;
if (isStateOnline(State))
{
var list = MsgrObj.List(0);
for (nUser=0; nUser<list.Count; nUser++)
{
AllUsers[list.Item(nUser).EmailAddress]=nUser;
switch (list.Item(nUser).State)
{
case 1:
UserNotOn[list.Item(nUser).EmailAddress]=nUser;
break;
default:
UserAdd[list.Item(nUser).EmailAddress]=nUser;
UserArr[nOnlineUsers]=nUser;
nOnlineUsers++;
break;
}
}
}
return nOnlineUsers;
}
function getOnlineList()
{
var txt = "";
var State = MsgrObj.LocalState;
var nUser = 0;
if (isStateOnline(State))
{
var list = MsgrObj.List(0);
var nOnlineUsers = DoUsers();
if( nOnlineUsers > 0 )
{
if (nOnlineUsers==1)
{
txt = getUserWithState(UserArr[0]);
}
else if (nOnlineUsers==2)
{
txt = getUserWithState(UserArr[0]) + '<br>' + getUserWithState(UserArr[1]);
}
else
{
txt = getUserWithState(UserArr[Math.round(Math.random()*(nOnlineUsers+-1))]) + '<br><img src="http://64.4.16.24/spacer.gif" width="13"> <A HREF="JavaScript:instantMessage(%22-2%22)"><i><FONT class="snub" size=2>' + (nOnlineUsers+-1) + L_More_Text + '</font></i></a>';
}
}
else
txt = '<font class="f" size=2">' + L_NoContacts_Text + '</font><br>';
}
else
{
if (State != null)
{
txt = '<A HREF="JavaScript:instantMessage(%22-1%22)"><font class="f" size=2>' + L_LogOn_Text + '</font></A>';
}
else
{
if (eval(WatchCount)==1)
txt = '<font class="f" size=2>' + L_WCS_Text + MsgrLink +'</font>';
else if (eval(WatchCount)>1)
txt = '<font class="f" size=2>' + WCP + MsgrLink +'</font>';
else
txt = '<font class="f" size=2>' + RandMsg() +'</font>';
}
}
if (State != null)
{
document.all.Imsngr.vAlign ="top";
txt = '<font class="f" size=2 color="#990000"><b>' + L_OLC_Text + '</b></font><br>' + txt;
}
document.all.Imsngr.innerHTML = txt;
}
function addMessengerAd()
{
var txt = "";
if (eval(WatchCount)==1)
txt = '<font class="f" size=2>' + L_WCS_Text + MsgrLink +'</font>';
else if (eval(WatchCount)>1)
txt = '<font class="f" size=2>' + WCP + MsgrLink +'</font>';
else
txt = '<font class="f" size=2>' + RandMsg() +'</font>';
document.all.Imsngr.innerHTML = txt;
}
function instantMessage(n)
{
var State = MsgrObj.LocalState;
if (1 != State)
{
//the user is logged on
if (n>=0)
{
pUsers = MsgrObj.List(0);
pUser = pUsers.Item(parseInt(n));
if(pUser.LogonName != MsgrObj.LocalLogonName)
{
//make sure we're not trying to IM ourself
MsgrApp.LaunchIMUI(pUser);
}
}
else if (-1==n)
{
MsgrApp.Visible=1;
MsgrApp.LaunchLogonUI();
}
else if (-2==n)
{
MsgrApp.Visible=1;
}
}
else
{
MsgrApp.Visible=1;
MsgrApp.LaunchLogonUI();
}
}
function RandMsg()
{
var ret;
ret = content[Math.round(Math.random()*2)] + MsgrLink;
return ret;
}
function DoMsngrLink()
{
if ("undefined" == typeof(MsgrObj))
{	
window.navigate("http://go.msn.com/ZZR/EN-IN/f.asp");
}
else
{
var State = MsgrObj.LocalState;
switch (State)
{
case 2:
instantMessage(-2);
break;
case 1:
instantMessage(-1);
break;
default:
window.navigate("http://go.msn.com/ZZR/EN-IN/f.asp");
break;
}
}
}
function ValidateEmail(IsItReal)
{
var ret = false;
if (typeof(IsItReal) != "undefined")
{
IsItReal = IsItReal.match(/(\w+)@(.+)\.(\w+)$/);
if (IsItReal !=null)
{
if ((IsItReal[3].length==2) || (IsItReal[3].length==3))
ret = true;
}
}
return ret;
}
function HTMLencode(strToCode)
{
strToCode = strToCode.replace(/</g,"&lt;");
strToCode = strToCode.replace(/>/g,"&gt;");
return strToCode;
}
//<script language="JavaScript">
//helppane.js Version 1.5
//This version doesn't do document.domain setting
var h_win
var iTopicTimer
var Topic_URL
var help_w, help_h, help_l, help_t, fudgeW
var bResize = true
var NoMax = 0
H_VER='1.5'
function GetClientURL()
{
return escape(document.location.protocol + "//" + document.location.hostname)
}
function GetClientParams()
{
return escape(document.location.search)
}
function setCurrentDomain(){
selfURL = document.domain //selfURL.substring(i1,i2)
var URLsegments = selfURL.split(".")
if (URLsegments.length > 1)
{
stEndSeg = URLsegments[URLsegments.length-1]
if (stEndSeg== "com" || stEndSeg == "net")
{ document.domain = (URLsegments[URLsegments.length-2] + "." + URLsegments[URLsegments.length-1])}
}
}
function reMax()
{
if (bScreen)
{
SniffSizing()
if(agent_isNS && (screen.availWidth != window.innerWidth) && agent_Major < 5)
{
top.window.resizeTo(screen.availWidth -(window.outerWidth - window.innerWidth), screen.availHeight - (window.outerHeight-window.innerHeight))
top.window.moveTo(0,0)	
}
else
{
if(agent_isAOL==false || agent_isMac==true)
{
top.window.resizeTo(screen.availWidth, screen.availHeight - startbarH - aoltoolbar)
top.window.moveTo(0,(startbarH * mac_heightoffset)+aoltoolbar-1)
}
}
}
}
function SniffSizing()
{
fudgeW = 0
if (agent_isMac==true)
{
if (agent_Major == 4)
{
fudgeW = 7
mac_heightoffset = 1.7
startbarH = (screen.height-screen.availHeight)
startbarW = (screen.width-screen.availWidth)
}
else
{
fudgeW = 2
mac_heightoffset=0
startbarH = 0//(screen.height-screen.availHeight)
startbarW = (screen.width - screen.availWidth)
}
if(agent_isAOL==true)
{
WIDTH = 248
aoltoolbar = 70
}
else
{
if(agent_Major==4)
{
WIDTH = 230
}
else
{
WIDTH = 230
}
aoltoolbar=0
}
}
else
{
mac_heightoffset = 0
startbarH = 0
startbarW = 0
if(screen.width <= 800)
{
WIDTH = 180
}
else
{
WIDTH = 230
}
if(agent_isAOL==true)
{
aoltoolbar = 150
}
else
{
aoltoolbar=0
}
}
}
function SizeforHelp()
{
if(agent_isNS && (screen.availWidth - WIDTH != window.innerWidth) && agent_Major < 5)
{
top.window.resizeTo(screen.availWidth - WIDTH - (window.outerWidth - window.innerWidth), screen.availHeight - (window.outerHeight-window.innerHeight))
top.window.moveTo(0,(startbarH * mac_heightoffset)+aoltoolbar)	
}
else
{
help_h=help_h - startbarH - aoltoolbar
if(agent_isAOL==false || agent_isMac==true)
{
top.window.resizeTo(screen.availWidth - WIDTH - (startbarW*fudgeW), screen.availHeight - startbarH-aoltoolbar)
top.window.moveTo(0,(startbarH * mac_heightoffset)+aoltoolbar)
}
}
}
function DoHelp(bLocTestWindows)
{
//document.domain = getCurrentDomain()
var domaincheck = document.domain
//bSearch is set in calling page
Topic_URL="INI="+H_CONFIG+"&H_APP="+escape(L_H_APP)
if (bSearch==true)
{
//do context sensative search
Topic_URL = "?"+Topic_URL+"&SearchTerm="+escape(H_KEY)+"&S_Text="+escape(L_H_TEXT)
}
else
{	
//jump directly to topic
Topic_URL = "?Topic="+H_TOPIC+"&"+Topic_URL
}
//name the window, so that topic from Help window can change URL of main app window.
window.name="msnMain";
if(agent_isAOL==false || agent_isMac==true)
{
//for Non AOL-WIN browsers
myURL = H_URL_BASE+"/helpwindow.asp"+Topic_URL+"&BrandID="+H_BRAND+"&Filter="+H_FILTER+"&H_VER="+H_VER
}
else
{
//for AOL-WIN versions. AOL-WIN have problems displaying after redirection & don't resize well
myURL = H_URL_BASE+"/frameset.asp"+Topic_URL+"&BrandID="+H_BRAND+"&Filter="+H_FILTER+"&H_VER="+H_VER
}
myURL = myURL + "&NoMax="+NoMax + "&v1="+GetClientURL() + "&v2=" + GetClientParams()
var agent_MSNMajor = ''
var agent_MSNMinor = ''
var agent_isWebTV = (agent.indexOf('webtv')>0)
var agent_isMSNCompanion = (agent.indexOf('msn companion') >= 0)
if (agent_isMSNCompanion == false)
{
if (agent.indexOf('msn ')>0) {
version = version.substr(version.indexOf("msn ")) //get past msn and the space
agent_MSNMajor = version.substring(version.indexOf(".")-1,version.indexOf("."))
if (agent_MSNMajor >= 6)
{
agent_isMSN = true
if (version.indexOf(0,";")>0)
agent_MSNMinor = version.substring(version.indexOf(".")+1, version.indexOf(";"))
else
agent_MSNMinor = version.substring(version.indexOf(".")+1, version.indexOf(")"))
}
else
{
agent_isMSN = false
}
}
}	
if (agent_isMSN && agent_MSNMinor != '0b1')
{
if(screen.width <= 800)
{
WIDTH = 180
}
else
{
WIDTH = 230
}
window.external.showHelpPane(myURL, WIDTH)
//h_win=window.open(myURL,"_help")
}	
else if (agent_isWebTV || agent_isMSNCompanion)
{
//webtv doesn't handle window.open very well, so just change the current windows href
top.location.href=myURL
}
else
{
if (bLocTestWindows == null)
windowName = '_help'
else
windowName = '_help'+Math.floor(Math.random()*100)
//set defaults for Help window size for 3.x browsers
help_w=230;help_h=450;help_l=640-help_w;help_t=0;
//bScreen is set by calling page - bScreen means can do screen.availWidth stuff
if(bScreen == true)
{
SniffSizing()
if (NoMax == 0) SizeforHelp()
help_w = WIDTH;
help_h = screen.availHeight;
help_l = screen.availWidth - WIDTH;
w_dressing = "toolbar=0,status=0,menubar=0,width="+help_w+",height="+help_h+",left="+help_l+",top="+help_t+",resizable=1"
}
else
{
//3.x browsers
w_dressing = "toolbar=0,status=0,menubar=0,width="+help_w+",height="+help_h+",,,resizable=1"
}
if(bScreen == true && agent_isNS == false && h_win != null && agent_isMac == false && agent_Major ==4)
{
if (H_URL_BASE.indexOf(domaincheck) > -1 && !(h_win.closed)) {
h_win.name=''
h_win.close()
}
else
{
h_win = null
}
}
bResize = false
h_win=window.open(myURL,windowName, w_dressing)
if(agent_isNS && agent_isMac)
h_win=window.open(myURL,windowName, w_dressing);
}
}
//set the document.domain to a subdomain everytime .js file is loaded.
var ap = navigator.appName.toLowerCase()
var version = navigator.appVersion.toLowerCase()
var agent = navigator.userAgent.toLowerCase()
var agent_isMSN = (agent.indexOf('msn 6') >= 0)
var isNS = ap.indexOf('netscape') >= 0
var isver4 = version.substr(0,1) == '4'
//if (!(isNS && isver4))
// if (!agent_isMSN)
// setCurrentDomain()
var L_H_APP = "MSN+Hotmail";
var H_CONFIG = "hotmailv3.ini";
var bSearch = false;
var H_TOPIC = "";
if (H_KEY.toLowerCase().indexOf('htm') == -1)
{
bSearch = true;
}
else
{
bSearch = false;
H_TOPIC = H_KEY;
}
var H_BRAND = '';
var H_FILTER = '';
if (((agent_isNS) || (agent_isIE) || (agent_isMac)) && (navigator.appVersion.indexOf("4.")>=0)) 
bScreen = true;
else
bScreen = false;
var agent_Major = 0	// an integer;
if (agent_isIE && navigator.appVersion.indexOf("MSN") == -1) {
agent_Major = navigator.appVersion.substr(navigator.appVersion.indexOf("MSIE") + 5,navigator.appVersion.indexOf("."));
agent_Major = parseInt(agent_Major); 
}
if (agent_isNS) 
agent_Major = parseInt(navigator.appVersion.substr(0,2));
var alphaChars = "abcdefghijklmnopqrstuvwxyz";
var digitChars = "0123456789";
var asciiChars = alphaChars + digitChars + "!\"#$%&'()*+,-./:;<=>?@[\]^_`{}~";
ie = document.all?1:0
ns4 = document.layers?1:0
dodiv=0;
function isASCII(str){	
var v_len = str.length;
var i;	
for (i = 0; i < v_len; i++)	
{
if (asciiChars.indexOf(str.charAt(i)) == -1) 
return false;
}
return true;
}
function ValidateEmail(str){
var resultStr = str.replace(/ /gi, "");	
var atIndex = resultStr.indexOf("@");
var dotIndex = resultStr.lastIndexOf(".");
if( resultStr == "" || !isASCII(resultStr) || dotIndex == -1)	
return "";
if ( resultStr.lastIndexOf("@") != atIndex || resultStr.charAt(atIndex+1) == ".")
return "";
if ( atIndex <= 0 || dotIndex < atIndex || dotIndex >= resultStr.length-1)	
return "";
return resultStr;	
}
function ValidateDomain(str){
var resultStr = str.replace(/ /gi, "");
var atIndex = resultStr.indexOf("@");
var dotIndex = resultStr.lastIndexOf(".");
if( resultStr=="" || !isASCII(resultStr) || dotIndex == -1)
return "";
if ( atIndex > 0 || resultStr.charAt(atIndex+1) == "." || dotIndex >= resultStr.length-1 )	
return "";
return resultStr.replace(/@/i, "");	
}
function isEmail(str) {
var pass = 0;
if (window.RegExp) {
var tempStr = "a";
var tempReg = new RegExp(tempStr);
if (tempReg.test(tempStr)) pass = 1;
}
if (!pass) 
return (str.indexOf(".") > 2) && (str.indexOf("@") > 0);
var r1 = new RegExp("(@.*@)|(\\.\\.)|(@\\.)|(^\\.)");
var r2 = new RegExp("^[a-zA-Z0-9\\.\\!\\#\\$\\%\\&\\'\\*\\+\\-\\/\\=\\?\\^\\_\\`\\{\\}\\~]*[a-zA-Z0-9\\!\\#\\$\\%\\&\\'\\*\\+\\-\\/\\=\\?\\^\\_\\`\\{\\}\\~]\\@(\\[?)[a-zA-Z0-9\\-\\.]+\\.([a-zA-Z]{2,3}|[0-9]{1,3})(\\]?)$");
return (!r1.test(str) && r2.test(str));
}
function CA(){
for (var i=0;i<frm.elements.length;i++)
{
var e = frm.elements[i];
if ((e.name != 'allbox') && (e.type=='checkbox'))
{
e.checked = frm.allbox.checked;
if (frm.allbox.checked)
hL(e);
else
dL(e);
}
}
}
function CCA(CB){
if (CB.checked)
hL(CB);
else
dL(CB);
var TB=TO=0;
for (var i=0;i<frm.elements.length;i++)
{
var e = frm.elements[i];
if ((e.name != 'allbox') && (e.type=='checkbox'))
{
TB++;
if (e.checked)
TO++;
}
}
if (TO==TB)
frm.allbox.checked=true;
else
frm.allbox.checked=false;
}
function hL(E){
if (ie)
{
while (E.tagName!="TR")
{E=E.parentElement;}
}
else
{
while (E.tagName!="TR")
{E=E.parentNode;}
}
E.className = "H";
}
function dL(E){
if (ie)
{
while (E.tagName!="TR")
{E=E.parentElement;}
}
else
{
while (E.tagName!="TR")
{E=E.parentNode;}
}
E.className = "";
}
