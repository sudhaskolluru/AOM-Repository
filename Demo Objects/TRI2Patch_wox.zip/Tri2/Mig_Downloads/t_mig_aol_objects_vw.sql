CREATE OR REPLACE VIEW T_MIG_AOL_OBJECTS_VW AS
SELECT object_type,object_name,application_short_name, owner
  FROM
  (
  SELECT 'CONCURRENT_PROGRAM_NAME' object_type,
       fcpt.user_concurrent_program_name || '-->' ||
       fcp.concurrent_program_name object_name,
       application_short_name,
       null owner
  FROM apps.fnd_concurrent_programs    fcp,
       apps.fnd_concurrent_programs_tl fcpt,
       apps.fnd_application            fa
 WHERE fcp.concurrent_program_id = fcpt.concurrent_program_id
   AND fcp. application_id = fa.application_id
   AND fcpt.application_id = fa.application_id
  UNION
  SELECT 'EXECUTABLE_NAME' object_type,
       fet.user_executable_name || '-->' || fe.executable_name object_name,
       application_short_name,
       null owner
  FROM apps.fnd_executables fe, fnd_executables_tl fet, fnd_application fa
 WHERE fe.executable_id = fet.executable_id
   AND fe. application_id = fa.application_id
   AND fet.application_id = fa.application_id
  UNION
  SELECT 'REQUEST_GROUP_NAME' object_type,
       fet.request_group_name object_name,
       application_short_name,
       null owner
  FROM fnd_request_groups fet, fnd_application fa
 WHERE fet.application_id = fa.application_id
  UNION
  SELECT 'LOOKUP_TYPE' object_type,
       flt.lookup_type object_name,
       application_short_name,
       null owner
  FROM fnd_lookup_types flt, fnd_application fa
 WHERE flt. application_id = fa.application_id
  UNION
  SELECT 'PROFILE_NAME' object_type,
       flt.USER_PROFILE_OPTION_NAME || '-->' || flt.profile_option_name object_name,
       application_short_name,
       null owner
  FROM fnd_profile_options_vl flt, fnd_application fa
 WHERE flt.application_id = fa.application_id
  UNION
  select 'ID_FLEX_CODE' object_type,
       fif.id_flex_name || '-->' || fif.id_flex_code || '-->' ||
       ffst.id_flex_structure_name,
       application_short_name,
       null owner
  from fnd_id_flexs fif, fnd_application fa, fnd_id_flex_structures_tl ffst
 where fif.application_id = fa.application_id
   and ffst.application_id = fif.application_id
   and fif.id_flex_code = ffst.id_flex_code
  UNION
  SELECT 'DESCRIPTIVE_FLEXFIELD_NAME' object_type,
       fdf.title || '-->' || fdf.descriptive_flexfield_name object_name,
       application_short_name,
       null owner
  FROM fnd_descriptive_flexs_tl fdf, fnd_application fa
 WHERE fdf.application_id = fa.application_id
  UNION
  SELECT 'MESSAGE_NAME' object_type,
       fnf.message_name object_name,
       application_short_name,
       null owner
  FROM fnd_new_messages fnf, fnd_application fa
 WHERE fnf.application_id = fa.application_id
  UNION
  SELECT 'FORM_NAME' object_type,
       fet.user_form_name || '-->' || fe.form_name object_name,
       application_short_name,
       null owner
  FROM fnd_form fe, fnd_form_tl fet, fnd_application fa
 where fe.form_id = fet.form_id
   and fe. application_id = fa.application_id
   and fet.application_id = fa.application_id
  UNION
  SELECT 'BNE_LAYOUTS' object_type,
       BL.LAYOUT_CODE,
       application_short_name,
       null owner
  FROM BNE_LAYOUTS_VL BL, FND_APPLICATION FA
 WHERE BL.APPLICATION_ID = FA.APPLICATION_ID
  UNION
  SELECT 'REQUEST_SET_NAME' object_type,
       frs.USER_REQUEST_SET_NAME || '-->' || frs.REQUEST_SET_NAME object_name,
       application_short_name,
       null owner
  FROM fnd_request_sets_vl frs, fnd_application fa
 WHERE fa.application_id = frs.application_id
  UNION
SELECT distinct XDL.LOB_CODE,
                'XML_PUB_REPORTS' object_type,
                FA.application_short_name,
                null owner
  FROM XDO_LOBS XDL, fnd_application fa
  UNION
 SELECT distinct XDD.DATA_SOURCE_CODE object_name,
                'XDO_DS_DEFINITIONS' object_type,
                fa.application_short_name,
                null owner
 FROM XDO_DS_DEFINITIONS_VL XDD, fnd_application fa
  UNION
  SELECT 'ORACLE_FORMS' object_type,
       ff.form_name object_name,
       application_short_name,
       null owner
  FROM fnd_form ff, fnd_application fa
 WHERE ff.application_id = fa.application_id
  UNION
  SELECT 'PRINTER_STYLE_NAME' object_type,
       fpsl.user_printer_style_name || '-->' || fpsl.printer_style_name object_name,
       null application_short_name,
       null owner
  FROM fnd_printer_styles_tl fpsl
  UNION
SELECT 'FND_USER_NAME' object_type,
       user_name object_name,
       null application_short_name,
       null owner
  FROM fnd_user
  UNION
  SELECT 'FND_RESPONSIBILITY_KEY' object_type,
       frv.RESPONSIBILITY_NAME || '-->' || f.responsibility_key object_name,
       null application_short_name,
       null owner
  FROM fnd_responsibility f, fnd_responsibility_vl frv
 WHERE f.responsibility_id = frv.RESPONSIBILITY_ID
  UNION
  SELECT 'FND_FORM_FUNCTION_NAME' object_type,
       function_name object_name,
       null application_short_name,
       null owner
  FROM FND_FORM_CUSTOM_RULES
  UNION
   SELECT 'FLEX_VALUE_SET_VALUE_NAME' object_type,
       fv.FLEX_VALUE object_name,
       null application_short_name,
       null owner
  FROM fnd_flex_values_vl fv
  UNION
  SELECT 'FND_ATTACHMENT_FUNCTIONS' object_type,
       faf.function_name object_name,
       null application_short_name,
       null owner
  FROM fnd_attachment_functions faf
  UNION
  SELECT 'MENU_NAME' object_type,
       fet.user_menu_name || '-->' || fe.menu_name object_name,
       null application_short_name,
       null owner
  FROM fnd_menus fe, fnd_menus_tl fet
 WHERE fe.menu_id = fet.menu_id
  UNION
  SELECT 'FLEX_VALUE_SET_NAME' object_type,
       SUBSTR(fv.flex_value_set_name,
              INSTR(fv.flex_value_set_name, '.') + 1) object_name,
       null application_short_name,
       null owner
  FROM fnd_flex_value_sets fv
  /* UNION
  SELECT 'VALUE_SET' object_type,
       ffv.flex_value_set_name object_name,
       null application_short_name,
       null owner
  FROM fnd_flex_value_sets ffv*/
  /* UNION
  SELECT 'DISCOVERER_REPORTS' object_type,
       DOC_NAME,
       null application_short_name,
       doc_created_by owner
  FROM EUL_US.EUL5_DOCUMENTS*/
  UNION
  SELECT 'FUNCTION_NAME' object_type,
       fet.user_function_name || '-->' || fe.function_name object_name,
       null application_short_name,
       null owner
  FROM fnd_form_functions fe, fnd_form_functions_tl fet
 WHERE fe.function_id = fet.function_id
  UNION
  SELECT 'ORACLE_WORKFLOW' object_type,
       t.display_name || '-->' || t.name object_name,
       null application_short_name,
       null owner
  from wf_item_types_tl t
 ORDER BY object_name
  );
