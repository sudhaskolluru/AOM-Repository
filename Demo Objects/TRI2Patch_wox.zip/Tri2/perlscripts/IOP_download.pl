#!/usr/bin/perl
use Expect;

#sub iop_download
#{

	
	
	$TIMEOUT = 120;  # Setting Timeout 
	# Expect Constant
	
		$S_USER_NAME='Administrator';
		$SOURCE_IP='192.168.0.206';
		$S_USER_PASSWD='welcome@123';
		$L_SEQNUM_BASE='/home/pddev/TrinitiApps28/MigBuild';
		$WINDOWS_IP='192.168.0.206';
		$WINDOWS_USERNAME='Administrator';
		$WINDOWS_PASSWORD='welcome@123';
	
		#$IOP_BIN='C:/oracle_iop/bin';
		$IOP_BIN='D:\IOP_Software\bin';
	       $IOP_USER='Admin';
		$IOP_USER_PWD='welcome1234';
		$INSTANCE_PORT_NUMBER=22;
	


	# Connecting to Source Machine
	#/////////////////////////////////
	$ssh = Expect->spawn("ssh -l $S_USER_NAME $SOURCE_IP");# Spawning secure shell process 

	$log = $ssh->log_file($logfile);

	$TIMEOUT = 5;

	# Checking whether it asks for exchange of keys
	if($ssh->expect(5,"connecting"))
	{
		print $ssh "yes\r";
	}
	if($ssh->expect(10,"password"))
	{ 
		# Checking for password promting

		print $ssh "$S_USER_PASSWD\r";

		if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
		{ 
			#Checking finally for command prompt

			print "\n##Connected to Destination instance..##\n";
		
			#if user registered is sudo user then switch to applmgr user and then execute commands
			if($IS_SUDO_USER eq "Yes")
			{
				print $ssh "sudo su - $SUDO_TO_USER\r";
				
				if($ssh->expect(10,"Password"))
				{ 
					# Checking for password promting
					
					print $ssh "$S_USER_PASSWD\r";

					if($ssh->expect($TIMEOUT,"\$") )# || $ssh->expect($TIMEOUT,"\>"))
					{ 
						print "\n##Finally Connected to Destination  from sudo login instance..##\n";
						
						print $ssh "cd .\r";
						print "Changed to directory\n";
						if($ssh->expect($TIMEOUT,"\$") || $ssh->expect($TIMEOUT,"\>"))
						{
							#logic to get hostname of the server, redirecting hostname to a file and then reading tht file
							print $ssh "hostname > host.txt\r";
							if($ssh->expect($TIMEOUT,"\$") || $ssh->expect($TIMEOUT,"\>"))
							{
		 						open hostfile, "host.txt";

								#open hostfile, "host.txt" or die $!;
								@raw_data=<hostfile>;
								close(hostfile);
		
								@tokensarr = split(/\./,@raw_data[0]);
								$HOST_NAME= $tokensarr[0];
 							}
							print "\nHost name of target server is...$HOST_NAME\n";	

							system("rm -r host.txt");

							#end of host name logic
						}

					}
					else
					{
						print "\n Connecting through sudo login failed\n";
					}
				}
			}

		}
		else
		{

			print "\n ## CONNECTION TIMED OUT IN GETTING CONNECTION  ## \n";
			exit;
		}
	}
	else
	{
		print "\n ### CONNECTION TIMED OUT IN MAKING CONNECTION### \n";
		exit;
	}
	


	# Change to SOURCE SEQNUM  BASE DIRECTORY
	#//////////////////////////////////	

	print $ssh "cd $S_SEQNUM_BASE\r";

	if($ssh->expect(15,"$SEQ_NUM"))
	{
		print "\n## Directory is changed ##\n";
	}
	else
	{
		print "\n ## CONNECTION TIMED OUT WHILE CHANGING THE DIRECTORY\n";

		$ssh->log_file(undef);	
		$ssh->hard_close();	
		exit;
	}

	#//////////////////////////////////

	# EXECUTING FNLOAD DOWNLOAD COMMAND

	#///////////////////////////////////

	print "\nobject type is ....$OBJ_TYPE \n";

	
	print "\n##Password is passed for Windows machine##\n";
	print $ssh "cd $IOP_BIN\r";
	#print $ssh "ls\r";
	if($ssh->expect($TIMEOUT,"\>") || $ssh->expect(700,"\$"))	
	{
		print "\nAfter DIR##\n";
		print $ssh "preparemigration.bat -u $IOP_USER -p $IOP_USER_PWD\r";

		if($ssh->expect(700,"\>") || $ssh->expect(700,"\$"))	
		{
			print "\nAfter prepare mig##\n";
			print $ssh "cd ..\r";
			#print $ssh "dir\r";
			print $ssh "jar cvf custom.zip custom\r";
			if($ssh->expect(1000,"\>") || $ssh->expect(700,"\$"))	
			{
				  print "\nAfter archiving custom folder##\n";
		     		  
				if($ssh->expect(100,"\>") || $ssh->expect(700,"\$"))	
				{
					print "\nAbout to do SCP..\n";
                        }
                        else
				{
					 print "\n Failed to create custom.zip \n";
				}

			}
		
		}
		else
		{
			print "\n ------Failed cntrl is in else\n";

		}
		
	}
	else
	{
		print "\n ## CONNECTION TIMED OUT, WINDOWS MACHINE NOT RESPONDING ## \n";
		exit;
}
	#/////////////////////////////////////////////////////////////////////////////////////////////////////



		
	#///////////////////////////////////
	#Copying files to respective directories
	# ///////////////////////////////////
	# copying log file from SOURCE SEQNUM BASE to LOCAL SEQNUM BASE Directory

	$TIMEOUT=15;
	
	#copying file from S_LOG_BASE to L_LOG_BASE

	print "\nDude this is an area of concern ->> scp -r $S_SEQNUM_BASE* $L_USER_NAME\@$LOCAL_IP:$L_SEQNUM_BASE \n";

	#print $ssh "scp -r custom.zip* $L_USER_NAME\@$LOCAL_IP:$L_SEQNUM_BASE\r";
	print $ssh "scp -r -P $L_INSTANCE_PORT_NUMBER $S_SEQNUM_BASE $L_USER_NAME\@$LOCAL_IP:$L_DOWNLOAD_BASE\r";
       print "\nDude this is an area of concern ->>scp -r -P $L_INSTANCE_PORT_NUMBER $S_SEQNUM_BASE $L_USER_NAME\@$LOCAL_IP:$L_DOWNLOAD_BASE \n";
	if($ssh->expect(10,"?"))
	{
		print $ssh "yes\r";
	}
	if($ssh->expect($TIMEOUT,"password"))
		{ 
			# Checking for password promting
	
			print $ssh "$L_USER_PASSWD\r";
			
			print "\n##Password is passed second time login##\n";
	
			if($ssh->expect($TIMEOUT,"\$") || $ssh->expect($TIMEOUT,"\>"))
			{ 
				#Checking finally for command promt
	
				print "\n##Connected to Destination Machine##\n";
				if($issudouser eq "Yes")
				{
					print $ssh "sudo su - $sudotouser\r";
					
					if($ssh->expect(10,"Password"))
					{ 
						# Checking for password promting
				
						print $ssh "$L_USER_PASSWD\r";
			
					}
					if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
					{ 
						print "\n##Connected to Destination Machine with sudo user##\n";
	
					}
			
				}
			}
	}
	else
	{
		print "\n ## CONNECTION TIMED OUT WHILE COPYING THE LOG FILES FROM SOURCE TO LOCAL MACHINE ##\n";
		$ssh->log_file(undef);	
		$ssh->hard_close();	
		exit;
	}
	if($ssh->expect($TIMEOUT,"100"))
	{

		print "\n## scp is continuing ...###\n";
		if($ssh->expect($TIMEOUT,"\$") || $ssh->expect($TIMEOUT,"\>"))
		{
			print "\n## scp of all LDT files is over...all files are copied##\n";
		}
 		else
		{
			print "\n## CONNECTION TIMED OUT Unable to Copy the LDT files ##\n";
			$ssh->log_file(undef);	
			$ssh->hard_close();	
			exit;
		}

		
	}

		
	$ssh->log_file(undef);	
	$ssh->hard_close();
	exit;
#}
#1;
