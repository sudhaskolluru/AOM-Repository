#!/usr/bin/perl 
#REQUIRED PROCEDURES
#///////////////////////////

require ("get_instance_details.pl");
require ("create_patch_on_hwbuild.pl");

#//////////////////////////////


$no_args = $#ARGV;
if($no_args  < 2)
{
	print "InSufficient Arguments....to connect_to_build.pl file\n";
	exit;
}
else
{
	print "perl connect_to_build.pl $DB_NAME $SRC_SIDE_LOCATION $PROJECT \n" ;

	my $i=0;
	$DB_NAME  =	@ARGV[$i++];
	print "Instance Name --> $DB_NAME \n";

	$SRC_SIDE_LOCATION	=	@ARGV[$i++];
	print "SRC_SIDE_LOCATION --> $SRC_SIDE_LOCATION \n";

       $PASS_WORD           =      @ARGV[$i++];
      # print "PASS_WORD is  --> $PASS_WORD \n";

	$PROJECT		=	@ARGV[$i++];

	print "PROJECT --> $PROJECT \n";

	$MIG_REQ_NUMBER		=	@ARGV[$i++];

	print "MIG_REQ_NUMBER--> $MIG_REQ_NUMBER\n";

       $PROJECT_NAME		=	@ARGV[$i++];

	print "PROJECT_NAME	--> $PROJECT_NAME	\n";

	$RELEASE_NAME		=	@ARGV[$i++];

	print "RELEASE_NAME--> $RELEASE_NAME\n";



	get_instance_details();

	create_patch_on_hwbuild();

	print "\n*********Patch Migration Process Completed********\n";
	exit();	
}
