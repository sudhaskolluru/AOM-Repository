
#!/usr/bin/perl 
#REQUIRED PROCEDURES
#///////////////////////////
require ("get_upload_aol_cmdline_var.pl");
require ("get_instance_details.pl");
require ("upload_LDT.pl");

#//////////////////////////////


$no_args = $#ARGV;
if($no_args  < 3)
{
	print "InSufficient Arguments....\n";
	print "Usage :\n";
	print "perl upload_aol.pl TPM10TST LDT_NAME LCT_NAME SRC_LDT_LOCN\n";
	exit;
}
else
{
	print "\n before calling get_upload_aol_cmdline_var()\n ";
	get_upload_aol_cmdline_var(@ARGV);

	print "\n after calling  get_upload_aol_cmdline_var()\n ";
	get_instance_details();

	# Preparing Connectiong string 
	$usr_passwd_dbname= $DB_USER.'/'.$DB_USER_PASSWD.'@'.$INSTANCE_SID;
	print "\nObject type here is ::$OBJECT_TYPE\n";

	if(($OBJECT_TYPE eq "DISCOVERER_REPORTS") || ($OBJECT_TYPE eq "DISCOVERER_BA_FOLDER"))
	{
		print "\n abt to call upload_discoverer_report()\n ";
		upload_discoverer_report();
	}
	else
	{
		print "\n abt to call upload_LDT()\n ";

		upload_LDT();
	}
	###With this command we are trying to clear confidential Information in log files..STARTs..########
       system("sh ../shellscripts/formatlogs.sh $OBJECT_TYPE $DB_USER_PASSWD > myperl.log");
       ###With this command we are trying to clear confidential Information in log files..ENDs..########
	#print "\n after calling upload_LDT()\n ";
	exit();

}
