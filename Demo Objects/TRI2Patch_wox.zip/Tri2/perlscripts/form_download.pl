#!/usr/bin/perl 
use Expect;

sub form_download 
{

	#$TIMEOUT = 20;  # Setting Timeout 
	# Expect Constant
	$Expect::Log_Stdout=1;	

	#//////////////////////////////////	
	# Connecting to Source Machine
	#/////////////////////////////////
    
    print "InstancePortNumber::$INSTANCE_PORT_NUMBER";
	
	$ssh = Expect->spawn("ssh -l $S_USER_NAME $SOURCE_IP -p $INSTANCE_PORT_NUMBER");# Spawning secure shell process 

	if($ssh->expect(10,"password"))
	{ 
		# Checking for password promting

		print $ssh "$S_USER_PASSWD\r";
		print "\n##Password is passed##\n";

		if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
		{ #Checking finally for command promt

			print "\n##Connected to target##\n";

			#if user registered is sudo user then switch to applmgr user and then execute commands
			if($IS_SUDO_USER eq "Yes")
			{
				print $ssh "sudo su - $SUDO_TO_USER\r";
				
				if($ssh->expect(10,"Password"))
				{ 
					# Checking for password promting
					
					print $ssh "$S_USER_PASSWD\r";

					if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
					{ 
						print "\n##Finally Connected to Destination instance..##\n";

					}
					else
					{
						print "\n Connecting through sudo login failed\n";
					}
				}
			}

		}
		else
		{

			print "\n ## CONNECTION TIMED OUT IN CONNECTION  ## \n";
			exit;
		}
	}
	else
	{
		print "\n ### CONNECTION TIMED OUT IN MAKING CONNECTION### \n";
		exit;
	}

	#############################################################
	## Copying fmd from AU_TOP to tri2 server
	#############################################################
	
	if($OBJECT_TYPE eq "ORACLE_FORMS")   #To compare two string in perl "eq" is used
	{
		print "Instance Port number:: $L_INSTANCE_PORT_NUMBER";
        print "scp -P $L_INSTANCE_PORT_NUMBER \$AU_TOP\/forms/US/$FORM_NAME $L_USER_NAME\@$LOCAL_IP:$DEST_LOCATION2\r";;

		$scp_command = "scp -P $L_INSTANCE_PORT_NUMBER \$AU_TOP\/forms/US/$FORM_NAME $L_USER_NAME\@$LOCAL_IP:$DEST_LOCATION2\r";
	}
	elsif($OBJECT_TYPE eq "ORACLE_REPORTS")
	{
		print "In else if,Instance Port number:: $L_INSTANCE_PORT_NUMBER";
        print "in if scp -P $L_INSTANCE_PORT_NUMBER \$AU_TOP\/forms/US/$FORM_NAME $L_USER_NAME\@$LOCAL_IP:$DEST_LOCATION2\r";;


		$scp_command = "scp -P $L_INSTANCE_PORT_NUMBER $SRC_LOCATION/$FORM_NAME $L_USER_NAME\@$LOCAL_IP:$DEST_LOCATION2\r";
	}

	print "hello scp command to be executed is  ->> $scp_command \n\n";
	
	print $ssh "$scp_command\r";
	
	
			if($ssh->expect(20,"?"))
			{
			        print $ssh "yes\r";
			}
			if($ssh->expect(20,"password"))
			{ 
				# Checking for password promting
	
				print $ssh "$L_USER_PASSWD\r";
			
				print "\n##Password is passed to login##\n";
	
				if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
				{ 
					#Checking finally for command promt
	
					print "\n##Connected to Destination Machine##\n";
					if($issudouser eq "Yes")
					{
						print $ssh "sudo su - $sudotouser\r";
						
						if($ssh->expect(10,"Password"))
						{ 
							# Checking for password promting
				
							print $ssh "$L_USER_PASSWD\r";
				
						}
						if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
						{ 
							print "\n##Connected to Destination Machine with sudo user##\n";
	
						}
			
					}
				}
			}
			else
			{
				print "\n ## CONNECTION TIMED OUT WHILE COPYING THE FMB FILES FROM SOURCE TO LOCAL MACHINE ##\n";
				$ssh->log_file(undef);	
				$ssh->hard_close();	
				exit;
			}
			if($ssh->expect(100,"100"))
			{
		
				print "\n## scp is continuing ...###\n";
				if($ssh->expect(20,"\$"))
				{
					print "\n## fmb file copying is over...all files are copied##\n";
				}
				else
				{
					print "\n## CONNECTION TIMED OUT Unable to Copy the files ##\n";
		
					$ssh->log_file(undef);	
					$ssh->hard_close();	
					exit;
				}
			}
	
	      		
	        $ssh->log_file(undef);
        $ssh->hard_close();
	
}1;
