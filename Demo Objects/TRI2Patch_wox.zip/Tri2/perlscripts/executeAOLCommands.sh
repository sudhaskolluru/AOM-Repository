# $1 is for isSudoUser
# $2 temporary file location(Ex: MIG_TOOL/Upload/Upload)
# $3 FNDLOAD command 
# $4 is log required are not(Ex: log file is required for Uploading and not required for Download)
# $5 is for env file path which is given in the instance registry report by the dba 
issudo=$1
uploadBaseDir=$2
echo 'issudo' $1
echo 'uploadBaseDir' $2
pwd
$5
pwd
whoami
. .bash_profile
pwd
cd $2
pwd
if [ $4 == 'Yes' ]
then
	$3 2>extractAOLlog.log	
else
	$3
fi	
