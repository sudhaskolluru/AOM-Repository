#!/usr/bin/perl
use Expect;

sub conn_download_LDT
{

	# Expect Constant
	$Expect::Log_Stdout=1;	
	

	#creating LOCAL SEQNUM BASES 

	print  "\nL_SEQNUM_BASE: $L_SEQNUM_BASE\n";

	# Connecting to Source Machine
	#/////////////////////////////////
	$ssh = Expect->spawn("ssh -l $S_USER_NAME $SOURCE_IP -p $INSTANCE_PORT_NUMBER");# Spawning secure shell process 

	$log = $ssh->log_file($logfile);

	# Checking whether it asks for exchange of keys
	if($ssh->expect(5,"connecting"))
	{
		print $ssh "yes\r";
	}
	if($ssh->expect(10,"password"))
	{ 
		# Checking for password promting

		print $ssh "$S_USER_PASSWD\r";

		if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
		{ 
			#Checking finally for command prompt

			print "\n##Connected to Destination instance..##\n";
		
			#if user registered is sudo user then switch to applmgr user and then execute commands
			if($IS_SUDO_USER eq "Yes")
			{
				print $ssh "sudo su - $SUDO_TO_USER\r";
				
				if($ssh->expect(10,"Password"))
				{ 
					# Checking for password promting
					
					print $ssh "$S_USER_PASSWD\r";

					if($ssh->expect(5,"\$") )# || $ssh->expect(5,"\>"))
					{ 
						print "\n##Finally Connected to Destination  from sudo login instance..##\n";
						
						print $ssh "cd .\r";
						print "Changed to directory\n";
						if($ssh->expect(5,"\$") || $ssh->expect(5,"\>"))
						{
							#logic to get hostname of the server, redirecting hostname to a file and then reading tht file
							print $ssh "hostname > host.txt\r";
							if($ssh->expect(5,"\$") || $ssh->expect(5,"\>"))
							{
		 						open hostfile, "host.txt";

								#open hostfile, "host.txt" or die $!;
								@raw_data=<hostfile>;
								close(hostfile);
		
								@tokensarr = split(/\./,@raw_data[0]);
								$HOST_NAME= $tokensarr[0];
 							}
							print "\nHost name of target server is...$HOST_NAME\n";	

							system("rm -r host.txt");

							#end of host name logic
						}

					}
					else
					{
						print "\n Connecting through sudo login failed\n";
					}
				}
			}

		}
		else
		{

			print "\n ## CONNECTION TIMED OUT IN GETTING CONNECTION  ## \n";
			exit;
		}
	}
	else
	{
		print "\n ### CONNECTION TIMED OUT IN MAKING CONNECTION### \n";
		exit;
	}
	#//////////////////////////////////


	# Creating LOG file
	#/////////////////////////////////
	my @arr = split(/\./,$ldt_filename);
	$logfile = $arr[0].".log";

	#print "\n##Old logfile  is ##$logfile##\n";

	#$logfile = $L_SEQNUM_BASE.$logfile;
	$logfile = $L_DOWNLOAD_BASE.$logfile;


	system("rm -rf $logfile");
	#print "\n##logfile  is ##$logfile##\n";

	$log = $ssh->log_file($logfile);

	#//////////////////////////////


	# Creating SOURCE SEQNUM BASE 
	#//////////////////////////////////

	print $ssh "mkdir -p $S_SEQNUM_BASE\r";

	if($ssh->expect(10,"\$") || $ssh->expect(10,"\>"))
	{
		print "\n##$S_SEQNUM_BASE is Created\n";
	}
	else
	{
		print "\n## CONNECTION TIMED OUT WHILE CREATING S_SEQNUM_BASE  ##\n";

		$ssh->log_file(undef);	
		$ssh->hard_close();	
		exit;
	}
	#///////////////////////////////////

	#comping APPSORA FILE present INSTANCE_APPL  directory

	if(($OBJ_TYPE ne "DISCOVERER_REPORTS") && ($OBJ_TYPE ne "DISCOVERER_BA_FOLDER"))
	{

		$appsora_filepath =  $INSTANCE_APPL."/APPS".$INSTANCE_SID."_".$HOST_NAME.".env";
		#$appsora_filepath ="/Software/HLR12TST/apps/apps_st/appl/APPSHLR12TST_hlr12htp2.env";

		print $ssh ". $appsora_filepath\r";
		print $ssh "echo \$FND_TOP\r";

		if($ssh->expect(20,"fnd"))
		{
			print "\n## $appsora_filepath  is Compiled ##\n";
			print "######## APPS Environment FILE COMPILED \n";
		}
		else
		{
			print "\n## CONNECTION TIMED OUT WHILE COMPILING APPS ENV FILE ##\n";

			$ssh->log_file(undef);	
			$ssh->hard_close();	
			exit;
		}
	}

	#//////////////////////////////////	
	# Change to SOURCE SEQNUM  BASE DIRECTORY
	#//////////////////////////////////	

	print $ssh "cd $S_SEQNUM_BASE\r";

	if($ssh->expect(15,"$SEQ_NUM"))
	{

		print "\n## Directory is changed ##\n";
	}
	else
	{
		print "\n ## CONNECTION TIMED OUT WHILE CHANGING THE DIRECTORY\n";

		$ssh->log_file(undef);	
		$ssh->hard_close();	
		exit;
	}

	#//////////////////////////////////

	# EXECUTING FNLOAD DOWNLOAD COMMAND

	#///////////////////////////////////

	print "\nobject type is ....$OBJ_TYPE \n";

	#Block for executing WFLOAD for downloading Apps workflows
	if($OBJ_TYPE eq "ORACLE_WORKFLOW")
	{
		#WFLOAD apps/apps 0 Y DOWNLOAD reqappv_final.wft REQAPPRV
		print "\n Processing ORACLE_WORKFLOW block....";
		$ldt_filename = $OBJ_NAME.".wft";
		$fnd_load_comm = "WFLOAD $usr_passwd_dbname 0 Y DOWNLOAD  $ldt_filename $OBJ_NAME";
	}
	elsif($OBJ_TYPE eq "DISCOVERER_REPORTS")
	{
	       print "\n Processing Discoverer request block OBJ_NAME is.. $OBJ_NAME..............";
		$OBJ_NAME = $ACTUAL_OBJ_NAME;
		$disc_report_name=$OBJ_NAME."_".$OBJ_TYPE.".eex";
		#eulapi -connect apps/apps@HLR12TST -export TABLESPACE_FREE_STATS_REPORT.eex -workbook "TABLESPACE_FREE_STATS_REPORT"
		$fnd_load_comm = "eulapi -connect $apps_connect -export \"$disc_report_name\" -workbook \"$OBJ_NAME\"";
	
	
	}
	elsif($OBJ_TYPE eq "DISCOVERER_BA_FOLDER")
	{
	       print "\n Processing Discoverer BA/ Folder export request block OBJ_NAME is.. $OBJ_NAME..............";
		$OBJ_NAME = $ACTUAL_OBJ_NAME;

              @values = split('-->',$OBJ_NAME);
		$DISC_BA_NAME = @values[0];
		$DISC_FOLDER_NAME = @values[1];

		print "\nDisc BA Name :: $DISC_BA_NAME";
		print "\nDISC_FOLDER_NAME :: $DISC_FOLDER_NAME";
             	          
		$export_file_name=$DISC_BA_NAME."_".$DISC_FOLDER_NAME."_".$OBJ_TYPE.".eex";
		#eulapi -connect apps/apps@HLR12TST -export DBA_BA_Xx_Freesp_Stats_V.eex -business_area DBA_BA -folder "Xx_Freesp_Stats_V"
		$fnd_load_comm = "eulapi -connect $apps_connect -export \"$export_file_name\" -business_area \"$DISC_BA_NAME\" -folder \"$DISC_FOLDER_NAME\"";
	
	
	}
	elsif($OBJ_TYPE eq "BNE_LAYOUTS")
	{
		print "\n Processing BNE LAYOUT request block..............";
		$fnd_load_comm = "FNDLOAD $usr_passwd_dbname 0 Y DOWNLOAD \$BNE_TOP/patch/115/import/bnelay.lct $ldt_filename BNE_LAYOUTS LAYOUT_ASN=\"$APPL_SHORT_NAME\" LAYOUT_CODE=\"$OBJ_NAME\"";

	}
	elsif($OBJ_TYPE eq "XML_PUB_REPORTS")
	{
		print "\n Processing XDOLoader request block..............";
	
		$fnd_load_comm = "java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD -DB_USERNAME $DB_USER -DB_PASSWORD $DB_USER_PASSWD -JDBC_CONNECTION $INSTANCE_DB_IP:$INSTANCE_DB_PORT:$INSTANCE_SID -LOB_TYPE TEMPLATE_SOURCE -APPS_SHORT_NAME $APPL_SHORT_NAME -LOB_CODE $OBJ_NAME -LANGUAGE en -TERRITORY US";

	}
	elsif($OBJ_TYPE eq "XDO_DS_DEFINITIONS")
	{
		print "\n Processing XDO_DS_DEFINITIONS request block..............";

		$fnd_load_comm = "FNDLOAD $usr_passwd_dbname 0 Y DOWNLOAD \$XDO_TOP/patch/115/import/xdotmpl.lct $ldt_filename XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME=$APPL_SHORT_NAME DATA_SOURCE_CODE=$OBJ_NAME";

	}
	else
	{
	
		#Block for executing FNDLOAD for downloading AOL objects
	
		print "\n Processing FNDLOAD request block..............";
		$fnd_load_comm = "FNDLOAD $usr_passwd_dbname 0 Y DOWNLOAD \$FND_TOP/patch/115/import/$lct_filename $ldt_filename $ENT_TYPE $param1 $param2";

	}
	print "\n\n## This is the FNDLOAD command being executed ---- ##\n\n";	
	print $ssh "$fnd_load_comm\r";

	if($ssh->expect(10,"Report") || $ssh->expect(10,"successfully:") || $ssh->expect(5,"Command completed."))
	{
		print "\n in if block after execution........\n";
		if($ssh->expect(100,"\$") || $ssh->expect(100,"\>"))
		{
			print "\n## fnd command executed successfully...##\n";
		}
		else
		{	
			print "\n## fnd command failed.##\n";
		}
		

	}
	else
	{

		print "\n ## CONNECTION TIMED OUT WHILE RUNNING FNDLOAD COMMAND ##\n";
		print "\n I ERROR\n";

		$ssh->log_file(undef);	
		$ssh->hard_close();	
	}
	#/////////////////////////////////////////////////////////////////////////////////////////////////////
	#Code to archive files exported by XDOLOADER command
	#/////////////////////////////////////////////////////////////////////////////////////////////////////
	if($OBJ_TYPE eq "XML_PUB_REPORTS")
	{

		#$archive_file_name = $OBJ_NAME.".jar";
		$new_name = $OBJ_NAME.".rtf";
	
		#commad to rename generated rtf name to name as LOB_CODE
		print $ssh "mv *.rtf $new_name\r";
		#print $ssh "jar cvf  $archive_file_name *.* \r";
 		#print $ssh "rm *.rtf\r";

		#if($ssh->expect(100,"\$") || $ssh->expect(100,"\>"))
		#{
		#	print "\n## Jar file created successfully...##\n";
		#}
		#else
		#{	
		#	print "\n## Failed to create Jar files..##\n";
		#}

	}
	#/////////////////////////////////////////////////////////////////////////////////////////////////////


		
	#///////////////////////////////////
	#Copying files to respective directories
	# ///////////////////////////////////
	# copying log file from SOURCE SEQNUM BASE to LOCAL SEQNUM BASE Directory

	#copying file from S_LOG_BASE to L_LOG_BASE

		print "\nDude this is an area of concern ->>scp -r -P $L_INSTANCE_PORT_NUMBER ../$SEQ_NUM* $L_USER_NAME\@$LOCAL_IP:$L_DOWNLOAD_BASE \n";
		#print $ssh "scp -r -P $L_INSTANCE_PORT_NUMBER $S_SEQNUM_BASE $L_USER_NAME\@$LOCAL_IP:$L_DOWNLOAD_BASE\r";
		print $ssh "scp -r -P $L_INSTANCE_PORT_NUMBER ../$SEQ_NUM $L_USER_NAME\@$LOCAL_IP:$L_DOWNLOAD_BASE\r";


	if($ssh->expect(10,"?"))
	{
		print $ssh "yes\r";
	}
	if($ssh->expect(15,"password"))
		{ 
			# Checking for password promting
	
			print $ssh "$L_USER_PASSWD\r";
			
			print "\n##Password is passed second time login##\n";
	
			if($ssh->expect(15,"\$") || $ssh->expect(15,"\>"))
			{ 
				#Checking finally for command promt
	
				print "\n##Connected to Destination Machine##\n";
				if($issudouser eq "Yes")
				{
					print $ssh "sudo su - $sudotouser\r";
					
					if($ssh->expect(10,"Password"))
					{ 
						# Checking for password promting
				
						print $ssh "$L_USER_PASSWD\r";
			
					}
					if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
					{ 
						print "\n##Connected to Destination Machine with sudo user##\n";
	
					}
			
				}
			}
	}
	else
	{
		print "\n ## CONNECTION TIMED OUT WHILE COPYING THE LOG FILES FROM SOURCE TO LOCAL MACHINE ##\n";
		$ssh->log_file(undef);	
		$ssh->hard_close();	
		exit;
	}
#	if($ssh->expect(10,"100"))
#	{
#
#		print "\n## scp is continuing ...###\n";
#		if($ssh->expect(5,"\$") || $ssh->expect(5,"\>"))
#		{
#			print "\n## scp of all LDT files is over...all files are copied##\n";
#		}
#		else
#		{
#			print "\n## CONNECTION TIMED OUT Unable to Copy the LDT files ##\n";
#			$ssh->log_file(undef);	
#			$ssh->hard_close();	
#			exit;
#		}
#	}

		#command to delete all the contents in MIG_TOOL folder, to remove junk data
		#system("rm -rf /tmp/MIG_TOOL/Download/$SEQ_NUM*");
		print "folder going to delete is ::$SEQ_NUM*\n";
              print $ssh "rm -rf ../$SEQ_NUM*\r";

	     if($ssh->expect(10,"\$") || $ssh->expect(5,"\>"))
	    {
                       
            print "\n## rm is over...all files are deleted..............##\n"; 
                                                                                                                  				
	    }   
           else
	    {
		print "\n## CONNECTION TIMED OUT Unable to delete the files ##\n";
						  
		$ssh->log_file(undef);	
		$ssh->hard_close();	
		exit;
	    }


	$ssh->log_file(undef);	
	$ssh->hard_close();
	exit;
}
1;


sub download_discoverer_report()
{

	
		$apps_connect = $usr_passwd_dbname;
		$instance_type="Discoverer";
		
		##---------- about to call get_instance_details()

		get_instance_details();
		print "\n after cmng out of get_instance_details.............";
            
		conn_download_LDT();
		print "\n after cmng out of conn_download_LDT.............";

}
1;
