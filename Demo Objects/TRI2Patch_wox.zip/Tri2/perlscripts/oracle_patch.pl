#!/usr/bin/perl 
#REQUIRED PROCEDURES
#///////////////////////////
require ("get_ora_patch_cmdline_var.pl");
require ("get_instance_details.pl");
require ("oracle_patch_execute.pl");
#//////////////////////////////

$no_args = $#ARGV;
if($no_args  < 3)
{
	print "InSufficient Arguments....\n";
	print "Usage :\n";
	print "perl patch_execute.pl DB_NAME SRC_LOCATION DEST_LOCATION1 \n";
	exit;
}
else
{
	print "perl patch_execute.pl $DB_NAME $SRC_LOCATION $DEST_LOCATION1 $FILE_NAME $PATCH_NUM $ORA_SYS_PWD $PASS_WORD\n" ;
	#print "before calling get_ora_patch_cmdline_var() \n";
	get_ora_patch_cmdline_var(@ARGV);
	#print "after calling get_ora_patch_cmdline_var()";
	get_instance_details();
	#print "after calling oracle_patch_execute()";
	oracle_patch_execute();
	#print "after calling oracle_patch_execute()";
	print "\n*********Oracle Patch Migration Process Completed********\n";
	exit();	
}
