
#!/usr/bin/perl
use Expect;

sub create_patch_on_hwbuild 
{

	# Expect Constant
	$Expect::Log_Stdout=1;	

	#$S_USER_NAME = 'skota';
	#$S_USER_PASSWD= 'welcome@123';
	#$SOURCE_IP='192.168.0.20';
	#$BUILD_LOCATION='/home/skota/Triniti';
       #$BUILD_LOCATION='/home/productsbuildv5';
	#$PROJECT='TRI2';
	#$SRC_SIDE_LOCATION='/home/pddev/TrinitiApps28/Tri2Build/temp/UploadPatch/TRI2Development';

	########################################
	## Local instance details
	########################################
	#$L_USER_NAME='tri2prod';
	#$L_USER_PASSWD='Tri!2pr0d@tr!2';
	#$LOCAL_IP='192.168.0.28';
	#######################################


	#/////////////////////////////////
	# Connecting to Build Machine
	#/////////////////////////////////


	#$TIMEOUT = 10;

	$PatchName=$PROJECT.'Patch.zip';
       
       $MigReqNumber=$MIG_REQ_NUMBER;

       $ProjectFolderName=$PROJECT_NAME;
    
	$ReleaseName   = $RELEASE_NAME;

	print "Patch name being passed is : $PatchName\n";

	$ssh = Expect->spawn("ssh -l $S_USER_NAME $SOURCE_IP -p $INSTANCE_PORT_NUMBER");# Spawning secure shell process 

	print " Hello connecting user is : $S_USER_NAME\n";
	
	if($ssh->expect(5,"?"))
	{
		print $ssh "yes\r";
	}
	if($ssh->expect(10,"password"))
	{ 
		# Checking for password promting

		print $ssh "$S_USER_PASSWD\r";

		print "\n##Password is passed##\n";

		if($ssh->expect(10,"\$"))
		{ 
			#Checking finally for command promt

			print "\n##Connected to Destination Machine##\n";

			print $ssh "cd $BUILD_LOCATION/$PROJECT\r";
 
			print "\n executing the Ant Build File \n";

		    print $ssh "ant -DprojectName=$PROJECT -DpatchName=$PatchName -DmigReqNumber=$MigReqNumber -DprojectFolderName='$ProjectFolderName' -DreleaseName=$ReleaseName\r";
                   
			print "\n*************Ant File executed successfully\n";

			if($ssh->expect(50,"400"))
			{
				print "\n*************Ant File executed successfully inside if....\n";
				
			}
			else
			{
				#print "\n ## I AM IN ELSE ##\n";

			}
		}
		else
		{
			print "\n ## CONNECTION TIMED OUT, WRONG PASSWORD CHECK ONCE ## \n";
			exit;
		}

	}
	else
	{
		print "\n ### CONNECTION TIMED OUT IN MAKING CONNECTION### \n";
		exit;
	}

	#//////////////////////////////////
	#Connecting to Build machine nd copying the patch file to source
	#//////////////////////////////

	print "\nHello U R connecting to destination m/c ->>scp $BUILD_LOCATION/$PROJECT/patchrelease/$PatchName* $L_USER_NAME\@$LOCAL_IP:$SRC_SIDE_LOCATION\n\n";

	#$ssh = Expect->spawn("scp $BUILD_LOCATION/$PROJECT/patchrelease/$PatchName* $L_USER_NAME\@$LOCAL_IP:$SRC_SIDE_LOCATION");# Spawning secure shell process 

	print $ssh "scp -P $L_INSTANCE_PORT_NUMBER $BUILD_LOCATION/$PROJECT/patchrelease/$PatchName* $L_USER_NAME\@$LOCAL_IP:$SRC_SIDE_LOCATION\r";

	$log = $ssh->log_file($logfile);

	if($ssh->expect(5,"?"))
	{
		print $ssh "yes\r";
	}
	if($ssh->expect(10,"password"))
		{ 
			# Checking for password promting
	
			print $ssh "$L_USER_PASSWD\r";
			
			print "\n##Password is passed second time login##\n";
	
			if($ssh->expect(50,"\$") || $ssh->expect(50,"\>"))
			{ 
				#Checking finally for command promt
	
				print "\n##Connected to Destination Machine##\n";
				if($issudouser eq "Yes")
				{
					print $ssh "sudo su - $sudotouser\r";
					
					if($ssh->expect(10,"Password"))
					{ 
						# Checking for password promting
				
						print $ssh "$L_USER_PASSWD\r";
			
					}
					if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
					{ 
						print "\n##Connected to Destination Machine with sudo user##\n";
	
					}
			
				}
	              }
	
		}
	else
	{
		print "\n ## CONNECTION TIMED OUT WHILE COPYING THE  FILES FROM LOCAL TO SOURCE MACHINE ##\n";
		$ssh->log_file(undef);	
		$ssh->hard_close();	
		exit;
	}

	if($ssh->expect(100,"1000"))
			{
				print "\n## File Copying to Destination is still continuing ...###\n";
				if($ssh->expect(10,"\$") || $ssh->expect(10,"\>"))
				{
					#Checking finally for command prompt
			
					print "### Copying is over...all files are Successfully copied##\n";
				}
				else
				{
					print "## CONNECTION TIMED OUT Unable to Copy the files ##\n";
					$ssh->log_file(undef);	
					$ssh->hard_close();	
					exit;
				}

			}

}
1;
