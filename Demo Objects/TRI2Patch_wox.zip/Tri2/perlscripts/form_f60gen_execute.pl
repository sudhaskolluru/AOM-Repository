#!/usr/bin/perl
use Expect;

sub form_f60gen_execute
{
 
	# Expect Constant
	$Expect::Log_Stdout=1;	

	print "\n\n**************** AOL Objects Migration Logs ******************\n";
       
       print " SOURCE LOCATION --> $SRC_LOCATION \n";
	print " ORACLE_RELEASE_VERSION --> $ORACLE_RELEASE_VERSION \n";
	print " ORACLE FORM Destination Location --> $DEST_LOCATION2 \n";
	print " Form Name --> $FORM_NAME \n";
	print " OBject Type --> $OBJECT_TYPE \n";
	print " Migration Request Number --> $MIG_REQ_NUMBER \n";


	if($OBJECT_TYPE eq "ORACLE_FORMS") 
	{	# $AU_TOP is a base path were all 'FMB' files will store and migrate 'FMX' Files to destiantion location(selected basepath) 
		$DEST_LOCATION1 = '$AU_TOP/forms/US';
		print "\nORACLE FORM Source Location      :: $DEST_LOCATION1";
		print "\nORACLE FORM Destination Location :: $DEST_LOCATION2";
	}
	elsif($OBJECT_TYPE eq "ORACLE_REPORTS")
	{
		$DEST_LOCATION1 = $DEST_LOCATION2;
        	print "\nORACLE REPORTS Destination Location :: $DEST_LOCATION1";        
	}
	else
	{
		print "\n Object Type is null....";
	}

	print "\n***************form_f60gen_execute .... method entered\n";

		#------------------------------#
		# Connecting to Source Machine #
		#------------------------------#
		
		$ssh = Expect->spawn("ssh -l $S_USER_NAME $SOURCE_IP -p $INSTANCE_PORT_NUMBER");# Spawning secure shell process 
	
		# Checking whether it asks for exchange of keys
		if($ssh->expect(5,"connecting"))
		{
			print $ssh "yes\r";
		}
		
		if($ssh->expect(5,"password"))
		{	
		    
		    # Checking for password promting
	
		    print $ssh "$S_USER_PASSWD\r";
					
			
		    if($ssh->expect(10,"\$") || $ssh->expect(10,"\>"))
		    {
		    	#Checking finally for command promt
			
			print "\n[INFO]::##Connected to target Instance##\n";

			#if user registered is sudo user then switch to applmgr user and then execute commands
			if($IS_SUDO_USER eq "Yes")
			{
				print $ssh "sudo su - $SUDO_TO_USER\r";
				
				if($ssh->expect(10,"Password"))
				{ 
					# Checking for password promting
					
					print $ssh "$S_USER_PASSWD\r";

					if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
					{ 
						print "\n##Finally Connected to Destination instance..##\n";

					}
					else
					{
						print "\n Connecting through sudo login failed\n";
					}
				}
			  }
		    }
		    else
		    {
	
				print "\n [ERROR]::## CONNECTION TIMED OUT IN CONNECTION  ## \n";
				exit;
		    }
		}
		else
		{
			print "\n [ERROR]::### CONNECTION TIMED OUT IN MAKING CONNECTION### \n";
			exit;
		}
		

		print "\n\nSCP Command to be Execute -->> scp -r -p $L_INSTANCE_PORT_NUMBER $L_USER_NAME\@$LOCAL_IP:$SRC_LOCATION $DEST_LOCATION1 \n\n";
		 	
	 	print $ssh "scp -r -p $L_INSTANCE_PORT_NUMBER $L_USER_NAME\@$LOCAL_IP:$SRC_LOCATION $DEST_LOCATION1 \r";
		
		if($ssh->expect(5,"?"))
		{
		       print $ssh "yes\r";
		}
		if($ssh->expect(5,"password"))
		{ 
			# Checking for password promting
	
			print $ssh "$L_USER_PASSWD\r";
			
			print "\n##Password is passed second time login##\n";
	
			if($ssh->expect(10,"\$") || $ssh->expect(10,"\>"))
			{ 
				#Checking finally for command promt
	
				print "\n[INFO]::##Connected to Destination Machine##\n";
				if($issudouser eq "Yes")
				{
					print $ssh "sudo su - $sudotouser\r";
					
					if($ssh->expect(10,"Password"))
					{ 
						# Checking for password promting
				
						print $ssh "$L_USER_PASSWD\r";
			
					}
					if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
					{ 
						print "\n[INFO]::##Connected to Destination Machine with sudo user##\n";
	
					}
				}
			}
		}
		else
		{
			print "\n [ERROR]::## CONNECTION TIMED OUT WHILE COPYING THE LOG FILES FROM SOURCE TO LOCAL MACHINE ##\n";
			$ssh->log_file(undef);	
			$ssh->hard_close();	
			exit;
		}
		if($ssh->expect(20,"100"))
		{
			print "\n## scp is continuing ...###\n";
			if($ssh->expect(10,"\$"))
			{
				print "\n[INFO]::## scp is over...all files are copied##\n";
			}
 			elsif($ssh->expect(10,"\>"))
		      	{
			  #Checking finally for command promt
			
			  print "\n##Connected to target Instance##\n";

		      	}
			else
			{
				print "\n[ERROR]::## CONNECTION TIMED OUT Unable to Copy the files ##\n";
	
				$ssh->log_file(undef);	
				$ssh->hard_close();	
				exit;
			}
		}
	
		
	#---------------------------------#
	# RUNNING F60gen DOWNLOAD COMMAND #
	#---------------------------------#
	
	# Preparing Connectiong string 
	$usr_passwd_dbname= $DB_USER.'/'.$DB_USER_PASSWD;

	print "\nobject type is :: $OBJECT_TYPE\n";
	if($OBJECT_TYPE eq "ORACLE_FORMS")   #To compare two string in perl "eq" is used
	{

		#changing directory to AU_TOP/forms/US to execute the fmb file using f60gen

		print $ssh "cd \$AU_TOP/forms/US\r";

		print $ssh "pwd\r";
		
		if($ORACLE_RELEASE_VERSION eq "R12")
		{
			$f60gen_cmd = "frmcmp_batch module=\$AU_TOP/forms/US/$FORM_NAME.fmb output_file=$DEST_LOCATION2/$FORM_NAME.fmx userid=$usr_passwd_dbname module_type=form compile_all=special";   
		}
		else
		{
			$f60gen_cmd = "f60gen module=$DEST_LOCATION1/$FORM_NAME.fmb userid=$usr_passwd_dbname output_file=$DEST_LOCATION2/$FORM_NAME.fmx module_type=form batch=no compile_all=special > extractAOLlog.log";
		}
		
		#print "\n\n## This is the F60GEN command being executed ---- $f60gen_cmd##\n";	
		print $ssh "$f60gen_cmd\r";
		
		if($ssh->expect(100,"Created"))
		{
			print "\n##Form compilation Completed##\n";			
		}
		elsif($ssh->expect(100,"created"))
		{
			print "\n##Form compilation Completed##\n";
		}
		else
		{
			print "\n[ERROR]:: ## CONNECTION TIMED OUT WHILE RUNNING F60GEN COMMAND ##\n";
			$ssh->log_file(undef);	
			$ssh->hard_close();	
			exit;
		}

	}
	elsif($OBJECT_TYPE eq "ORACLE_REPORTS")
	{
		print "**********Need to do Report Migration***********\n";

		#changing directory to AU_TOP/reports/US to copy the rdf file from this dir to dest dir

		#moving the  rdf file to corresponding schema top directory using move command
		
		print "move command being executed :: mv $SRC_LOCATION/$FORM_NAME.rdf $DEST_LOCATION2  \n";
		print $ssh "mv $DEST_LOCATION1 $DEST_LOCATION2 \r";
	
		if($ssh->expect(40,"US"))
		{
			print "\n [INFO]::RDF Migration is done...\n";
		}
		else
		{
			print "\n [ERROR]::## CONNECTION TIMED OUT WHILE RUNNING report copy ##\n";
			print "\n I ERROR\n";
			$ssh->log_file(undef);	
			$ssh->hard_close();	
			exit;
		}

	}

	$ssh->log_file(undef);	
	$ssh->hard_close();
	#exit;
}
1;
