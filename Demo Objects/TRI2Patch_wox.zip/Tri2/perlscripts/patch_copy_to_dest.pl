#!/usr/bin/perl
use Expect;

sub patch_copy_to_dest {

	#$TIMEOUT = 120;  # Setting Timeout 
	# Expect Constant
	$Expect::Log_Stdout=1;	

       print "\n ********* Triniti Objects Migration Logs ********* \n";
       
	#print "***************patch migration perl.... method entered\n";

	#//////////////////////////////////

	# Creating LOG file
	#/////////////////////////////////
	my @arr = split(/\./,"PatchMig.log",);
	$logfile ="PatchMig.log";

	#print "\n##Old logfile  is ##$logfile##\n";

	$logfile = $logfile;

	system("rm -rf $logfile");
	#print "\n##logfile  is ##$logfile##\n";

	#//////////////////////////////

	print "\nHello U R connecting to destination m/c ->>scp -P $INSTANCE_PORT_NUMBER $SRC_LOCATION $S_USER_NAME\@$SOURCE_IP:$DEST_LOCATION1\n\n";
 	
	$ssh = Expect->spawn("scp -P $INSTANCE_PORT_NUMBER $SRC_LOCATION* $S_USER_NAME\@$SOURCE_IP:$DEST_LOCATION1 ");

	$log = $ssh->log_file($logfile);

	#$TIMEOUT = 8;
 
	if($ssh->expect(8,"?"))
	{
		print $ssh "yes\r";
	}
	if($ssh->expect(1000,"password"))
	{
		print $ssh "$S_USER_PASSWD\r"; 

		print "\n##password is supplied first time##\n";
	}
	else
	{
		print "\n ## CONNECTION TIMED OUT WHILE CONNECTING THE  FILES FROM LOCAL TO SOURCE MACHINE ##\n";
		$ssh->log_file(undef);	
		$ssh->hard_close();	
		exit;
	}

	#if user registered is sudo user then switch to actual user and then execute commands
	if($IS_SUDO_USER eq "Yes")
	{
		print $ssh "sudo su - $SUDO_TO_USER\r";
				
		if($ssh->expect(10,"Password"))
		{ 
			# Checking for password promting
			
			print $ssh "$S_USER_PASSWD\r";

		}
	}
			#if($ssh->expect($TIMEOUT,"300"))
			if($ssh->expect(1000,"1000"))
			{

				print "\n## File Copying to Destination is still continuing ...###\n";
				if($ssh->expect(8,"\$") || $ssh->expect(8,"\>"))
				{
					#Checking finally for command prompt
			
					print "### Copying is over...all files are Successfully copied##\n";
				}
				else
				{
					print "## CONNECTION TIMED OUT Unable to Copy the files ##\n";
					$ssh->log_file(undef);	
					$ssh->hard_close();	
					exit;
				}

			}

		

	#/////////////////////////////////
	# Connecting to Source Machine
	#/////////////////////////////////
       

	#print "Instance Port Number::$INSTANCE_PORT_NUMBER" ;
       $ssh = Expect->spawn("ssh -l $S_USER_NAME $SOURCE_IP -p $INSTANCE_PORT_NUMBER");# Spawning secure shell process 
	

	print " Hello connecting user is : $S_USER_NAME\n";
	if($ssh->expect(5,"?"))
	{
		print $ssh "yes\r";
	}
	if($ssh->expect(10,"password"))
	{ 
		 #Checking for password promting

		print $ssh "$S_USER_PASSWD\r";
		
		
		if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
		{ 
			
				print "\n##Password is passed second time login##\n";

				print "\n Is this a sudo user ? $IS_SUDO_USER \n";
				print $ssh "pwd\r";
				#if user registered is sudo user then switch to applmgr user and then execute commands
				if($IS_SUDO_USER eq "Yes")
				{
					print $ssh "sudo su - $SUDO_TO_USER\r";
					
					if($ssh->expect(10,"Password"))
					{ 
						# Checking for password promting
						print $ssh "$S_USER_PASSWD\r";
						print "\n##Password is passed third time login##\n";


					}
					else 
					{
						print "\n ## CONNECTION TIMED OUT, while connecting to sudo user login ## \n";
						exit;
					}

				
				} 


					if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
					{ 
						#Checking finally for command prompt

						print "\n##Connected to Destination Machine##\n";

						print $ssh "cd $DEST_LOCATION1\r";
						print "\n executing first ant \n";
						print $ssh "ant -buildfile buildUnzip.xml -DzipName=$FILE_NAME \r";

						if($ssh->expect(10,"50"))
						{
							print "\n*************Ant File executed successfully\n";
							print $ssh "ant -DzipName=$FILE_NAME \r";
						}
						else
						{
							#print "\n ## I AM IN ELSE ##\n";
						}			

						#changing directory to DEST DIR 
						#$TIMEOUT = 120;


						if($MIG_TYPE eq "JAR")
						{
							print $ssh "cd GPSPatches\r";
							print "\nPresent Working Directory::";
							print $ssh "pwd\r";

							my $deploymentPath = $DEST_LOCATION1;

							#Getting deployment path, below is the reqex to get string before last file seperator i.e., /home/pddev/TrinitiApps28/MigBuild will give
							# /home/pddev/TrinitiApps28 as output string

							$deploymentPath =~ s{\/[^\/]*$}{}x;
							print "\nDeployment path on target instance is::";
							print $deploymentPath;
							print "\n Clearing process log buffer to start second ant execution. \n";
							$ssh->clear_accum();
							print "\n executing second ant \n";
							print $ssh "ant -DzipName=$FILE_NAME -Ddeploy.path=$deploymentPath \r";
							
							if($ssh->expect(150,"BUILD SUCCESSFUL", "BUILD FAILED"))
							{
								print "\n*************Ant File execution Completed\n";
							}
							else
							{
								print "\n ## ANT executing in else\n";
								
							}
							if($DB_NAME eq "HLPDTEST" || $DB_NAME eq "HLPDDEV")
							{
								#$TIMEOUT = 10;							
										
								print $ssh "sh $DEST_LOCATION1/tomcat-shutdown-startup.sh\r";
								if($ssh->expect(100,"200"))
								{
									print "\n*************Tomcat restart shell execution failed\n";
								}
								else
								{		
									print "\n*************Tomcat restarted successfully..\n";
									exit;
								}
							}
						


						 }
					}
					else 
					{
						print "\n ## CONNECTION TIMED OUT, after login ## \n";
						exit;
					}
			
		}
		else
		{

			print "\n ## CONNECTION TIMED OUT IN GETTING CONNECTION  ## \n";
			exit;
		}

	}#4
	else
	{
		print "\n ### CONNECTION TIMED OUT IN MAKING CONNECTION### \n";
		exit;
	}

	#//////////////////////////////////

	$ssh->log_file(undef);	
	$ssh->hard_close();
	exit;		
}
1;
