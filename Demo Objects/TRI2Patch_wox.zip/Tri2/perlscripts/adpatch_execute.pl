#!/usr/bin/perl
use Expect;

sub adpatch_execute
{

	# Expect Constant
	$Expect::Log_Stdout=1;	
	
	$LOG_FILE_NAME= "L".$PATCH_NUM.".log";
	
	$DRV_FILE_NAME = "u".$PATCH_NUM.".drv";
	
	print "DRV_FILE_NAME is.....$DRV_FILE_NAME\n";

	$workers = 6;
	
	print "\nPresent Working directory is ...\n";
	
	print $ssh "pwd\r";

	print $ssh "adpatch\r";

	if($ssh->expect(5,"APPL_TOP [Yes] ?"))
	{
		  print $ssh "yes\r";
	}
	if($ssh->expect(5,"[adpatch.log] :"))
	{
		print $ssh "$LOG_FILE_NAME \r";
	}
	if($ssh->expect(5,"AutoPatch session [Yes] ?"))
	{
		print $ssh "no\r";	
	}
	if($ssh->expect(5,"AutoPatch session. [No] :"))
	{
		print $ssh "yes\r";	
	}
	if($ssh->expect(10,"activate this feature [No] ?"))
	{
		 print $ssh "no\r";
	}
	if($ssh->expect(10,"Please enter the batchsize [1000] :"))
	{
		 print $ssh "\r";
	}
	if($ssh->expect(10,"Is this the correct database [Yes] ?"))
	{
		 print $ssh "yes\r";
	}
	if($ssh->expect(10,"for your 'SYSTEM' ORACLE schema:"))
	{
		 print $ssh "$ORA_SYS_PWD\r";
	}

	if($ssh->expect(15,"Application Object Library [APPS] :"))
	{
		 print $ssh "$DB_USER_PASSWD\r";
	}

	if($ssh->expect(15,":"))
	{
		print $ssh "\r";
	}
	if($ssh->expect(100,"AutoPatch driver file :"))
	{
		print $ssh "$DRV_FILE_NAME\r";
	}
	if($ssh->expect(15,"parallel workers"))
	{
		print $ssh "$workers\r";
	}
	#this option will be twice dont remove this
	if($ssh->expect(10,"Continue as if it were successful [No] :"))
	{
		print $ssh "No\r";
	}
	if($ssh->expect(10,"Drop FND_INSTALL_PROCESSES table [No] ?"))
	{
		 print $ssh "Yes\r";
	}
	if($ssh->expect(100,"Would you like to continue anyway  [N] ?")) 
	{
		print $ssh "Y\r";
	}

	if($ssh->expect(10,"Continue as if it were successful [No] :"))
	{
		print $ssh "No\r";
	}
	
	if($ssh->expect(100,"\$"))
	{
		print "\nOracle patch is done with errors..\n";
	}
	else
	{
		if($ssh->expect(300,"] :"))
		{
			print $ssh "\r";

		}
	
		if($ssh->expect(50,"] :"))
		{
			print $ssh "\r";
		}
	
		elsif($ssh->expect(undef,"\$"))
		{
			print "\nOracle patch is done.....\n";
		}
	
		else
		{
			print "\nOracle patch is done...\n";
		}
    }

}
1;
