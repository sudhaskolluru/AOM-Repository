#!/usr/bin/perl
use Expect;

# This Program reads Table containing information about Instances and their
# Connection variables

use DBI;

sub get_instance_details 
{
	# Expect Constant
	$Expect::Log_Stdout=1;

	#Code to get Migration Tool instance properties from InstanceDetails.properties file
         my %instanceDetails;
         open my $in, "InstanceDetails.properties" or die $!;
         while(<$in>) 
         {
            $instanceDetails{$1}=$2 while m/(\S+)=(\S+)/g;
         }

	
	$LOCAL_IP = $instanceDetails{'LocalIP'};
	$L_USER_NAME =$instanceDetails{'UserName'};
	$L_USER_PASSWD =$instanceDetails{'Password'};
	$DIR_BASE=$instanceDetails{'dirbase'};
	$L_DOWNLOAD_BASE=$DIR_BASE.'/Download/';
	$L_UPLOAD_BASE=$DIR_BASE.'/Upload/';
	$L_INSTANCE_PORT_NUMBER = $instanceDetails{'Instance_port_number'};
       
	
	my $HOST= $instanceDetails{'Host'};
	my $SID = $instanceDetails{'DB_SID'};
	my $PORT= $instanceDetails{'DB_PORT'};         
	my $DBUSER =$instanceDetails{'dbUser'};
	#my $DBUSER_PASSWD=$instanceDetails{'dbPassword'};

	$issudouser=$instanceDetails{'issudouser'};
	$sudotouser=$instanceDetails{'sudotouser'};
	
	#End of Property file reading code

	print "\n Target instance DBName is $DB_NAME\n";

	#String for connecting to database using DBI Module
	#$connstring = "dbi:Oracle:host=$HOST;sid=$SID";
	
	#Above line commented as if we place host it is giving problem while connecting to RAC dB
	$connstring = "dbi:Oracle:$SID";

	# Connecting to Database and Querying table T_MIG_INSTANCE_DETAILS 
	#/////////////////////////////////////////////////////////////////////


	if($OBJ_OWNER eq "" || $OBJ_OWNER eq "null") #IF FOR ANY OBJECT ITS OWNER IS NULL THEN DEFAULT IT TO APPS USER
	{
		$OBJ_OWNER = 'APPS';
	}
		print "\nNow Object owner  is $OBJ_OWNER\n";
	$dbh = DBI->connect($connstring,$DBUSER,$PASS_WORD) || die "cannot connect to Oracle Database:$DBI::errstr\n";

	
	if($instance_type eq "Discoverer")
	{
		$sth = $dbh->prepare("select TMID.instance_ip,TMID.instance_username,TMID.instance_password,CUS.SCHEMA_USER,CUS.SCHEMA_PASSWORD,TMID.instance_appl,TMID.mig_setup_id,CON.DOWNLOAD_PATH_IN_CONTEXT,TMID.INSTANCE_SID,TMID.INSTANCE_DB_IP,TMID.INSTANCE_DBPORT,TMID.ISSUDOUSER,TMID.SUDO_TO_USER,TMID.instance_port_number from T_MIG_INSTANCE_DETAILS TMID,T_MIG_INSTANCE_CONTEXT_DETAILS CON,T_MIG_INSTANCE_CUSTOM_SCHEMAS CUS where TMID.INSTANCE_ID=CON.INSTANCE_ID(+) AND TMID.INSTANCE_ID=CUS.INSTANCE_ID(+) AND CUS.SCHEMA_SHORT_NAME(+)=\'$OBJ_OWNER\' AND instance_type=\'Discoverer\' AND TMID.IS_INSTANCE_ENABLED='true' ") or die "Cant prepare SQL statement: $DBI::errstr";
	}
	else
	{
		$sth = $dbh->prepare("select TMID.instance_ip,TMID.instance_username,TMID.instance_password,CUS.SCHEMA_USER,CUS.SCHEMA_PASSWORD,TMID.instance_appl,TMID.mig_setup_id,CON.DOWNLOAD_PATH_IN_CONTEXT,TMID.INSTANCE_SID,TMID.INSTANCE_DB_IP,TMID.INSTANCE_DBPORT,TMID.ISSUDOUSER,TMID.SUDO_TO_USER,TMID.instance_port_number from T_MIG_INSTANCE_DETAILS TMID,T_MIG_INSTANCE_CONTEXT_DETAILS CON,T_MIG_INSTANCE_CUSTOM_SCHEMAS CUS where TMID.INSTANCE_ID=CON.INSTANCE_ID(+) AND TMID.INSTANCE_ID=CUS.INSTANCE_ID(+) AND CUS.SCHEMA_SHORT_NAME(+)=\'$OBJ_OWNER\' AND upper(instance_short_name)=upper(\'$DB_NAME\') AND TMID.IS_INSTANCE_ENABLED='true'") or die "Cant prepare SQL statement: $DBI::errstr";

	}

	$sth->execute() or die "Can't execute SQL statement: $DBI::errstr\n";

	@row = $sth->fetchrow_array;
	$sth->finish();
	
	$SOURCE_IP 	    	 = $row[0];
	$S_USER_NAME      	 = $row[1];
	$DB_USER          	 = $row[3];
	$INSTANCE_APPL    	 = $row[5];
	$MIG_SETUP_ID     	 = $row[6];
	$BUILD_LOCATION      = $row[7];
	$INSTANCE_SID     	 = $row[8];
	$INSTANCE_DB_IP   	 = $row[9];
	$INSTANCE_DB_PORT 	 = $row[10];
	$IS_SUDO_USER     	 = $row[11];
	$SUDO_TO_USER     	 = $row[12];
    $INSTANCE_PORT_NUMBER= $row[13];
       
	if($INSTANCE_PORT_NUMBER eq "")
 	{ 
		$INSTANCE_PORT_NUMBER = 22;
	}
  
	#Disconnecting from the Database
	$dbh->disconnect or warn "Error disconnecting : $DBI::errstr\n";
    
	############################################	
	# Connecting to Source Machine
	############################################

	$ssh = Expect->spawn("ssh -l $L_USER_NAME $LOCAL_IP -p $L_INSTANCE_PORT_NUMBER");# Spawning secure shell process 

	#print " Hello connecting user is : $L_USER_NAME\n";
	if($ssh->expect(5,"?"))
	{
		print $ssh "yes\r";
	}

	if($ssh->expect(5,"password"))
	{ 
		# Checking for password promting

		print $ssh "$L_USER_PASSWD\r";
		
		print "\n##Password is passed second time login##\n";

		if($ssh->expect(5,"\$") || $ssh->expect(5,"\>"))
		{ 
			#Checking finally for command promt

			print "\n##Connected to Destination Machine##\n";
			if($issudouser eq "Yes")
			{
				print $ssh "sudo su - $sudotouser\r";
				
				if($ssh->expect(10,"Password"))
				{ 
					# Checking for password promting
			
					print $ssh "$L_USER_PASSWD\r";
		
				}
				if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
				{ 
					print "\n##Connected to Destination Machine with sudo user##\n";

				}
		
			}


		}
	
		print $ssh "cd $DIR_BASE/ServicePackObjects\r";

		print "Changed to directory\n";
		if($ssh->expect(5,"\$") || $ssh->expect(5,"\>"))
		{ 
			#Checking finally for command prompt

			#print "\n##changed to directory##\n";
			
			print $ssh "java StringEncrypter DECRYPT $row[2] > spwd.txt\r";

			if($ssh->expect(5,"\$") || $ssh->expect(5,"\>"))
			{
				open spwd, "$DIR_BASE/ServicePackObjects/spwd.txt" or die $!;
				#open(spwd, "spwd.txt") || die("$!");
				@raw_data=<spwd>;
				close(spwd);
				$S_USER_PASSWD= @raw_data[0];
 
				#print "\ntarget password last is ::$S_USER_PASSWD \n";	
			}
			print $ssh "java StringEncrypter DECRYPT $row[4] > dbpwd.txt\r";
			if($ssh->expect(5,"\$") || $ssh->expect(5,"\>"))
			{
				print $ssh "perl -p -e 's/\s+$/ /g' dbpwd.txt\r";
				open dbpwd, "$DIR_BASE/ServicePackObjects/dbpwd.txt" or die $!;
				
				#open(DAT1, "$DIR_BASE/ServicePackObjects/dbpwd.txt");
				@raw_data1=<dbpwd>;
				close(dbpwd);

				$DB_USER_PASSWD = @raw_data1[0];

				#Reg Ex to remove new lines, tabs,spaces etc from string
				$DB_USER_PASSWD =~ s/\s+$//; #As string read from while includes new line
 	
				#print "\n target schema password is ::$DB_USER_PASSWD";
			}
		
			system("rm -r $DIR_BASE/ServicePackObjects/spwd.txt");

			system("rm -r $DIR_BASE/ServicePackObjects/dbpwd.txt");

			
		}

	}
	else
	{
		print "\n ## CONNECTION TIMED OUT, WRONG PASSWORD ENTERED CHECK ONCE ## \n";
		$ssh->log_file(undef);	
		$ssh->hard_close();	
		exit;

	}
	############################################
	##  End of source machine login
	############################################


	
}
1;
