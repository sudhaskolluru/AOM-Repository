#!/usr/bin/perl 
#REQUIRED PROCEDURES
#///////////////////////////
require ("get_patch_cmdline_var.pl");
require ("get_instance_details.pl");
require ("patch_copy_to_dest.pl");
#//////////////////////////////

$no_args = $#ARGV;
if($no_args  < 3)
{
	print "InSufficient Arguments....\n";
	print "Usage :\n";
	print "perl patch_execute.pl DB_NAME SRC_LOCATION DEST_LOCATION1 \n";
	exit;
}
else
{
	print "perl patch_execute.pl $DB_NAME $SRC_LOCATION $DEST_LOCATION1 $FILE_NAME $PASS_WORD $MIG_TYPE\n" ;
	#print "before calling get_patch_cmdline_var() \n";
	get_patch_cmdline_var(@ARGV);
	#print "after calling get_patch_cmdline_var()";
	get_instance_details();
	#print "after calling patch_copy_to_dest()";
	patch_copy_to_dest();
	#print "after calling patch_copy_to_dest()";
	print "\n*********Patch Migration Process Completed********\n";
	exit();	
}
