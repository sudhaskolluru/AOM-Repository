#!/usr/bin/perl 
#REQUIRED PROCEDURES
#///////////////////////////
require ("get_forms_cmdline_var.pl");
require ("get_instance_details.pl");
require ("form_download.pl");
#//////////////////////////////

print "Test print";
	$no_args = $#ARGV;
	if($no_args  < 2){
	print "InSufficient Arguments....\n";
	print "Usage :\n";
	print "perl form_download_execute.pl DB_NAME SRC_LOCATION DEST_LOCATION \n";
	exit;
	}
	else{
	print "perl form_download_execute.pl $DB_NAME $SRC_LOCATION $DEST_LOCATION2 $FORM_NAME $OBJECT_TYPE \n" ;
	print "before calling get_forms_cmdline_var()";
	get_forms_cmdline_var(@ARGV);
	print "after calling get_forms_cmdline_var()";
	get_instance_details();
	print "after calling get_instance_details()";
	form_download();
	print "after calling form_download()";
	exit();	
	}
