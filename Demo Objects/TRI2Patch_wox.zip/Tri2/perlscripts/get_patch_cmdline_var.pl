sub get_patch_cmdline_var 
{
	print "Below are the Arguments being Passed to migrator.....\n";

	my $i=0;
	$DB_NAME = @_[$i++];
	print "Param1 :db name -> $DB_NAME \n";
	$SRC_LOCATION = @_[$i++];
	print "Param2 :Source Location -> $SRC_LOCATION \n";

	$DEST_LOCATION1=@_[$i++];
	print "Param3 :Destination Location -> $DEST_LOCATION1 \n";

	$FILE_NAME=@_[$i++];
	print "Param4 :Patch name -> $FILE_NAME \n";

    $PASS_WORD=@_[$i++];
	#print "Param5 :PASS_WORD name -> $PASS_WORD \n";

	$MIG_TYPE=@_[$i++];
	print "Param6 :MIG_TYPE name -> $MIG_TYPE \n";
}
1;