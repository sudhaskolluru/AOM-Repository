#!/usr/bin/perl

# This Program reads Table containing information about Instances and their
# Connection variables

use DBI;


my $DB_NAME = "HLPDDEV";
	print "entered get_instance_details";
	         my %instanceDetails;
	         open my $in, "InstanceDetails.properties" or die $!;
	         while(<$in>) 
	         {
	            $instanceDetails{$1}=$2 while m/(\S+)=(\S+)/g;
	         }
	
	
		
		my $HOST= $instanceDetails{'Host'};
		my $SID = $instanceDetails{'DB_SID'};
		my $PORT= $instanceDetails{'DB_PORT'};         
		# Read all this infor from t_mig_setup table
		my $DBUSER =$instanceDetails{'dbUser'};
		my $DBUSER_PASSWD=$instanceDetails{'dbPassword'};
	
	
	#print "assigend the values for all db connection";
	print "\nHost instance  is $HOST\n";

	#String for connecting to database using DBI Module
	#$connstring = "dbi:Oracle:host=$HOST;sid=$SID;port=$PORT";
	$connstring = "dbi:Oracle:$SID";



	# Connecting to Database and Querying table T_MIG_INSTANCE_DETAILS 
	#/////////////////////////////////////////////////////////////////////	
	$dbh = DBI->connect($connstring,$DBUSER,$DBUSER_PASSWD) || die "cannot connect to Oracle Database:$DBI::errstr\n";

	print "dbname $DB_NAME\n";
	
	$sth = $dbh->prepare("select user_name from t_users") or die "Cant prepare SQL statement: $DBI::errstr";
	print "after DB\n";
	$sth->execute()or die "Can't execute SQL statement: $DBI::errstr\n";

	@row = $sth->fetchrow_array;
	$sth->finish();
	
	

	$SOURCE_IP = $row[0];
	print "row ) : $row[0]";
	
	$S_USER_NAME = $row[1];
	$S_USER_PASSWD =$row[2];
	print "password is $S_USER_PASSWD\n";
	$DB_USER= $row[3];
	$DB_USER_PASSWD =$row[4];
	$INSTANCE_APPL = $row[5];
	$MIG_SETUP_ID  = $row[6];
	
	
	#print "** $INSTANCE_APPL***\n";

	#Disconnecting from the Database
	$dbh->disconnect or warn "Error disconnecting : $DBI::errstr\n";

