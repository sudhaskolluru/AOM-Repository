sub get_upload_aol_cmdline_var 
{
	my $i=0;

	$DB_NAME         = @_[$i++];
	print "\n DB --> $DB_NAME \n";
	
	$LCT_FILE_NAME   = @_[$i++];
	print "\n LCT File Name --> $LCT_FILE_NAME \n";

	$LDT_FILE_NAME   = @_[$i++];
	print "\n LDT File Name --> $LDT_FILE_NAME \n";

	$SRC_LDT_LOCN    = @_[$i++];
     	print "\n Source Location --> $SRC_LDT_LOCN \n";

       	$PASS_WORD       = @_[$i++];	

	$OBJECT_TYPE     = @_[$i++];
	print "\n Object Type --> $OBJECT_TYPE \n";

	$APPL_SHORT_NAME = @_[$i++];
	print "\n Application short name --> $APPL_SHORT_NAME \n";

	$OBJ_OWNER 	 = @_[$i++];
	print "\n Object Owner --> $OBJ_OWNER \n";

	
	$MIG_REQ_NUMBER  = @_[$i++];
	print "\n Migration Request Number --> $MIG_REQ_NUMBER \n";

	$WORKFLOW_UPLOAD_MODE  = @_[$i++];
	print "\n Oracle Workflow Upload Mode --> $WORKFLOW_UPLOAD_MODE \n";


	#print "\n Object_name::$OBJ_OWNER";	
	#print "\n Migration Request Number::$MIG_REQ_NUMBER";
	#print "\n$DB_NAME $LCT_FILE_NAME $LDT_FILE_NAME $SRC_LDT_LOCN $PASS_WORD $OBJECT_TYPE $APPL_SHORT_NAME $OBJ_OWNER\n";
}
1;
