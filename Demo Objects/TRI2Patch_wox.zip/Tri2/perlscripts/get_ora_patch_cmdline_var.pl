sub get_ora_patch_cmdline_var 
{
	print "Below are the Arguments being Passed to migrator.....\n";

	my $i=0;
	$DB_NAME = @_[$i++];
	print "Param1 :db name -> $DB_NAME \n";
	
	$SRC_LOCATION = @_[$i++];
	print "Param2 :Source Location -> $SRC_LOCATION \n";

	$FILE_NAME=@_[$i++];
	print "Param3 :Patch name -> $FILE_NAME \n";

	$PATCH_NUM=@_[$i++];
	print "Param4 :Patch number is -> $PATCH_NUM \n";

	$ORA_SYS_PWD=@_[$i++];
	#print "Param5 :SYSTEM user password is -> $ORA_SYS_PWD \n";

    $PASS_WORD=@_[$i++];
    #print "Param6 :Connection password is -> $PASS_WORD \n";
}
1;