#!/usr/bin/perl 
use Expect;



$TIMEOUT = 120;  # Setting Timeout 
# Expect Constant
	


	$S_USER_NAME='pddev';
	$SOURCE_IP='192.168.0.29';
	$S_USER_PASSWD='pddev@123';
	$DEST_LOCATION1='/home/pddev/TrinitiApps28/MigBuild';
	$WINDOWS_IP='192.168.0.206';
	$WINDOWS_USERNAME='Administrator';
	$WINDOWS_PASSWORD='welcome@123';
	$IOP_BIN='D:\IOP_Software\bin';

       $IOP_USER='Admin';
	$IOP_USER_PWD='welcome1234';


	
		
			#/////////////////////////////////
			# Connecting to Source Machine
			#/////////////////////////////////
			$ssh = Expect->spawn("ssh -l $S_USER_NAME $SOURCE_IP");#Spawning secure shell process 
		
			print " Hello connecting user is : $S_USER_NAME\n";
		
						
			print $ssh "$S_USER_PASSWD\r";
		
			if($ssh->expect($TIMEOUT,"password"))
			{ 
				# Checking for password promting
		
				print $ssh "$S_USER_PASSWD\r";
				print "\n##Password is passed##\n";
				
				if($ssh->expect($TIMEOUT,"\$"))
				{ 
					#Checking finally for command promt
				
					print "\n##Connected to Destination Machine##\n";
					
					#changing directory to DEST DIR 
					$TIMEOUT = 120;
					
					print $ssh "telnet $WINDOWS_IP\r";
										
					if($ssh->expect($TIMEOUT,"login:"))
					{
						print $ssh "$WINDOWS_USERNAME\r";
					}
					if($ssh->expect($TIMEOUT,"password:"))	
					{
						print $ssh "$WINDOWS_PASSWORD\r";

					}
					if($ssh->expect($TIMEOUT,"\>"))	
					{
						print "\n##Password is passed for Windows machine##\n";
						print $ssh "cd $IOP_BIN\r";
						print $ssh "dir\r";
						print $ssh "D:\r";
						if($ssh->expect(120,"\>"))	
						{
							print "\nAfter DIR##\n";
							print $ssh "preparemigration_setenv.bat -u $IOP_USER -p $IOP_USER_PWD\r";
							print "\nAfter set MW and EPM oracle paths\n";
							print $ssh "preparemigration.bat -u $IOP_USER -p $IOP_USER_PWD\r";
							print "\nAfter run the preparemigration.bat file \n ";

							if($ssh->expect(700,"\>"))	
							{
								print "\nAfter prepare mig##\n";
								print $ssh "cd ..\r";
								#print $ssh "dir\r";
								print $ssh "jar cvf custom.zip custom\r";
								if($ssh->expect(1000,"\>") || $ssh->expect(700,"\$"))	
								{
								  print "\nAfter archiving custom folder##\n";
		     		  
								  if($ssh->expect(100,"\>") || $ssh->expect(100,"\$"))	
								  {
									print "\nAbout to do SCP..\n";
                        					  }
                        					  else
								  {
					                            print "\n Failed to create custom.zip \n";
				                               }

			                              }

							
							}
							else
							{
								print "\n ------IOP Model export Failed cntrl is in else\n";
								exit;
							}
							
						}
						else
						{
							print "\n ## CONNECTION TIMED OUT, WINDOWS MACHINE NOT RESPONDING ## \n";
							exit;
						}
					}
					else
					{
						print "\n ## CONNECTION TIMED OUT, WINDOWS MACHINE IS NOT CONNECTING OR WRONG PASSWORD CHECK ONCE  ## \n";
						exit;
					}

				}
				else
				{
					print "\n ## CONNECTION TIMED OUT, WRONG PASSWORD CHECK ONCE ## \n";
					exit;
				}
			}
			else
			{
				print "\n ### CONNECTION TIMED OUT IN MAKING CONNECTION### \n";
				exit;
			}
			
			
			#//////////////////////////////////
				
			
	
		
	$ssh->hard_close();
	exit;		
