
sub get_cmdline_var 
{
	my $i=0;
	$DB_NAME = @_[$i++];
	$ENT_TYPE = @_[$i++];

	$APPL_SHORT_NAME=@_[$i++];

    	$PASS_WORD=@_[$i++];

	$OBJ_TYPE = @_[$i++];

	$OBJ_NAME = @_[$i++];
	
	#Insert '_' if Object Name Contains spaces

	if($OBJ_NAME =~/\s+/)
	{
		print "\n Object Name Contains spaces\n";
		#$OBJ_NAME = "'$OBJ_NAME'";
		$OBJ_NAME = "$OBJ_NAME";
	}

	$SEQ_NUM  = @_[$i++];
	$OBJ_OWNER  = @_[$i++];
        $MIG_REQ_NUMBER = @_[$i++];
	#print "$DB_NAME $PASS_WORD $ENT_TYPE $APPL_SHORT_NAME $PASS_WORD $OBJ_TYPE $OBJ_NAME $SEQ_NUM\n";
}
1;
