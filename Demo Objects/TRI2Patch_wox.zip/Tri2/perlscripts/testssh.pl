#!/usr/bin/perl 
use Expect;


$TIMEOUT=20;
$S_USER_NAME ='tri2prod';
$SOURCE_IP='192.168.81.30';
$S_USER_PASSWD='tri2prod@123';

$ssh = Expect->spawn("ssh -l $S_USER_NAME $SOURCE_IP");# Spawning secure shell process 

	print $ssh "$S_USER_PASSWD\r";

	if($ssh->expect($TIMEOUT,"password"))
	{ 
		# Checking for password promting

		print $ssh "$S_USER_PASSWD\r";
		print "\n##Password is passed##\n";

		if($ssh->expect($TIMEOUT,"\$"))
		{ #Checking finally for command promt

			print "\n##Connected##\n";
			print $ssh "cd /software/Tri2ProductionHome\r";
			print "current directory is \n";

			print $ssh "cd test\r";
			
			print $ssh "pwd\r";

			if($ssh->expect($TIMEOUT,"US"))
			{
				print "\n##you are in fmb location##\n";
			}
		}
		else
		{

			print "\n ## CONNECTION TIMED OUT IN CONNECTION  ## \n";
			exit;
		}
	}
	else
	{
		print "\n ### CONNECTION TIMED OUT IN MAKING CONNECTION### \n";
		exit;
	}


	

	
	
