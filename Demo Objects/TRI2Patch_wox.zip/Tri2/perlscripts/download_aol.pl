
#!/usr/bin/perl 
#REQUIRED PROCEDURES
#///////////////////////////
require ("get_cmdline_var.pl");
require ("get_instance_details.pl");
require ("download_LDT.pl");
require ("conn_download_LDT.pl");
#//////////////////////////////

$no_args = $#ARGV;
if($no_args  < 4){
	print "InSufficient Arguments....\n";
	print "Usage :\n";
	print "perl download_aol.pl INSTANCE_NAME ENT_TYPE APPL_SHORT_NAME OBJ_TYPE OBJ_NAME SEQ_NUM\n";
	exit;
}
else
{
	print "\n before calling get_cmdline_var()\n ";
	get_cmdline_var(@ARGV);
	print "after calling get_cmdline_var()";
	get_instance_details();
	print "\n after calling get_instance_details()\n ";
	download_LDT();
	print "\n after calling download_LDT()\n ";

	print "\n object type in download_aol.pl is:: $OBJ_TYPE\n ";

	
	if(($OBJ_TYPE eq "DISCOVERER_REPORTS") || ($OBJ_TYPE eq "DISCOVERER_BA_FOLDER"))
	{
		print "\n abt to call download_discoverer_report()\n ";
		download_discoverer_report();
	}
	else
	{
		print "\n abt to call conn_download_LDT()\n ";

		conn_download_LDT();
	}

}
