
require("conn_download_LDT.pl");

# this program downloads required ldt file using corresponding lct file


sub download_LDT
{
	#creating required directories to store log data and ldt file

	$S_DOWNLOAD_BASE = "MIG_TOOL/Download/";	

	print "\n Seqnum is $SEQ_NUM \n";

	$L_SEQNUM_BASE = $L_DOWNLOAD_BASE."$SEQ_NUM/"; # Local SEQ BASE

	$S_SEQNUM_BASE = $S_DOWNLOAD_BASE."$SEQ_NUM/";# SOURCE SEQ BASE  dir full path

	#preparing appsora file

	$appsora_filepath = $INSTANCE_APPL."APPSORA.env";

	# preparing parameters which are passed to FNDLOAD function 


	#Defining additional parameters for flex fields


	# finding required lct file used for downloading 
	#  of LDT file  using ENT_TYPE variable

	$ENT_TYPE =~ tr/A-Z/a-z/;

	$ENTITY_TYPE=~ tr/A-Z/a-z/;

	print "%%%%%%%%%Object being downloaded is: \"$OBJ_NAME\"";

	if($ENT_TYPE eq "program" || $OBJ_TYPE eq "CONCURRENT_PROGRAM_NAME")
	{

		$param1 = "APPLICATION_SHORT_NAME=$APPL_SHORT_NAME"." ";
		$param1 = $param1."$OBJ_TYPE=\"$OBJ_NAME\"";
		$lct_filename = "afcpprog.lct";
		$ENTITY_TYPE = "program";

	}
	elsif($ENT_TYPE eq "executable" || $OBJ_TYPE eq "EXECUTABLE_NAME")
	{

		$param1 = "APPLICATION_SHORT_NAME=$APPL_SHORT_NAME"." ";
		$param1 = $param1."$OBJ_TYPE=\"$OBJ_NAME\"";
		$lct_filename = "afcpprog.lct";
              $ENTITY_TYPE = "executable";
	}
	elsif($ENT_TYPE eq "request_group" || $OBJ_TYPE eq "REQUEST_GROUP_NAME")
	{
		$param1 = "APPLICATION_SHORT_NAME=$APPL_SHORT_NAME"." ";
		$param1 = $param1."$OBJ_TYPE=\"$OBJ_NAME\"";
		$lct_filename = "afcpreqg.lct";
		$ENTITY_TYPE = "request_group";
	}
	elsif($ENT_TYPE eq "fnd_lookup_type" || $OBJ_TYPE eq "LOOKUP_TYPE")
	{
		$param1 = "APPLICATION_SHORT_NAME=$APPL_SHORT_NAME"." ";
		$param1 = $param1."$OBJ_TYPE=\"$OBJ_NAME\"";
		$lct_filename = "aflvmlu.lct";
        	$ENTITY_TYPE = "fnd_lookup_type";
	}
	elsif($ENT_TYPE eq "profile"  || $OBJ_TYPE eq "PROFILE_NAME"){
		$param1 = "APPLICATION_SHORT_NAME=$APPL_SHORT_NAME"." ";
		$param1 = $param1."$OBJ_TYPE=\"$OBJ_NAME\"";
		$lct_filename = "afscprof.lct";
		$ENTITY_TYPE = "profile";
	}
	elsif($ENT_TYPE eq "fnd_attachment_functions" || $OBJ_TYPE eq "FND_ATTACHMENT_FUNCTIONS")
       {
		$param1 = "APPLICATION_SHORT_NAME=$APPL_SHORT_NAME"." ";
		$lct_filename = "afattach.lct";
		$ENTITY_TYPE = "fnd_attachment_functions";
	}

	elsif($ENT_TYPE eq "fnd_new_messages"  || $OBJ_TYPE eq "MESSAGE_NAME")
	{
		$param1 = "APPLICATION_SHORT_NAME=$APPL_SHORT_NAME"." ";
		$param1 = $param1."$OBJ_TYPE=\"$OBJ_NAME\"";
		$lct_filename = "afmdmsg.lct";
		$ENTITY_TYPE = "fnd_new_messages";
	}
       elsif($ENT_TYPE eq "req_set"  || $OBJ_TYPE eq "REQUEST_SET_NAME")
	{
		$param1 = "APPLICATION_SHORT_NAME=$APPL_SHORT_NAME"." ";
		$param1 = $param1."$OBJ_TYPE=\"$OBJ_NAME\"";
		$lct_filename = "afcprset.lct";
		$ENTITY_TYPE = "req_set";
	}
	#elsif($ENT_TYPE eq "value_set"|| $ENT_TYPE eq "desc_flex" || $ENT_TYPE eq "key_flex" || $ENT_TYPE eq "value_security_rule" || $ENT_TYPE eq "value_rollup_group" || $ENT_TYPE eq "value_set_value")
	elsif( $ENT_TYPE eq "desc_flex"  || $ENT_TYPE eq "value_security_rule" || $ENT_TYPE eq "value_rollup_group"  || $OBJ_TYPE eq "DESCRIPTIVE_FLEXFIELD_NAME")
	{
		$param1 = "APPLICATION_SHORT_NAME=$APPL_SHORT_NAME"." ";
		#$OBJ_NAME =~ s/\'//g;        
		$param1 = $param1."$OBJ_TYPE=\"$OBJ_NAME\"";
		$lct_filename = "afffload.lct";
		if ($ENT_TYPE eq "value_sequrity_rule")
		{
			$param2 =   "FLEX_VALUE_RULE_NAME=\"%\""." ";
			$param2 =   $param2."PARENT_FLEX_VALUE_LOW=\"%\"";			
		}
		elsif ($ENT_TYPE eq "value_rollup_group")
		{
			$param2 = "HIERARCHY_CODE=\"%\"" ;
		}
	
		$ENTITY_TYPE = "desc_flex";
             
	}
       elsif ($ENT_TYPE eq "key_flex"  || $OBJ_TYPE eq "ID_FLEX_CODE")
       {
                 $param1  = "P_LEVEL='COL_ALL:FQL_ALL:SQL_ALL:STR_ONE:WFP_ALL:SHA_ALL:CVR_ALL:SEG_ALL\' ";
                 $param1 = $param1. " APPLICATION_SHORT_NAME=$APPL_SHORT_NAME"." ";
		   $lct_filename = "afffload.lct";
 
 
                  @values = split('-->',$OBJ_NAME);
                   
                  $param2 = "ID_FLEX_CODE=\"@values[0]\"";
                  $param2 = $param2." P_STRUCTURE_CODE=\"@values[1]\"";

		    $OBJ_NAME=@values[1];
             
                 	
	           $ENTITY_TYPE = "key_flex";
       }
	elsif($ENT_TYPE eq "value_set" || $OBJ_TYPE eq "FLEX_VALUE_SET_NAME")
	{
		$param1 = "$OBJ_TYPE=\"$OBJ_NAME\"";
		$lct_filename = "afffload.lct";
		$ENTITY_TYPE = "value_set";

	}
	elsif($ENT_TYPE eq "value_set_value"  || $OBJ_TYPE eq "FLEX_VALUE_SET_VALUE_NAME")
	{
		$param1 = "FLEX_VALUE_SET_NAME=\"$OBJ_NAME\"";
		$lct_filename = "afffload.lct";
		$ENTITY_TYPE = "value_set_value";

	}
	elsif($ENT_TYPE eq "function"  || $OBJ_TYPE eq "FUNCTION_NAME")
	{
		$param1 = "$OBJ_TYPE=\"$OBJ_NAME\"";
		$lct_filename = "afsload.lct";
		$ENTITY_TYPE = "function";
	}
	elsif($ENT_TYPE eq "menu"  || $OBJ_TYPE eq "MENU_NAME")
	{
		$param1 = "$OBJ_TYPE=\"$OBJ_NAME\"";
		$lct_filename = "afsload.lct";
		$ENTITY_TYPE = "menu";
	}
	elsif($ENT_TYPE eq "entry"  || $OBJ_TYPE eq "ENTRY_NAME")
	{
		$param1 = "$OBJ_TYPE=\"$OBJ_NAME\"";
		$lct_filename = "afsload.lct";
		$ENTITY_TYPE = "entry";
	}

	elsif($ENT_TYPE eq "form"  || $OBJ_TYPE eq "FORM_NAME")
	{
		$param1 = "APPLICATION_SHORT_NAME=$APPL_SHORT_NAME"." ";
		$param1 = $param1."$OBJ_TYPE=\"$OBJ_NAME\"";
		$lct_filename = "afsload.lct";
		$ENTITY_TYPE = "form";
	}
	elsif($ENT_TYPE eq "fnd_form_custom_rules"  || $OBJ_TYPE eq "FND_FORM_FUNCTION_NAME")
	{
		$param1 = "";
		$param1 = $param1."FUNCTION_NAME=\"$OBJ_NAME\"";
		$lct_filename = "affrmcus.lct";
		$ENTITY_TYPE = "fnd_form_custom_rules";
	}
       elsif($ENT_TYPE eq "fnd_responsibility"  || $OBJ_TYPE eq "FND_RESPONSIBILITY_KEY")
	{
		$param1 = "";
		$param1 = $param1."RESP_KEY=\"$OBJ_NAME\"";
		$lct_filename = "afscursp.lct";
		$ENTITY_TYPE = "fnd_responsibility";
	}
       elsif($ENT_TYPE eq "fnd_user"  || $OBJ_TYPE eq "FND_USER_NAME")
	{
		$param1 = "";
		$param1 = $param1."USER_NAME=\"$OBJ_NAME\"";
		$lct_filename = "afscursp.lct";
		$ENTITY_TYPE = "fnd_user";
	}
	 elsif($ENT_TYPE eq "style"  || $OBJ_TYPE eq "PRINTER_STYLE_NAME")
	{
		$param1 = "$OBJ_TYPE=\"$OBJ_NAME\"";
		$lct_filename = "afcppstl.lct";
		$ENTITY_TYPE = "style";
	}

     
	# Preparing Connectiong string 
	$usr_passwd_dbname= $DB_USER.'/'.$DB_USER_PASSWD.'@'.$INSTANCE_SID;

	# finding ldt file name from lct file  
	@tokens = split(/\./,$lct_filename); # Getting lct file header

	$ACTUAL_OBJ_NAME = $OBJ_NAME;
	$OBJ_NAME =~ s/\s+/_/g; # Replacing spaces present in ObjectName with '_'
	$OBJ_NAME =~ s/\'//g;
  
	#Preparing final Ldt file
       $ldt_filename = $OBJ_NAME."_".$OBJ_TYPE.".ldt";
	
	$ENT_TYPE =~ tr/a-z/A-Z/; # Finally converting Enitity type to Caps 

	$ENTITY_TYPE =~ tr/a-z/A-Z/; # Finally converting Enitity type to Caps 

	return;
	

}
1;
