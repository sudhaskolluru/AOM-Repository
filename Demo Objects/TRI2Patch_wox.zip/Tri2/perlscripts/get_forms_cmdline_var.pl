sub get_forms_cmdline_var 
{

	my $i=0;
	$DB_NAME = @_[$i++];
	print "\n DB --> $DB_NAME \n";
	$SRC_LOCATION = @_[$i++];
	print " SOURCE LOCATION --> $SRC_LOCATION \n";

	$ORACLE_RELEASE_VERSION=@_[$i++];
	print " ORACLE_RELEASE_VERSION --> $ORACLE_RELEASE_VERSION \n";

	$DEST_LOCATION2=@_[$i++];
	print " ORACLE FORM Destination Location --> $DEST_LOCATION2 \n";
	
	$FORM_NAME=@_[$i++];
	print " Form Name --> $FORM_NAME \n";

        $PASS_WORD=@_[$i++];
    
	$OBJECT_TYPE=@_[$i++];
	print " OBject Type --> $OBJECT_TYPE \n";

	$MIG_REQ_NUMBER  = @_[$i++];
	print " Migration Request Number --> $MIG_REQ_NUMBER \n";
	
}
1;
