#!/usr/bin/perl
use Expect;
require ("download_LDT.pl");

# this program uploads required ldt file using corresponding lct file
sub upload_LDT
{

       print "\n\n**************** AOL Objects Migration Logs ******************\n";
	
       print "\n DB --> $DB_NAME \n";
	print "\n LCT File Name --> $LCT_FILE_NAME \n";
	print "\n LDT File Name --> $LDT_FILE_NAME \n";
	print "\n Source Location --> $SRC_LDT_LOCN \n";
	print "\n Object Type --> $OBJECT_TYPE \n";
	print "\n Application short name --> $APPL_SHORT_NAME \n";
	print "\n Object Owner --> $OBJ_OWNER \n";
	print "\n Migration Request Number --> $MIG_REQ_NUMBER \n";
	print "\n Oracle Workflow Upload Mode --> $WORKFLOW_UPLOAD_MODE \n";

    	# Expect Constant
 	$Expect::Log_Stdout=1;	

	#creating LOCAL SEQNUM BASES 
		
	my @tokens = split(/\./,$LDT_FILE_NAME); # Getting ldt file header
	$SUB_FOLDER= $tokens[0];
		
	$UPLOAD_SEQNUM_BASE = $L_UPLOAD_BASE."$SUB_FOLDER/"; # Local SEQ BASE
      
	print "\n\n Location in Local instance............$UPLOAD_SEQNUM_BASE\n";
	
	system("mkdir -p $UPLOAD_SEQNUM_BASE");

    #-------------------------------#
	#     preparing appsora file    #
	#-------------------------------#

	$appsora_filepath = $INSTANCE_APPL."APPSORA.env";
 
	# Preparing Connectiong string 
	$usr_passwd_dbname= $DB_USER.'/'.$DB_USER_PASSWD.'@'.$INSTANCE_SID;

	$DST_LDT_LOCN = "MIG_TOOL/Upload/Upload/"."$SUB_FOLDER/";

	#--------------------------------------------------------------#
	# Prepearing Timestamp to append at the end of the backup file #
	#--------------------------------------------------------------#

         ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
            $mon=$mon+1;
            if ($mon < 10) {$mon = "0$mon";}
  	     if ($hour < 10){$hour = "0$hour";}
  	     if ($min < 10) {$min = "0$min";}
   	     if ($sec < 10) {$sec = "0$sec";}
 	     $year=$year+1900;
	     $TimeStamp = $mday.''.$mon.''.$year._.$hour.':'.$min.':'.$sec;


	     print "\n**** Destination Location **** ::: $DST_LDT_LOCN\n";
	
		#------------------------------#
		# Connecting to Source Machine #
		#------------------------------#

		$ssh = Expect->spawn("ssh -l $S_USER_NAME $SOURCE_IP -p $INSTANCE_PORT_NUMBER");# Spawning secure shell process 
	
		# Checking whether it asks for exchange of keys
		if($ssh->expect(20,"connecting"))
		{
			print $ssh "yes\r";
		}
		
		if($ssh->expect(20,"password"))
		{	
	    
		    # Checking for password promting
	
		    print $ssh "$S_USER_PASSWD\r";
			
		    if($ssh->expect(10,"\$") || $ssh->expect(10,"\>"))
		    {
		    	#Checking finally for command promt
			
			print "\n##Connected to target Instance##\n";

			#if user registered is sudo user then switch to applmgr user and then execute commands
			if($IS_SUDO_USER eq "Yes")
			{
				print $ssh "sudo su - $SUDO_TO_USER\r";
				
				if($ssh->expect(20,"Password"))
				{ 
					# Checking for password promting
					
					print $ssh "$S_USER_PASSWD\r";

					if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
					{ 
						print "\n##Finally Connected to Destination instance..##\n";

					}
					else
					{
						print "\n Connecting through sudo login failed\n";
					}
				}
			}

		    
		    }
		    else
		    {
				print "\n [ERROR]::## CONNECTION TIMED OUT IN CONNECTION  ## \n";
				exit;
		    }
		}
		else
		{
			print "\n [ERROR]::### CONNECTION TIMED OUT IN MAKING CONNECTION### \n";
			exit;
		}
		
	
		#------------------------------#
		#      Creating SOURCE BASE    #
		#------------------------------#
          
		print $ssh "mkdir -p $DST_LDT_LOCN\r";
	
		if($ssh->expect(5,"\$"))
		{
			print "\n##$DST_LDT_LOCN is Created\n";
		}
	       elsif($ssh->expect(5,"\>"))
		{
			#Checking finally for command promt
			
			print "\n##Connected to target Instance##\n";

	       }
		else
		{
			print "\n[ERROR]::## CONNECTION TIMED OUT WHILE CREATING DST_LDT_LOCN  ##\n";
	
			$ssh->log_file(undef);	
			$ssh->hard_close();	
			exit;
		}
	
		#----------------------------------------------------------#
		#          Copying files to respective directories         #  
        # copying log file from SOURCE BASE to DEST BASE Directory #
		#----------------------------------------------------------#
	
		print "\n\n*** SCP Command Executed ***->> scp -r -P $L_INSTANCE_PORT_NUMBER $L_USER_NAME\@$LOCAL_IP:$SRC_LDT_LOCN/$LDT_FILE_NAME $DST_LDT_LOCN \n\n";
	 	
	 	print $ssh "scp -r -P $L_INSTANCE_PORT_NUMBER $L_USER_NAME\@$LOCAL_IP:$SRC_LDT_LOCN/$LDT_FILE_NAME $DST_LDT_LOCN\r";
		
		print $ssh "$L_USER_PASSWD\r";
		
		if($ssh->expect(20,"?"))
		{
		       print $ssh "yes\r";
		}
		if($ssh->expect(20,"password"))
		{
			print $ssh "$L_USER_PASSWD\r";
			print "\n##password is supplied##\n";
		}
		else
		{
			print "\n[ERROR]::## CONNECTION TIMED OUT WHILE COPYING THE LOG FILES FROM SOURCE TO LOCAL MACHINE ##\n";
			$ssh->log_file(undef);	
			$ssh->hard_close();	
			exit;
		}
		if($ssh->expect(30,"100"))
		{
	
			print "\n## scp is continuing ...###\n";
			if($ssh->expect(15,"\$"))
			{
				print "\n## scp is over...all files are copied##\n";
			}
 			elsif($ssh->expect(15,"\>"))
		      {
			  #Checking finally for command promt
			
			  print "\n##Connected to target Instance##\n";

		      }
			else
			{
				print "\n[ERROR]::## CONNECTION TIMED OUT Unable to Copy the files ##\n";
	
				$ssh->log_file(undef);	
				$ssh->hard_close();	
				exit;
			}
		}

		#----------------------------------------#
		# Change to SOURCE SEQNUM  BASE DIRECTORY#
		#----------------------------------------#
		 
                     print $ssh "cd $DST_LDT_LOCN\r";
		
			if($ssh->expect(5,"$SUB_FOLDER"))
			{
				print "\n ## Directory is changed ##\n";
			}
			else
			{
				print "\n[ERROR]:: ## CONNECTION TIMED OUT WHILE CHANGING THE DIRECTORY\n";
		
				$ssh->log_file(undef);	
				$ssh->hard_close();	
				exit;
			}
		
		#-----------------------------------------------------#
		#comping APPSORA FILE present INSTANCE_APPL  directory#
		#-----------------------------------------------------#
		
		print "\nObject type here is $OBJECT_TYPE \n";

	       if(($OBJECT_TYPE ne "DISCOVERER_REPORTS") && ($OBJECT_TYPE  ne "DISCOVERER_BA_FOLDER"))
		{
			#print $ssh ". /software/oracle/tpm10tstappl/APPSORA.env\r";
			#print $ssh ". $appsora_filepath\r";
			print $ssh "echo \$FND_TOP\r";
		
			if($ssh->expect(5,"fnd"))
			{
				#print "\n ##$appsora_filepath  is Compiled##\n";
				#print "\n######## APPSORA FILE COMPILEd\n";
			}
			else
			{
				print "\n[ERROR]::## CONNECTION TIMED OUT WHILE COMPILING APPSORA FILE ##\n";
	
				$ssh->log_file(undef);	
				$ssh->hard_close();	
				exit;
			}
		}

           #----------------------------------------------------------------------------#
           # Preparing Objects variables to take backup of the current before execution #
	       #----------------------------------------------------------------------------#
		
	     $OBJ_TYPE = $OBJECT_TYPE;

            print"LDT_FILE_NAME is:: $LDT_FILE_NAME\n";

            if(index($LDT_FILE_NAME,$OBJECT_TYPE)!=-1)
            {
               print"\n enter into if block\n";
               $OBJ_NAME   =  substr($LDT_FILE_NAME, 0, index($LDT_FILE_NAME,$OBJECT_TYPE)-1);
            }
            else
            {
              print"\n enter into else block\n";
              $OBJ_NAME =  substr($LDT_FILE_NAME, 0, rindex($LDT_FILE_NAME,'.'));
            }
           

           print"\n OBJECT_NAME after removing OBJECT_TYPE is :: $OBJ_NAME \n";
          
	       print "\n About to call download_LDT().............";
	        
           download_LDT();
		
		print "\n After call to download_LDT().............";

		#-----------------------------------#
		# EXECUTING FNLOAD DOWNLOAD COMMAND #
 		#-----------------------------------#

           	print"\n  OBJECT_NAME after download_LDT()is :: $OBJ_NAME\n";

           	$backUpFile_name = $OBJ_NAME.'_'.$MIG_REQ_NUMBER.'_'.$TimeStamp;

           	print"backUpFile_name:::$backUpFile_name\n";
	
		$backup_ldt_name = $backUpFile_name;
	
              print"backup_ldt_name :::$backup_ldt_name \n";



		if($OBJECT_TYPE eq "ORACLE_WORKFLOW")
		{
                               
				#WFLOAD apps/apps 0 Y DOWNLOAD reqappv_final.wft REQAPPRV
				print "\n Processing ORACLE_WORKFLOW Download ....";
								
				$wrkflow_bckup_dir = "/tmp/MIG_TOOL/workflow_backups";
			       	print $ssh "mkdir -p $wrkflow_bckup_dir\r";
			       	
			       		if($ssh->expect(5,"\$"))
			       		{
			       			print "\n##$wrkflow_bckup_dir is Created\n";
			       		}
						 elsif($ssh->expect(5,"\>"))
		    				{
							#Checking finally for command promt
					
							print "\n##Connected to target Instance##\n";

		    				}
			       		else

			       		{
			       			print "\n[ERROR]::## CONNECTION TIMED OUT WHILE CREATING wrkflow_bckup_dir  ##\n";
			       	
			       			$ssh->log_file(undef);	
			       			$ssh->hard_close();	
			       			exit;
			       		}
		
				#To backup original
				#WFLOAD apps/apps 0 Y DOWNLOAD $wrkflow_bckup_dir/$NEW_OBJ_NAME."_bkup.wft" $NEW_OBJ_NAME
			
				@values = split('.wft',$LDT_FILE_NAME);
				  
				$NEW_OBJ_NAME = @values[0];
				
				print "\nworkflow name: @values[0]";
				$wft_bkup_name = $NEW_OBJ_NAME.'_'.$MIG_REQ_NUMBER."_bkup.wft";
				
				
				$wft_load_bkp_comm = "WFLOAD $usr_passwd_dbname 0 Y DOWNLOAD $wrkflow_bckup_dir/$wft_bkup_name  $NEW_OBJ_NAME";
				
				
				 print $ssh "$wft_load_bkp_comm\r";
				
				print "\n Workflow backup completed.....................\n";
				
				
				print "\n uploading new workflow.....................\n";
				
				#to upload workflows in UPLOAD/FORCE/UPGRADE Mode--$WORKFLOW_UPLOAD_MODE

				$fnd_load_comm = "WFLOAD $usr_passwd_dbname 0 Y $WORKFLOW_UPLOAD_MODE $LDT_FILE_NAME > extractAOLlog.log";
			}
			elsif($OBJECT_TYPE eq "DISCOVERER_REPORTS")
			{
                           	print "\n Processing Discoverer request block..............";
				$backUpFile_name = $backUpFile_name.'_'.$MIG_REQ_NUMBER.".eex";

				#eulapi -connect apps/apps@HLR12TST -export XX_DB_USERS.eex -workbook "XX_DB_USERS"
				#$fnd_load_bkp_comm = "eulapi -connect $apps_connect -export $backUpFile_name -workbook \"$OBJ_NAME\"";

				print "\n Uploading Discoverer objects ........";
				#eulapi -connect apps/apps@HLR12DEV -import TABLESPACE_FREE_STATS_REPORT.eex -identifier -preserve_workbook_owner -import_rename_mode refresh -auto_refresh -log TABLESPACE_FREE_STATS_REPORT._importlog
				$fnd_load_comm = "eulapi -connect $apps_connect -import $LDT_FILE_NAME -identifier -preserve_workbook_owner -import_rename_mode refresh -auto_refresh -log extractAOLlog.log > extractAOLlog.log";
		
			}
	        elsif($OBJECT_TYPE eq "DISCOVERER_BA_FOLDER")
			{
                           #No backup taken for discoverer business area folder as we dont have clue of ba/ folder name.So just doing import
				print "\n Uploading Discoverer objects ........";
				#eulapi -connect apps/apps@HLR12DEV -import_rename_mode refresh -import DBA_BA_Xx_Freesp_Stats_V.eex
				$fnd_load_comm = "eulapi -connect $apps_connect -import_rename_mode refresh -import $LDT_FILE_NAME > extractAOLlog.log";
		
			}
			elsif($OBJECT_TYPE eq "BNE_LAYOUTS")
			{
                          
				print "\n Processing BNE LAYOUT request block..............";
				$backUpFile_name = $backUpFile_name.".ldt";
                #$fnd_load_bkp_comm = "FNDLOAD $usr_passwd_dbname 0 Y DOWNLOAD \$BNE_TOP/patch/115/import/bnelay.lct $backup_ldt_name\".ldt\" BNE_LAYOUTS LAYOUT_ASN=\"$APPL_SHORT_NAME\" LAYOUT_CODE=\"$OBJ_NAME\"";

				print "\n Uploading ADI Layouts objects ........";
				$fnd_load_comm = "FNDLOAD $usr_passwd_dbname 0 Y UPLOAD \$BNE_TOP/patch/115/import/bnelay.lct $LDT_FILE_NAME 2> extractAOLlog.log";
		
			}
			elsif($OBJECT_TYPE eq "BNE_PRARAMLIST")
			{
				print "\n Uploading BNE ParamList objects ........";
			      #$fnd_load_comm = "FNDLOAD $usr_passwd_dbname 0 Y UPLOAD \$BNE_TOP/patch/115/import/bnelay.lct $LDT_FILE_NAME 2> extractAOLlog.log";

				$fnd_load_comm = "FNDLOAD $usr_passwd_dbname 0 Y UPLOAD \$BNE_TOP/patch/115/import/bneparamlist.lct $LDT_FILE_NAME - CUSTOM_MODE=FORCE 2> extractAOLlog.log";

			}
			elsif($OBJECT_TYPE eq "XML_PUB_REPORTS")
			{
				print "\n Processing XDOLoader request block..............";
			
				$NEW_OBJ_NAME = $LDT_FILE_NAME;
				$RTF_NAME     = $LDT_FILE_NAME;
				@values       = split('.rtf',$LDT_FILE_NAME);
				  
				$NEW_OBJ_NAME = @values[0];
				
				#$RTF_NAME="TEMPLATE_SOURCE_".$APPL_SHORT_NAME."_".$NEW_OBJ_NAME."_en_US.rtf";
                         
                           print "\n backup  File Name: $backup_ldt_name";
			       print "\n Processing XDOLoader request block..............";
	                   
			      $backUpFile_name = $backUpFile_name.".rtf";
                  #$fnd_load_bkp_comm = "java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD -DB_USERNAME $DB_USER -DB_PASSWORD $DB_USER_PASSWD -JDBC_CONNECTION $INSTANCE_DB_IP:$INSTANCE_DB_PORT:$INSTANCE_SID -LOB_TYPE TEMPLATE_SOURCE -APPS_SHORT_NAME $APPL_SHORT_NAME -LOB_CODE $backup_ldt_name -LANGUAGE en -TERRITORY US";
                
                  $fnd_load_comm = "java oracle.apps.xdo.oa.util.XDOLoader UPLOAD -DB_USERNAME $DB_USER -DB_PASSWORD $DB_USER_PASSWD -JDBC_CONNECTION $INSTANCE_DB_IP:$INSTANCE_DB_PORT:$INSTANCE_SID -LOB_TYPE TEMPLATE_SOURCE -APPS_SHORT_NAME $APPL_SHORT_NAME -LOB_CODE $NEW_OBJ_NAME -LANGUAGE en -TERRITORY US -XDO_FILE_TYPE RTF -FILE_CONTENT_TYPE 'application/rtf' -FILE_NAME $RTF_NAME -CUSTOM_MODE FORCE > extractAOLlog.log";

			}
			elsif($OBJECT_TYPE eq "XDO_DS_DEFINITIONS")
			{     
                          
                            print "\n Processing XDO_DS_DEFINITIONS request block for Backup..............";
                            $backUpFile_name=$backUpFile_name.".ldt";
		              #$fnd_load_bkp_comm = "FNDLOAD $usr_passwd_dbname 0 Y DOWNLOAD \$XDO_TOP/patch/115/import/xdotmpl.lct $backup_ldt_name\".ldt\" XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME=$APPL_SHORT_NAME DATA_SOURCE_CODE=$OBJ_NAME";

				print "\n Processing XDO_DS_DEFINITIONS request block..............";

				$fnd_load_comm = "FNDLOAD $usr_passwd_dbname 0 Y UPLOAD \$XDO_TOP/patch/115/import/xdotmpl.lct $LDT_FILE_NAME 2> extractAOLlog.log"; 

			}
			else
			{
                           
			       print "\n Processing FNDLOAD request block for BackUp..............";
                      
                            $backUpFile_name=$backUpFile_name.".ldt";
                          
     				#$fnd_load_bkp_comm = "FNDLOAD $usr_passwd_dbname 0 Y DOWNLOAD \$FND_TOP/patch/115/import/$LCT_FILE_NAME $backup_ldt_name\".ldt\" $ENTITY_TYPE $param1 $param2";

                    		print "\n Uploading AOL objects ........";
				$fnd_load_comm = "FNDLOAD $usr_passwd_dbname 0 Y UPLOAD \$FND_TOP/patch/115/import/$LCT_FILE_NAME $LDT_FILE_NAME 2> extractAOLlog.log";
			}
	
		#print "\n\n## This is the backup FNDLOAD command being executed ---- $fnd_load_bkp_comm##\n\n";
   		#print "\n\n## This is the FNDLOAD command being executed ---- $fnd_load_comm##\n\n";	
		#print "\n\n## FNDLOAD backup command being executed ----##\n\n";
   			
		
		 #print $ssh "$fnd_load_bkp_comm\r";
		 
		 print "\n\n## FNDLOAD command being executed ----##\n\n";
		 
		 print $ssh "$fnd_load_comm\r";
            
		if($OBJECT_TYPE eq "XML_PUB_REPORTS")
		{
                  $backup_ldt_name = $backUpFile_name;
	           print $ssh "cp *.rtf $backup_ldt_name\r";
        }
		
		#if($ssh->expect(100,"Report") || $ssh->expect(100,"successfully:"))
		#{
		#	print "\n ## CONNECTION TIMED OUT WHILE RUNNING FNDLOAD COMMAND ##\n";
		#	print "\n I ERROR\n";
	
	#	}
	#	else
	#	{
	
	#		print "\n##FNDLOAD  ran Successfully...##\n";
			
	#	}
		
		
    #--------------------------------------------------------------------------#
	#              Copying files to respective directories                     # 
	#--------------------------------------------------------------------------#
	# copying log file from SOURCE SEQNUM BASE to LOCAL SEQNUM BASE Directory  #
	#--------------------------------------------------------------------------#

	#$TIMEOUT=5;
		
	print "\n\nSCP Command to be Execute ->> scp -r -P $L_INSTANCE_PORT_NUMBER . $L_USER_NAME\@$LOCAL_IP:$UPLOAD_SEQNUM_BASE \n\n";
		
	print $ssh "scp -r -P $L_INSTANCE_PORT_NUMBER . $L_USER_NAME\@$LOCAL_IP:$UPLOAD_SEQNUM_BASE \r";

       
	print $ssh "$L_USER_PASSWD\r";
	
		if($ssh->expect(20,"?"))
		{
		        print $ssh "yes\r";
		}
		if($ssh->expect(20,"password"))
		{ 
			# Checking for password promting
	
			print $ssh "$L_USER_PASSWD\r";
			
			print "\n##Password is passed second time login##\n";
	
			if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
			{ 
				#Checking finally for command prompt
	
				print "\n##Connected to Destination Machine##\n";
				if($issudouser eq "Yes")
				{
					print $ssh "sudo su - $sudotouser\r";
					
					if($ssh->expect(5,"Password"))
					{ 
						# Checking for password promting
				
						print $ssh "$L_USER_PASSWD\r";
			
					}
					if($ssh->expect(10,"\$") || $ssh->expect(10,"\>"))
					{ 
						print "\n[ERROR]::##Connected to Destination Machine with sudo user##\n";
	
					}
				}
			}
              }

		else
		{
			print "\n [ERROR]::## CONNECTION TIMED OUT WHILE COPYING THE LOG FILES FROM SOURCE TO LOCAL MACHINE ##\n";
			$ssh->log_file(undef);	
			$ssh->hard_close();	
			exit;
		}

	      if($ssh->expect(20,"100"))
		{
	
			print "\n## scp is continuing ...###\n";
                           
			if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
			{
			    print "\n## scp is over...all files are copied##"; 
                                                                                                                 				
			}   
                     else
			{
				print "\n[ERROR]::## CONNECTION TIMED OUT Unable to Copy the files ##\n";
	
				$ssh->log_file(undef);	
				$ssh->hard_close();	
				exit;
			}
     		}

          
        #---------------------------------------------------------------------------------------------------------------------------------#
        #      Taking of backup                                                                                                           #
        #The below code is added for Creating BackUp Dir with The Instance Name and Object Type and copy the backupFile to created folder #   
        #---------------------------------------------------------------------------------------------------------------------------------#

        $BACKUP_DIR=$INSTANCE_SID."_".$OBJECT_TYPE;
        print "\n\n This is an area of creating backUp Folder   ->> mkdir  $DIR_BASE/../MigBackUps/$BACKUP_DIR\n";      
        system("mkdir -p $DIR_BASE/../MigBackUps/$BACKUP_DIR");
		print "\n\n This is an area of backup  ->> scp -r -P $L_INSTANCE_PORT_NUMBER ../$SUB_FOLDER/$backUpFile_name $L_USER_NAME\@$LOCAL_IP:$DIR_BASE/../MigBackUps/$BACKUP_DIR/\n";
		print $ssh "scp -r -P $L_INSTANCE_PORT_NUMBER ../$SUB_FOLDER/$backUpFile_name $L_USER_NAME\@$LOCAL_IP:$DIR_BASE/../MigBackUps/$BACKUP_DIR/\r";
              if($ssh->expect(5,"?"))
		{
		       print $ssh "yes\r";
		}
		if($ssh->expect(5,"password"))
		{
			print $ssh "$L_USER_PASSWD\r";
			print "\n##password is supplied##\n";
		}
              else
		{
			print "\n [ERROR]::## CONNECTION TIMED OUT WHILE COPYING THE LOG FILES FROM SOURCE TO LOCAL MACHINE ##\n";
			$ssh->log_file(undef);	
			$ssh->hard_close();	
			exit;
		}

		#command to delete all the contents in MIG_TOOL folder, to remove junk data
		print "folder going to delete is ::$SUB_FOLDER*\n";
                print system('pwd');
                print $ssh "rm -rf ../$SUB_FOLDER*\r";


		
 	      if($ssh->expect(5,"?") || $ssh->expect(5,"\>"))
             {
                       
                print "\n## rm is continuing....##\n"; 
                                                                                                                  				
	      }   
             else
	      {
		  print "\n## rm is over...all files are deleted.............. ##\n";
		 				  
		  $ssh->log_file(undef);	
		  $ssh->hard_close();	
	    }
            
            $ssh->log_file(undef);
            $ssh->hard_close();

}
1;


sub upload_discoverer_report()
{
	
		#print "\n Here apps connect string is ::$usr_passwd_dbname \n";
		$apps_connect 	   = $usr_passwd_dbname;
		$instance_type         = "Discoverer";
	

		##---------- about to call get_instance_details()

		get_instance_details();
		print "\n after cmng out of get_instance_details.............";
            
		upload_LDT();
		print "\n after cmng out of upload_LDT.............";


}
1;
