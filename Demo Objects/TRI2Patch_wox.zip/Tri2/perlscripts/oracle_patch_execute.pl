#!/usr/bin/perl
use Expect;

require("adpatch_execute.pl");

sub oracle_patch_execute {

	#$TIMEOUT = 120;  # Setting Timeout 
	# Expect Constant
	$Expect::Log_Stdout=1;	

	$DST_PATCH_LOCN = "MIG_TOOL/Oracle_Patches/$PATCH_NUM";

	@values = split('.zip',$FILE_NAME);
	            
	$ORACLE_PATCH_NAME=@values[0];
	
	print "\n**********Oracle Patch Name is ........$ORACLE_PATCH_NAME\n";
	
	   #/////////////////////////////////
		# Connecting to Source Machine
		#/////////////////////////////////
		$ssh = Expect->spawn("ssh -l $S_USER_NAME $SOURCE_IP -p $INSTANCE_PORT_NUMBER");# Spawning secure shell process 
	
		# Checking whether it asks for exchange of keys
		if($ssh->expect(5,"connecting"))
		{
			print $ssh "yes\r";
		}
		
		if($ssh->expect(5,"password"))
		{	
		    
		    # Checking for password promting
	
		    print $ssh "$S_USER_PASSWD\r";
					
			
		    if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
		    {
		    	#Checking finally for command prompt
			
			print "\n##Connected to target Instance##\n";

			#if user registered is sudo user then switch to applmgr user and then execute commands
			if($IS_SUDO_USER eq "Yes")
			{
				print $ssh "sudo su - $SUDO_TO_USER\r";
				
				if($ssh->expect(10,"Password"))
				{ 
					# Checking for password promting
					
					print $ssh "$S_USER_PASSWD\r";

					if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
					{ 
						print "\n##Finally Connected to Destination instance..##\n";

					}
					else
					{
						print "\n Connecting through sudo login failed\n";
					}
				}
			}

		    
		    }
		    else
		    {
	
				print "\n ## CONNECTION TIMED OUT IN CONNECTION  ## \n";
				exit;
		    }
		}
		else
		{
			print "\n ### CONNECTION TIMED OUT IN MAKING CONNECTION### \n";
			exit;
		}
		
		
		
		#//////////////////////////////////
		
	
		#//////////////////////////////
		# Creating SOURCE BASE 
		#//////////////////////////////////
		
		print $ssh "mkdir -p $DST_PATCH_LOCN\r";
	
		if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
		{
			print "\n##$DST_PATCH_LOCN is Created\n";
		}
	      	else
		{
			print "\n## CONNECTION TIMED OUT WHILE CREATING DST_LDT_LOCN  ##\n";
	
			$ssh->log_file(undef);	
			$ssh->hard_close();	
			exit;
		}
	
		#///////////////////////////////////
		#Copying files to respective directories
		# ///////////////////////////////////
		# copying log file from SOURCE BASE to DEST BASE Directory
	
		print "\n\nDude this is an area of concern ->> scp -r -P $L_INSTANCE_PORT_NUMBER $L_USER_NAME\@$LOCAL_IP:$SRC_LOCATION* $DST_PATCH_LOCN \n\n";
	 	
	 	print $ssh "scp -r -P $L_INSTANCE_PORT_NUMBER $L_USER_NAME\@$LOCAL_IP:$SRC_LOCATION* $DST_PATCH_LOCN\r";
			
		if($ssh->expect(5,"?"))
		{
		       print $ssh "yes\r";
		}
		if($ssh->expect(5,"password"))
		{ 
			# Checking for password promting
	
			print $ssh "$L_USER_PASSWD\r";
			
			print "\n##Password is passed second time login##\n";
	
			if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
			{ 
				#Checking finally for command promt
	
				print "\n##Connected to Destination Machine##\n";
				if($issudouser eq "Yes")
				{
					print $ssh "sudo su - $sudotouser\r";
					
					if($ssh->expect(10,"Password"))
					{ 
						# Checking for password promting
				              print "sudo password::$L_USER_PASSWD";
						print $ssh "$L_USER_PASSWD\r";
			
					}
					if($ssh->expect(20,"\$") || $ssh->expect(20,"\>"))
					{ 
						print "\n##Connected to Destination Machine with sudo user##\n";
	
					}
			       }
                      }
		}
		else
		{
			print "\n ## CONNECTION TIMED OUT WHILE COPYING THE LOG FILES FROM SOURCE TO LOCAL MACHINE ##\n";
			$ssh->log_file(undef);	
			$ssh->hard_close();	
			exit;
		}
		#if($ssh->expect(20,"100"))
		#{
	
		#	print "\n## scp is continuing ...###\n";
		#	if($ssh->expect(20,"\$"))
		#	{
		#		print "\n## scp is over...all files are copied##\n";
		#	}
 		#	elsif($ssh->expect(20,"\>"))
		#      {
		#	  #Checking finally for command promt
			
		#	  print "\n##Connected to target Instance##\n";

		#     }
		#	else
		#	{
		#		print "\n## CONNECTION TIMED OUT Unable to Copy the files ##\n";
	       #		$ssh->log_file(undef);	
		#		$ssh->hard_close();	
		#		exit;
		#	}
		#}
	
		#//////////////////////////////////
		# Change to SOURCE SEQNUM  BASE DIRECTORY
		#//////////////////////////////////	
			
			print "\n##Connected to Destination Machine##\n";
			
			print $ssh "cd $DST_PATCH_LOCN\r";
			
			print "\n executing unzip command for extracting oracle patch\n";
			print $ssh "unzip $FILE_NAME\r";

			if($ssh->expect(5,"[r]ename:"))
			{
		       	print $ssh "A\r";
			}
			if($ssh->expect(5,"50"))
			{
				print "\n*************zip extracted successfully\n";

			}	

			print "Setting envy to maintainence mode\n";

			print $ssh "sqlplus apps/$DB_USER_PASSWD \@\$AD_TOP/patch/115/sql/adsetmmd.sql ENABLE\r";
			
			if($ssh->expect(100,"\$"))
			{
				print "\nSuccessfully set instance to maintainence mode\n";
			}
			else
			{
				print "\Failed to set instance to maintainence mode\n";

			}
			
			print $ssh "cd $PATCH_NUM\r";	
			if($ssh->expect(100,$PATCH_NUM))
			{
				print "\nChanged dir to patch location\n";
			}
		

			print "\nCalling adpatch_execute login......\n";
			adpatch_execute();


			print $ssh "sqlplus apps/$DB_USER_PASSWD \@\$AD_TOP/patch/115/sql/adsetmmd.sql DISABLE\r";
			
			if($ssh->expect(100,"\$"))
			{
				print "\nSuccessfully unset instance from maintainence mode\n";
			}
			else
			{
				print "\Failed to unset instance from maintainence mode\n";

			}
	#///////////////////////////////////
	#Copying files to respective directories
	# ///////////////////////////////////
	# copying log file from SOURCE SEQNUM BASE to LOCAL SEQNUM BASE Directory

	print"\n\nDudethis is an area of concern->> scp -r -P $L_INSTANCE_PORT_NUMBER extractAOLlog.log $L_USER_NAME\@$LOCAL_IP:$L_UPLOAD_BASE\r";
 
	print $ssh "scp -r -P $L_INSTANCE_PORT_NUMBER extractAOLlog.log $L_USER_NAME\@$LOCAL_IP:$L_UPLOAD_BASE \r";

       
	print $ssh "$L_USER_PASSWD\r";
	
		if($ssh->expect(5,"?"))
		{
		        print $ssh "yes\r";
		}
		if($ssh->expect(5,"password"))
		{ 
			# Checking for password promting
	
			print $ssh "$L_USER_PASSWD\r";
			
			print "\n##Password is passed second time login##\n";
	
			if($ssh->expect(5,"\$") || $ssh->expect(5,"\>"))
			{ 
				#Checking finally for command prompt
	
				print "\n##Connected to Destination Machine##\n";
				if($issudouser eq "Yes")
				{
					print $ssh "sudo su - $sudotouser\r";
					
					if($ssh->expect(5,"Password"))
					{ 
						# Checking for password promting
				
						print $ssh "$L_USER_PASSWD\r";
			
					}
					if($ssh->expect(10,"\$") || $ssh->expect(10,"\>"))
					{ 
						print "\n##Connected to Destination Machine with sudo user##\n";
	
					}
			
				}
			}
              }

		else
		{
			print "\n ## CONNECTION TIMED OUT WHILE COPYING THE LOG FILES FROM SOURCE TO LOCAL MACHINE ##\n";
			$ssh->log_file(undef);	
			$ssh->hard_close();	
			exit;
		}


			#command to delete all the contents in MIG_TOOL folder, to remove junk data
		     	print $ssh "rm -rf ../../$PATCH_NUM*\r";

			if($ssh->expect(100,"\$") || $ssh->expect(100,"\]"))
			{
				print "\nDeleted extracted dir\n";
			}
			else
			{
				print "\nunable to Delete extracted dir\n";
			}


			
		#///////////////////////////////////
			

		


	#//////////////////////////////////

	$ssh->log_file(undef);	
	$ssh->hard_close();
	exit;		
}
1;
