#!/usr/bin/perl 
#REQUIRED PROCEDURES
#///////////////////////////
require ("get_forms_cmdline_var.pl");
require ("get_instance_details.pl");
require ("form_f60gen_execute.pl");
#//////////////////////////////

print "Test print";
	$no_args = $#ARGV;
	if($no_args  < 2)
       {
		print "InSufficient Arguments....\n";
		print "Usage :\n";
		print "perl forms_execute.pl DB_NAME SRC_LOCATION DEST_LOCATION \n";
		exit;
	}
	else
	{
		print "perl forms_execute.pl $DB_NAME $SRC_LOCATION $DEST_LOCATION $PASS_WORD \n" ;
		print "About to call get_forms_cmdline_var()";
		
		get_forms_cmdline_var(@ARGV);
		print "After calling get_forms_cmdline_var()";
		
		get_instance_details();
		print "After calling get_instance_details()";
		
		form_f60gen_execute();
		print "After calling form_f60gen_execute()";
		
              #print "With this command we are trying to clear confidential Information in log files..STARTs..########..\n";
              system("sh ../shellscripts/formatlogs.sh $OBJECT_TYPE $DB_USER_PASSWD  > myperl.log");
              #print "With this command we are trying to clear confidential Information in log files..ENDs..########...\n";
	        

		exit();	
	}
