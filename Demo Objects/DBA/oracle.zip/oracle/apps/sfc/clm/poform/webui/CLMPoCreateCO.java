/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package oracle.apps.sfc.clm.poform.webui;

import com.sun.java.util.collections.HashMap;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Hashtable;
import java.util.Vector;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.cp.request.ConcurrentRequest;
import oracle.apps.fnd.cp.request.RequestSubmissionException;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OADialogPage;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageChoiceBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.apps.fnd.framework.webui.beans.table.OATableBean;
import oracle.apps.sfc.clm.poform.server.CLMCreatePoAMImpl;
import oracle.apps.sfc.clm.poform.server.CLMHistoryNewRecordVORowImpl;
import oracle.apps.sfc.clm.poform.server.CLMPoLinesTabVORowImpl;
import oracle.apps.sfc.clm.poform.server.CLMViewLineHistoryVORowImpl;
import oracle.jdbc.OracleCallableStatement;

/**
 * Controller for ...
 */
public class CLMPoCreateCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");
        
    public String isSaveClicked     =   "N";
    public String pageMode          =   "";
    public String existingSurrDate  =   "";
    public String existingCommDate  =   "";
    public String oldCommDate       =   "";

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
        super.processRequest(pageContext, webBean);
        String  BackNavFrom =   pageContext.getParameter("BackNavFrom");        
        String  pMode       =   pageContext.getParameter("pMode");
//      String  cMode       =   pageContext.getParameter("circuitMode");
        String  ckSession   =   pageContext.getSessionValue("createSession")+"";
        
        System.out.println("ckSession "+ckSession);
        System.out.println("BackNavFrom "+BackNavFrom);
        System.out.println("pMode "+pMode);          
        //          if ("Sify Bandwidth Commercial".equalsIgnoreCase(RespName)) 
        //          {}        
        CLMCreatePoAMImpl   PoAM    =   (CLMCreatePoAMImpl)pageContext.getApplicationModule(webBean);
        if(BackNavFrom ==null )
        {        
            System.out.println("if back nav from is null Executed");
            // CLMCreatePoAMImpl PoAM = (CLMCreatePoAMImpl)pageContext.getApplicationModule(webBean);
            String Event        =   pageContext.getParameter(EVENT_PARAM);
            String BwReqId      =   pageContext.getParameter("BwReqId");
            String BwActivity   =   pageContext.getParameter("BwActivity");//activity
            String BwClmID      =   pageContext.getParameter("BwClmID");//not defined anywhere
            String LineID       =   pageContext.getParameter("LineID");//not defined anywhere
            /*view page*/
            String ClmHeaderId  =   pageContext.getParameter("ClmHeaderId");//poheaderId
            String ClmID        =   pageContext.getParameter("ClmId");//clmid
            String ClmActivity  =   pageContext.getParameter("ClmActivity");//poheaderId
            String ClmReqID     =   pageContext.getParameter("ClmReqID");//clmid
            System.out.println("ClmHeaderId"+ClmHeaderId);
            System.out.println("ClmID"+ClmID);
            System.out.println("ClmActivity"+ClmActivity);
            System.out.println("ClmReqID"+ClmReqID);
            System.out.println("BwReqId"+BwReqId);
            System.out.println("ClmHeaderId"+ClmHeaderId);
            System.out.println("BwActivity"+BwActivity);
            System.out.println("BwClmID"+BwClmID);
            System.out.println("Event="+Event);
            // String createSessionVal="";
            if(pageContext.getSessionValue("createSession") != null)
            {
                if (    (pageContext.getSessionValue("dialogPageSession") != null)      || 
                        (pageContext.getSessionValue("dialogPageSession1") != null)     ||
                        (pageContext.getSessionValue("dialogPageSession2") != null) ) 
                {        
                
                }
                else
                {
                    // createSessionVal=(String )pageContext.getSessionValue("createSession");
                    pageContext.removeSessionValue("createSession");
                }
            }
            pageMode=pageContext.getParameter("PageMode");
            System.out.println("pageMode="+pageMode);
            if (pageMode.equalsIgnoreCase("create"))
            {  // create mode 
                OATableBean viewTable=(OATableBean)webBean.findChildRecursive("CLMViewLineHistoryVO");  //fetching data from po lines  table
                viewTable.setRendered(false);
            }
            else
            { // edit mode        
                OATableBean CreateTable=(OATableBean)webBean.findChildRecursive("CLMHistoryNewRecordVO");   
                CreateTable.setRendered(false);
            }
            if ("VIEWREQ".equals(Event))                                  //REQUEST NO CREATE MODE 
            {
                //need to check new or upgrade       
                System.out.println("CREATE REQUEST");
                OATableBean viewTable=(OATableBean)webBean.findChildRecursive("CLMViewLineHistoryVO");  //fetching data from po lines  table
                viewTable.setRendered(false);                
                PoAM.CopyHeader(BwReqId,BwClmID,BwActivity);
                PoAM.CopyHistory(BwReqId,BwClmID,BwActivity);
                PoAM.CopyCommLines(BwReqId,BwClmID,BwActivity);
                OAMessageLovInputBean   lov1 =  (OAMessageLovInputBean)webBean.findChildRecursive("PoOrderType");
                lov1.setValue(pageContext,"CLM");
                OAMessageChoiceBean     mcb1 =  (OAMessageChoiceBean)webBean.findChildRecursive("PoClassification");
                mcb1.setValue(pageContext,"DOMESTIC");
                
                pageContext.putSessionValue("createSession","Y");     
                System.out.println("CREATE REQUEST PR is executed");
                OAViewObject vo1 = PoAM.getCLMBwAttachViewVO();
                vo1.setWhereClause(null);
                vo1.setWhereClauseParams(null);        
                vo1.setWhereClause("BAND_WIDH_REQ_ID=:1");
                vo1.setWhereClauseParam(0,BwReqId);
                vo1.executeQuery();
            }
            if ("VIEWDRAFT".equals(Event)) 
            {          ///VIEW LINK REQUESTs UPDATE MODE
                System.out.println("view REQUEST");      
                OATableBean CreateTable=(OATableBean)webBean.findChildRecursive("CLMHistoryNewRecordVO");
                CreateTable.setRendered(false);
                PoAM.ExecuteDraft(ClmHeaderId,ClmID);
                pageContext.putSessionValue("createSession","N");    
                OAViewObject vo1 = PoAM.getCLMBwAttachViewVO();
                vo1.setWhereClause(null);
                vo1.setWhereClauseParams(null);        
                vo1.setWhereClause("BAND_WIDH_REQ_ID=:1");
                vo1.setWhereClauseParam(0,ClmReqID);
                vo1.executeQuery();
            }
        String PRSession=pageContext.getSessionValue("createSession")+"";
        System.out.println("session in PR "+PRSession);   
        }//if Back Nav is null
        else if(    "AttachPage".equalsIgnoreCase(BackNavFrom)  || 
                    "CircuitPage".equalsIgnoreCase(BackNavFrom) ||
                    "CapacityPage".equalsIgnoreCase(BackNavFrom)
               )
        {
            if("CreateMode".equalsIgnoreCase(pMode))
            {
                OATableBean viewTable=(OATableBean)webBean.findChildRecursive("CLMViewLineHistoryVO");
                viewTable.setRendered(false);
            }
            else if("EditMode".equalsIgnoreCase(pMode))
            {
                OATableBean CreateTable=(OATableBean)webBean.findChildRecursive("CLMHistoryNewRecordVO");
                CreateTable.setRendered(false);
            }
        }//From AttachPage
        else
        {        
            System.out.println("INSIDE PR - NO CONDITION SATISFIED");        
        } 
        
        OAViewObject HdrVO = PoAM.getCLMPoHdrTabVO();        
        if (HdrVO.first().getAttribute("LinkStatus")!=null)
        {
            String  linkStatus  =   "";
                    linkStatus  =   HdrVO.first().getAttribute("LinkStatus").toString();
            OAViewObject vo     =   PoAM.getCLMApprovalSummaryVO();
            vo.setWhereClause(null);
            vo.setWhereClauseParams(null);
            
            if(linkStatus.equalsIgnoreCase("In Process")  || linkStatus.equalsIgnoreCase("Active") )
            {            
                vo.setWhereClause("WF_ITEM_KEY=:1");
                vo.setWhereClauseParam(0, (String)HdrVO.first().getAttribute("Attribute10"));
                vo.executeQuery();
            }
            else  if(linkStatus.equalsIgnoreCase("Approval In Process") || linkStatus.equalsIgnoreCase("Active") )
            {
                vo.setWhereClause("WF_ITEM_KEY=:1");
                vo.setWhereClauseParam(0, (String)HdrVO.first().getAttribute("Attribute8"));
                vo.executeQuery();
            }
            else
            {
                vo.setWhereClause("1=2"); 
                vo.executeQuery();
            }
        }  
    }//END PR
  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    String ClmHeaderId  =   pageContext.getParameter("ClmHeaderId");//poheaderId
    String ClmID        =   pageContext.getParameter("ClmId");//ClmID
    String ClmActivity  =   pageContext.getParameter("ClmActivity");//poheaderId
    String ClmReqID     =   pageContext.getParameter("ClmReqID");//ClmID
    System.out.println("START OF PFR********************************************");
    System.out.println("ClmID in view PFR "+ClmID);
    System.out.println("ClmActivity in view PFR "+ClmActivity);
    System.out.println("ClmReqID in view PFR "+ClmReqID);
    System.out.println("ClmHeaderId in PFR  "+ClmHeaderId);
    
    String PFRSession   =   pageContext.getSessionValue("createSession")+"";
    System.out.println("session in PFR "+PFRSession);
    
    CLMCreatePoAMImpl   PoAM    =   (CLMCreatePoAMImpl)pageContext.getApplicationModule(webBean);
    String              rowref  =   pageContext.getParameter(OAWebBeanConstants.EVENT_SOURCE_ROW_REFERENCE); 
    
    OAViewObject        HdrVO   =   PoAM.getCLMPoHdrTabVO();
    //OAViewObject      HVo     =   PoAM.getCLMHistoryVO();    
    //LOV validation for INR currency 
    if (pageContext.isLovEvent())
    {
        String lovInputSourceId = pageContext.getLovInputSourceId();
        System.out.println("lov clicked  "+lovInputSourceId);
        if("Currency".equals(lovInputSourceId))
        {
            OAMessageLovInputBean lovBean=(OAMessageLovInputBean)webBean.findIndexedChildRecursive(lovInputSourceId);
            if(lovBean != null)
            {
                String lovInput  =  (String) lovBean.getValue(pageContext);
                System.out.println("currency  val "+lovInput);
                if("INR".equalsIgnoreCase(lovInput))
                {
                    HdrVO.first().setAttribute("DisableConvRateType",Boolean.TRUE);        
                }
                else
                    HdrVO.first().setAttribute("DisableConvRateType",Boolean.FALSE);        
            }
        }
      }
      if("CreatePGAttachments".equals(pageContext.getParameter(EVENT_PARAM)))
      {
        String PO_BW_REQ_ID =   pageContext.getParameter("BW_REQ_ID");
        String PO_CLM_ID    =   pageContext.getParameter("BW_CLM_ID");
        String pMode        =   "CreateMode";      
        HashMap hm=new HashMap();
        hm.put("PO_BW_REQ_ID",PO_BW_REQ_ID);
        hm.put("PO_CLM_ID",PO_CLM_ID);
        hm.put("pMode",pMode);
        
        pageContext.forwardImmediately  (   "OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMPoViewAttachmentPG"   ,   
                                            null                                                                    , 
                                            OAWebBeanConstants.KEEP_MENU_CONTEXT                                    , 
                                            null                                                                    , 
                                            hm                                                                      , 
                                            true                                                                    , 
                                            OAWebBeanConstants.ADD_BREAD_CRUMB_NO
                                        );              
      }
      if("EditPGAttachments".equals(pageContext.getParameter(EVENT_PARAM)))
      {
        String  PO_HDR_ID       =   pageContext.getParameter("PO_HDR_ID");
        String  PO_BW_REQ_ID    =   pageContext.getParameter("PO_BW_REQ_ID");
        String  PO_CLM_ID       =   pageContext.getParameter("PO_CLM_ID");
        String  pMode           =   "EditMode";
        System.out.println("in edit atachment  mode"+PO_HDR_ID);
        System.out.println("in edit atachment  mode1"+PO_BW_REQ_ID);
        System.out.println("in edit atachment  mode2"+PO_CLM_ID);
        
        HashMap hm  =   new HashMap();
        
        hm.put("PO_HDR_ID"      ,   PO_HDR_ID);
        hm.put("PO_BW_REQ_ID"   ,   PO_BW_REQ_ID);
        hm.put("PO_CLM_ID"      ,   PO_CLM_ID);
        hm.put("pMode"          ,   pMode);
        
        pageContext.forwardImmediately  (   "OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMPoViewAttachmentPG"   , 
                                            null                                                                    , 
                                            OAWebBeanConstants.KEEP_MENU_CONTEXT                                    , 
                                            null                                                                    , 
                                            hm                                                                      , 
                                            true                                                                    , 
                                            OAWebBeanConstants.ADD_BREAD_CRUMB_NO
                                        );      
      }
      if("EditCheckCommissionDate".equals(pageContext.getParameter(EVENT_PARAM)))
      {
        System.out.println("Edit check comm date event");
        String  HistClmID   =   "";
        String  HistBwReqid =   "";
        String  cDate       =   "";
        String  act         =   "";
        int     clmPoHdrId  =   0;
        CLMViewLineHistoryVORowImpl rowi = (CLMViewLineHistoryVORowImpl)PoAM.findRowByRef(rowref); 
        try
        {
            HistBwReqid =   rowi.getBandWidthReqId()+"";
            if(rowi.getClmId()!=null)
            {
                HistClmID=rowi.getClmId()+"";     
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        if(HistClmID !=null)
        {
            System.out.println("CLM ID "+HistClmID);
            if (rowi.getCommissionedDate() != null) 
            {
                cDate           =   rowi.getCommissionedDate().toString();     
                act             =   rowi.getActivity();
                int lockPeriod  =   rowi.getLockingPeriod().intValue();
                clmPoHdrId      =   rowi.getClmPoHdrId().intValue();
                String lockuom  =   rowi.getLockingPeriodUom();
            
            /*    if(HdrVO.first().getAttribute("LinkStatus").toString().equals("Active")){  
            pageContext.putSessionValue("dialogPageSession2","Y");      
            // to check whether clm invoice created for this activity.
            if( PoAM.checkInvoiceCreated(clmPoHdrId)){
            HdrVO.first().setAttribute("DisableSaveButtonFlag", Boolean.TRUE);
            throw new OAException("You can not change Commission Date as Invoice Payment created for this activiy",OAException.ERROR); 
            }else{                 
            HdrVO.first().setAttribute("DisableSaveButtonFlag", Boolean.FALSE);
            ///   OAException message =
            //   new OAException("SFC", "XXSIFY_CLMPO_COMMDATE_CHANGE_MSG");
            OAException message = new OAException("If Commissioned Date is changed while the Link Status is Active it will go for Approvals.Do you want to proceed..?");
            OADialogPage dialogPage = new OADialogPage(OAException.WARNING, message, null,"","");
            dialogPage.setOkButtonItemName("Y2Btn");
            dialogPage.setNoButtonItemName("N2Btn");
            dialogPage.setOkButtonToPost(true);
            dialogPage.setNoButtonToPost(true);
            dialogPage.setOkButtonLabel("Yes");
            dialogPage.setNoButtonLabel("No");
            dialogPage.setPostToCallingPage(true);
            Hashtable formParams = new Hashtable();
            formParams.put("REQID", HistBwReqid);
            formParams.put("ClmID", HistClmID);
            formParams.put("ACTIVITY", act);
            formParams.put("clmPoHdrId", clmPoHdrId);
            formParams.put("rowref", rowref);   
            dialogPage.setFormParameters(formParams);
            pageContext.redirectToDialogPage(dialogPage);                      
            
            }
            } */
            
                if(PoAM.CheckCommDatePriorToPoCreationDate(HistBwReqid,HistClmID,cDate))
                {      //  If comm date is prior to po creation date then it should go for approvals.                
                    pageContext.putSessionValue("dialogPageSession1","Y");                       
                    
                    ///   OAException message = 
                    //   new OAException("SFC", "XXSIFY_CLMPO_COMMDATE_CHANGE_MSG");
                    OAException message = new OAException("If Commissioned Date is prior to Purchase Order Creation Date it will go for Approvals.Do you want to proceed..?");
                    OADialogPage dialogPage = new OADialogPage(OAException.WARNING, message, null,"","");
                    dialogPage.setOkButtonItemName("Y1Btn");
                    dialogPage.setNoButtonItemName("N1Btn");
                    dialogPage.setOkButtonToPost(true);
                    dialogPage.setNoButtonToPost(true);
                    dialogPage.setOkButtonLabel("Yes");
                    dialogPage.setNoButtonLabel("No");
                    
                    dialogPage.setPostToCallingPage(true);
                    Hashtable formParams = new Hashtable();
                    
                    formParams.put("REQID", HistBwReqid);
                    formParams.put("ClmId", HistClmID);
                    formParams.put("ACTIVITY", act);
                    formParams.put("clmPoHdrId", clmPoHdrId);
                    formParams.put("rowref", rowref);   
                    dialogPage.setFormParameters(formParams);
                    pageContext.redirectToDialogPage(dialogPage);    
                }        
                else if (!rowi.getActivity().equals("Shifting"))
                {
                    // before entering comm date  po number should be created and approved then only we can enter comm date.
                    //comm date should not be future date
                    if(!PoAM.isCommDateValid(clmPoHdrId,HistClmID,cDate))
                    {                  
                        rowi.setCommissionedDate(null);
                        rowi.setPoEndDate(null);                
                        throw new OAException("Commissioned Date should not be Future Date or PO Not Approved ",OAException.ERROR);                
                    }
                    else
                    {
                        if(HdrVO.first().getAttribute("LinkStatus").toString().equals("Active"))
                        {                  
                            if( PoAM.checkInvoiceCreated(clmPoHdrId))
                            {
                                HdrVO.first().setAttribute("DisableSaveButtonFlag", Boolean.TRUE);
                                throw new OAException("You can not change Commission Date as Invoice Payment created for this activiy",OAException.ERROR);                        
                            }                   
                        }
                        String ValidStatus=PoAM.ViewModeUpdateSurrenderDate(HistBwReqid,HistClmID,cDate,clmPoHdrId,lockPeriod,lockuom);  
                        // will updates sureender date for the previous activity and updates po end date for the current activity
                        if(!"VALID".equalsIgnoreCase(ValidStatus))
                        {
                            rowi.setCommissionedDate(null);
                            rowi.setPoEndDate(null);
                            throw new OAException("Error While updating po end date=>"+ValidStatus,OAException.ERROR);
                        }                    
                    }
                }
                else
                {     // for Shifting activity
                    // code for shifting activity to check whether PO is created and Approved or not
                    if(!PoAM.isCommDateValid(clmPoHdrId,HistClmID,cDate))
                    {  
                        rowi.setCommissionedDate(null);
                        rowi.setPoEndDate(null);                
                        throw new OAException("Commissioned Date should not be Future Date or PO Not Approved",OAException.ERROR);                
                    }
                    else
                    {                
                        String flag=(String)PoAM.updateSurrenderDateForShifting(clmPoHdrId,HistClmID,cDate,lockPeriod,lockuom);
                        if(!"Y".equalsIgnoreCase(flag))
                        {
                            throw new OAException("Error While updating surrendered date for previous activity for Shifting ",OAException.ERROR);
                        }                   
                    }                
                } // end of IF              
            }  // comm date not null
        }  //hist clm id not null
        } // end of event                            
        /*   
        System.out.println("reqid"+HistBwReqid);
        System.out.println("HistClmID"+HistClmID);
        System.out.println("cDate"+cDate);
        // phase 2 code by chiranjeevi
        if(HdrVO.first().getAttribute("LinkStatus").toString().equals("Active")){  
        // means if super user changes commissioned date while the link is Active it has to go for one level of approval.
        OADBTransaction txn = PoAM.getOADBTransaction(); 
        String sql = "BEGIN xxsify_clm_po_wf_pkg.start_comm_date_change_wf(:1,:2,:3); END;";                                     
        try
        {
            OracleCallableStatement cs = (OracleCallableStatement)txn.createCallableStatement(sql, 1);                     
            cs.setString(1,HistBwReqid);
            cs.setString(2,HistClmID);
            cs.setString(3,pageContext.getUserName());                            
            cs.execute();
            cs.close();
        }
        catch (Exception ex) 
        {
            throw new OAException("Error while calling Procedure "+ex.getMessage());
        }  
        }*/      
        if (pageContext.getParameter("Y1Btn") != null)
        {
            pageContext.removeSessionValue("dialogPageSession1");
            System.out.println("in yes btn ");
            String  reqid       =   pageContext.getParameter("REQID");
            String  ClmId       =   pageContext.getParameter("ClmId");
            String  activity    =   pageContext.getParameter("ACTIVITY");
            int     poHdrId     =   Integer.parseInt(pageContext.getParameter("clmPoHdrId"));
            //update commission date,po end date at lines level
            PoAM.updateClmPOLinesDates();
            //update link status to Inprocess
            //  PoAM.UpdateLinkStatus(reqid,ClmID);
            // call WF for approvals      
            OADBTransaction txn = PoAM.getOADBTransaction(); 
            String          sql = "BEGIN XXSIFY_CLM_COMMDATE_APP_WOF.WORKFLOW_LAUNCH(:1,:2,:3,:4); END;";                                     
            try
            {
                OracleCallableStatement cs = (OracleCallableStatement)txn.createCallableStatement(sql, 1);                     
                //   cs.setString(1,reqid);
                cs.setString(1,ClmID);
                cs.setString(2,pageContext.getUserName());       
                cs.setString(3,activity);
                cs.setInt(4,poHdrId);
                cs.execute();
                cs.close();
            }
            catch (Exception ex) 
            {
                throw new OAException("Error while calling Procedure XXSIFY_CLM_COMMDATE_APP_WOF.WORKFLOW_LAUNCH "+ex.getMessage());
            }  
            pageContext.forwardImmediately  (   
                                                "OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMPoMainViewPG" ,
                                                null                                                            ,
                                                OAWebBeanConstants.KEEP_MENU_CONTEXT                            ,
                                                null                                                            ,
                                                null                                                            ,
                                                false                                                           , // retain AM
                                                OAWebBeanConstants.ADD_BREAD_CRUMB_NO
                                            );
       }
       /////////////////////////////////Mahesh
        if (pageContext.getParameter("Colo") != null)
        {
           pageContext.setForwardURL  ( "OA.jsp?page=/oracle/apps/sfc/xxcustom/xxsifyfmscoloratecard/webui/XXSifyFMSColoRateCardPG", 
                                        null                                  , 
                                        OAWebBeanConstants.KEEP_MENU_CONTEXT  , 
                                        null                                  , 
                                        null                                  , 
                                        true                                  , 
                                        OAWebBeanConstants.ADD_BREAD_CRUMB_YES, 
                                        OAWebBeanConstants.IGNORE_MESSAGES
                                      ); 
        }
       /////////////////////////////////Mahesh
        if (pageContext.getParameter("N1Btn") != null)
        {
            // OAMessageDateFieldBean  cd = (OAMessageDateFieldBean )webBean.findIndexedChildRecursive("CommissionedDate");
            //  cd.setValue(pageContext,"");
            System.out.println("in no btn ");
            String rowref2= pageContext.getParameter("rowref");
            CLMViewLineHistoryVORowImpl rowi = (CLMViewLineHistoryVORowImpl)PoAM.findRowByRef(rowref2); 
            rowi.setCommissionedDate(null);
            rowi.setPoEndDate(null);
        }
        /* 
        if (pageContext.getParameter("Y2Btn") != null)
        {
            pageContext.removeSessionValue("dialogPageSession2");
            System.out.println("in yes2 btn ");
            String  reqid       = pageContext.getParameter("REQID");
            String  ClmID       = pageContext.getParameter("ClmId");
            String  activity    = pageContext.getParameter("ACTIVITY");
            int     poHdrId     = Integer.parseInt(pageContext.getParameter("clmPoHdrId"));
            //store old commission date in attribute1 column at lines table
            oldCommDate =(String)PoAM.updateOldCommDate(poHdrId);
            System.out.println("old comm date="+oldCommDate);
            //update commission date,po end date at lines level 
            PoAM.updateClmPOLinesDates();
            //update link status to Inprocess
            // PoAM.UpdateLinkStatus(reqid,ClmId);
            
            // call WF for approvals      
            OADBTransaction txn = PoAM.getOADBTransaction();             
            String sql = "BEGIN XXSIFY_CLM_COMDT_APP_WOF.workflow_launch(:1,:2,:3,:4); END;";            
            try
            {
                OracleCallableStatement cs = (OracleCallableStatement)txn.createCallableStatement(sql, 1);                     
                // cs.setString(1,reqid);
                cs.setString(1,ClmId);
                cs.setString(2,pageContext.getUserName());       
                cs.setString(3,activity);
                cs.setInt(4,poHdrId);
                cs.execute();
                cs.close();
            }
            catch (Exception ex) 
            {
                //   throw new OAException("Error while calling Procedure XXSIFY_CLM_COMDT_APP_WOF.workflow_launch "+ex.printStackTrace());
                ex.printStackTrace();
            }  
            pageContext.forwardImmediately("OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMPoMainViewPG",
                                            null,
                                            OAWebBeanConstants.KEEP_MENU_CONTEXT,
                                            null,
                                            null,
                                            false, // retain AM
                                            OAWebBeanConstants.ADD_BREAD_CRUMB_NO);
        }
        if (pageContext.getParameter("N2Btn") != null)
        {
            String rowref1 = pageContext.getParameter("rowref");
            //   pageContext.putSessionValue("OldCommDate",existingCommDate);
            if(pageContext.getSessionValue("OldCommDate")!=null){
            //    System.out.println("n2 btn="+pageContext.getSessionValue("OldCommDate"));
            
            //  String oldCommDate=pageContext.getSessionValue("OldCommDate").toString();
            //  System.out.println("existingCommDate="+oldCommDate);
            CLMLineHistoryVORowImpl rowi = (CLMViewLineHistoryVORowImpl)PoAM.findRowByRef(rowref1); 
            System.out.println("rowi="+rowi);
            if(rowi != null){
            //  rowi.setCommissionedDate(castToJboDate(pageContext,oldCommDate));
            rowi.setCommissionedDate((oracle.jbo.domain.Date)pageContext.getSessionValue("OldCommDate"));
            }
            }
            System.out.println("in no btn ");
        }  */
/*      if("CheckCommissionDate".equals(pageContext.getParameter(EVENT_PARAM)))
        {
            String HistClmID="";
            String HistBwReqid="";
            String cDate="";
            CLMHistoryNewRecordVORowImpl rowi = (CLMHistoryNewRecordVORowImpl)PoAM.findRowByRef(rowref); 
            try
            {
                HistBwReqid=rowi.getBandWidhReqId()+"";
                if(rowi.getClmID()!=null)
                {
                    HistClmID=rowi.getClmID()+"";     
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            if(HistClmID !=null)
            {
                System.out.println("CLM ID "+HistClmID);
            
                if (rowi.getCommissionedDate() != null) 
                {
                    cDate=rowi.getCommissionedDate().toString();        
                    String ValidStatus=(String)PoAM.UpdateSurrenderDate(HistBwReqid,HistClmID,cDate);
                    System.out.println("commission date validation done"+ValidStatus);
                
                    if(!"VALID".equalsIgnoreCase(ValidStatus))
                    {
                        //System.out.println("commission date validation done");
                        rowi.setCommissionedDate(null);
                        rowi.setPoEndDate(null);
                        throw new OAException("Commissioned Date is not valid / Future Date  ",OAException.ERROR);
                    }                    
                    //else{
                    //  rowi.setCommissionedDate(null);
                    //  rowi.setPoEndDate(null);
                
                    //   throw new OAException("Commissioned Date is not valid / Future Date  ",OAException.ERROR);
                    //      }
            
                    // added by chiranjeevi to check commissioned date is prior to po creation date or not.
                    //If commissioned date is prior to po creation date call workflow for approvals.
                    
                    String flag=(String)PoAM.CheckCommDatePriorToPoCreationDate(HistBwReqid,HistClmID,cDate);
            
                    if ("Y".equals(flag))
                    {
                        OAException message = new OAException("If Commissioned Date is prior to Purchase Order Creation Date it will go for Approvals.Do you want to proceed..?");
                        OADialogPage dialogPage = new OADialogPage(OAException.CONFIRMATION, message, null,"","");
                        dialogPage.setOkButtonItemName("YBtn");
                        dialogPage.setNoButtonItemName("NBtn");
                        dialogPage.setOkButtonToPost(true);
                        dialogPage.setNoButtonToPost(true);
                        dialogPage.setOkButtonLabel("Yes");
                        dialogPage.setNoButtonLabel("No");
                        dialogPage.setPostToCallingPage(true);            
                        pageContext.redirectToDialogPage(dialogPage);             
                    }          
                 }                          
            }
        }*/
       /* if (pageContext.getParameter("YBtn") != null)
        * {
            // pageContext.removeSessionValue("dialogPageSession");
            System.out.println("in yes btn ");
            
            // call WF for 2 level of approvals
            pageContext.forwardImmediately("OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMPoMainViewPG",
            null,
            OAWebBeanConstants.KEEP_MENU_CONTEXT,
            null,
            null,
            false, // retain AM
            OAWebBeanConstants.ADD_BREAD_CRUMB_NO);
          }*/
    /*   if (pageContext.getParameter("NBtn") != null)
     *  {
     
        }*/      
        if ("checkSurrenderDate".equals(pageContext.getParameter(EVENT_PARAM)))
        {
            CLMViewLineHistoryVORowImpl rowi = (CLMViewLineHistoryVORowImpl)PoAM.findRowByRef(rowref);     
            if(rowi.getSurrenderedDate()!=null){
            String currSurrDateS=rowi.getSurrenderedDate().toString();        
            try 
            {
                SimpleDateFormat    formatter   = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat    finalFormat = new SimpleDateFormat("dd-MM-yyyy");  
                java.util.Date      esd         = formatter.parse(existingSurrDate);
                String              strDate     = finalFormat.format(esd);
                esd.setTime(esd.getTime()+ 30L * 1000 * 60 * 60 * 24);
                java.util.Date      csd         = formatter.parse(currSurrDateS);
                //  if ( (csd.compareTo(esd) < 0) || (csd.compareTo(esd) == 0)) {
                //    System.out.println("current surrendered date is before existing surrendered date + 30 days");                                   
                //  }         
                if (csd.compareTo(esd) > 0)
                {
                    HdrVO.first().setAttribute("DisableSaveButtonFlag", Boolean.TRUE);
                    throw new OAException("You can not modify Surrendered Date more than 30 days of the existing Surrendered Date i.e "+strDate,OAException.ERROR);
                }
                else
                {
                    HdrVO.first().setAttribute("DisableSaveButtonFlag", Boolean.FALSE);                                
                }                                
           }//try blcok
           catch (ParseException e) 
           {
               System.out.println(" Parsing : "+e.getMessage());
               e.printStackTrace();
           } 
          }
    }
    if ("UpdateHdrStatus".equals(pageContext.getParameter(EVENT_PARAM)))
    {
        String pMode=pageContext.getParameter("pMode");
        OAViewObject HVo1 =(OAViewObject)PoAM.findViewObject("CLMHistoryNewRecordVO");
        for (int i = 0; i < HVo1.getFetchedRowCount(); i++) 
        {
            String sd=pageContext.getParameter("SurrenderedDate");
            CLMHistoryNewRecordVORowImpl rowi = 
            (CLMHistoryNewRecordVORowImpl)HVo1.getRowAtRangeIndex(i);
            if (rowi != null) 
            {
                if (rowi.getSurrenderedDate()!=null)
                {
                }
                else
                {
                    System.out.println("in sod event create mode=>"+sd);
                    rowi.setSurrenderedDate(castToJBODate(pageContext,sd));
                }      
            }
        }    
    }
    if ("ShowHistoryLines".equals(pageContext.getParameter(EVENT_PARAM)))  //create mode
    {
        System.out.println("show history lines ");
        CLMHistoryNewRecordVORowImpl rowi = (CLMHistoryNewRecordVORowImpl)PoAM.findRowByRef(rowref);     
        String HistBwReqid=rowi.getBandWidhReqId()+"";  
        PoAM.ExecuteLinesVO(HistBwReqid);
        // System.out.println("HistBwReq id"+HistBwReqid);          
    }
    if ("showItems".equals(pageContext.getParameter(EVENT_PARAM)))
    {     
        OAViewObject LVo = PoAM.getCLMPoLinesTabVO();
        CLMPoLinesTabVORowImpl rowi = (CLMPoLinesTabVORowImpl)PoAM.findRowByRef(rowref); 
        String LineId=rowi.getClmPoLineId()+"";            
        PoAM.ExecuteItems(LineId);
        //  System.out.println("line id"+LineId);          
    }
    if ("ViewLines".equals(pageContext.getParameter(EVENT_PARAM)))        //update mode
    {
        // System.out.println("view  lines ");
        CLMViewLineHistoryVORowImpl rowi = (CLMViewLineHistoryVORowImpl)PoAM.findRowByRef(rowref); 
        //  System.out.println("rowref"+rowref);
        //  System.out.println("rowi"+rowi);
        String HistPoHdrId=rowi.getClmPoHdrId()+"";
        //  System.out.println("HistPoHdrId in PR :"+HistPoHdrId);
        PoAM.ExecuteViewLinesVO(HistPoHdrId);
        // added by Chiranjeevi to enable surrender date column  for commercial super user only.
        String superUserComm=pageContext.getProfile("XXSIFY_CLM_SUPER_USER_COMM");
        // superUserComm="osicomm";
        if(pageContext.getUserName().equalsIgnoreCase(superUserComm))
        {             
            rowi.setLineDisableSurDate(false);
            rowi.setLineDisableCommDate(false);
            if(rowi.getSurrenderedDate()!=null)
            {
                existingSurrDate=rowi.getSurrenderedDate().toString();             
            }
            if(rowi.getCommissionedDate()!=null)
            {            
                existingCommDate=rowi.getCommissionedDate().toString();
                //  pageContext.putSessionValue("OldCommDate",existingCommDate);
                //  System.out.println("comdate1"+rowi.getCommissionedDate());
                //  System.out.println("comdate2"+rowi.getCommissionedDate().toString());
                pageContext.putSessionValue("OldCommDate",rowi.getCommissionedDate());
            }
            // PoAM.enableSurrDateForSuperUser(currBwReqid,currClmID,cds);
        }
        /*else
        {
            rowi.setLineDisableSurDate(true);
            rowi.setLineDisableCommDate(true);
        }*/
        /*if(pageContext.getUserName().equals(superUserComm))
        {
            String currClmID="";
            String currBwReqid="";
            try
            {
                currBwReqid= rowi.getBandWidthReqId()+"";
                if(rowi.getClmID()!=null)
                {
                    currClmID=rowi.getClmID()+"";     
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }        
            if(currClmID !=null)
            {        
                if (rowi.getCommissionedDate() != null) 
                {
                    DateFormat formatter;
                    String cds=rowi.getCommissionedDate().toString();  
                    try 
                    {
                        formatter = new SimpleDateFormat("yyyy-MM-dd");
                        System.out.println("cd in string :"+cds);
                        java.util.Date cdd = formatter.parse(cds);
                        cdd.setTime(cdd.getTime()+ 30L * 1000 * 60 * 60 * 24);
                        oracle.jbo.domain.Date currDate = PoAM.getOADBTransaction().getCurrentDBDate();
                        java.util.Date sysDate = formatter.parse(currDate.toString());
                        if ( (sysDate.compareTo(cdd) < 0) || (sysDate.compareTo(cdd) == 0)) 
                        {
                            //    System.out.println("sysDate is before commissioned date+30");
                            //enable surrendered date column 
                            PoAM.enableSurrenderedDate(currBwReqid,currClmID,cds);
                        }                                         
                    }//try blcok
                    catch (ParseException e) 
                    {
                        System.out.println(" Parsing : "+e.getMessage());
                        e.printStackTrace();
                    }             
                }      // end commissioned date not null    
            }   // end clm id not null
        }  */ // end if user checks event
    }//end of if event
    if(pageContext.getParameter("SubmitBtn")!=null) 
    {
        if (isSaveClicked.equalsIgnoreCase("N"))
        {
            throw new OAException("Please Save before Submit",OAException.ERROR);
        }
        else
        {
            int     ln_request_id   =   0;
            String  rId             =   "";
            String  BwReqId         =   HdrVO.first().getAttribute("BandWidthReqId")+"";
            try
            {
                OADBTransaction trx = (OADBTransaction)PoAM.getDBTransaction();
                java.sql.Connection conn = trx.getJdbcConnection();
                ConcurrentRequest cr = new ConcurrentRequest(conn);
                String cpApplName = "SFC";
                String cpPrgName  = "XXSIFY_CLM_POCREATEPROG";
                String cpPrgDesc  = null;
                Vector cpArgs     = new Vector();
                cpArgs.addElement(BwReqId);
                //   System.out.println("fileName - " +fileName);
                ln_request_id = cr.submitRequest(cpApplName, cpPrgName, cpPrgDesc, null, false, cpArgs);
                trx.commit();
                System.out.println("requestId is - " +ln_request_id);
                rId = ln_request_id+"";
                //                throw new OAException("Submitted to Concurrent Program with Request ID : "+ln_request_id,OAException.CONFIRMATION);
                String clmMess="Submitted to Concurrent Program with Request ID : "+ln_request_id ;
                HashMap hm=new HashMap();
                hm.put("clmMess",clmMess);
                hm.put("BwReqId",BwReqId);
                hm.put("rId",rId);
                pageContext.forwardImmediately("OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMPoMainViewPG",
                                                null                                    ,
                                                OAWebBeanConstants.KEEP_MENU_CONTEXT    ,
                                                null                                    ,
                                                hm                                      ,
                                                false                                   , // retain AM
                                                OAWebBeanConstants.ADD_BREAD_CRUMB_NO
                                              );
            } // Try
            catch(RequestSubmissionException ex)
            {
                OAException exc = new OAException(ex.getMessage());
                throw exc;
            } // ExpCOAValidProc
        }
    }//end of submit        
    if(pageContext.getParameter("SaveBtn")!=null) 
    {
//      String ClmID="";
        String BwReqId="";        
        String sessionVal   =   pageContext.getSessionValue("createSession")+"";
        BwReqId             =   HdrVO.first().getAttribute("BandWidthReqId")+"";
        String HeaderID     =   HdrVO.first().getAttribute("ClmPoHdrId")+"";
        PoAM.SaveValidation(sessionVal); //session used to identify create mode or update mode
        
        if(HdrVO.first().getAttribute("ClmId")!=null)
        {
            ClmID = HdrVO.first().getAttribute("ClmId")+"";
            HdrVO.first().setAttribute("ClmId",ClmID);        
        }        
        else
        {
          ClmID= PoAM.getOADBTransaction().getSequenceValue("XXSIFY_CLM_ID_SEQ")+"";
          HdrVO.first().setAttribute("ClmId",ClmID);      
        }  
    //    System.out.println("ClmID"+ClmID);
    //    System.out.println("BwReqId"+BwReqId);    
        PoAM.UpdateClmPoLines(ClmID,BwReqId);                                   //update line tables with clm id /bwreqid
        try 
        {            
            PoAM.UpdateBwRequest(BwReqId,ClmID);                                //bw tables with clm id/bwreq id
        }
        catch (Exception ex) 
        {
            ex.printStackTrace();
        }
        if("N".equals(pageContext.getSessionValue("createSession")))
        {                     
            PoAM.ViewUpdateHistoryToLines(BwReqId,ClmID);                       //edit mode history data to clm po lines table
//          PoAM.EditPgSurrenderedDateval(BwReqId,ClmID);                                        
        }
        if("Y".equals(pageContext.getSessionValue("createSession")))
        {                                                                             
            PoAM.UpdateHistoryToLines(BwReqId,ClmID);                           //new history data to clm po lines table
    //      PoAM.SurrenderedDatevalidation(BwReqId,ClmID);        
        }                            
        PoAM.UpdateBwRequestData(sessionVal);                                   //both  mode vos to update bw tables (cancel,comm date,surr date,po end date)
       //  System.out.println("update done for BW tables");
        PoAM.save(HeaderID);        
        isSaveClicked="Y";          
        String message = "Record has been Saved Successfully";
        throw new OAException(message, (byte)3);        
      }
      if(pageContext.getParameter("HomeBtn")!=null) 
      {      
        if (isSaveClicked.equalsIgnoreCase("N"))
        {
          pageContext.putSessionValue("dialogPageSession","Y");    
          OAException message = new OAException("Do you want to quit with out saving the page ?");
          OADialogPage dialogPage = new OADialogPage(OAException.CONFIRMATION, message, null,"","");
          dialogPage.setOkButtonItemName("YesBtn");
          dialogPage.setNoButtonItemName("NoBtn");
          dialogPage.setOkButtonToPost(true);
          dialogPage.setNoButtonToPost(true);
          dialogPage.setOkButtonLabel("Yes");
          dialogPage.setNoButtonLabel("No");
          dialogPage.setPostToCallingPage(true);
          pageContext.redirectToDialogPage(dialogPage);
        }     
        else
        {
          System.out.println("in yes btn1 ");
          pageContext.forwardImmediately("OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMPoMainViewPG",
                                          null                                  ,
                                          OAWebBeanConstants.KEEP_MENU_CONTEXT  ,
                                          null                                  , 
                                          null                                  ,
                                          false                                 , // retain AM
                                          OAWebBeanConstants.ADD_BREAD_CRUMB_NO);
        }
    }
    if (pageContext.getParameter("YesBtn") != null)
    {
          pageContext.removeSessionValue("dialogPageSession");
          System.out.println("in yes btn ");
          pageContext.forwardImmediately("OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMPoMainViewPG",
                                          null,
                                          OAWebBeanConstants.KEEP_MENU_CONTEXT,
                                          null,
                                          null,
                                          false, // retain AM
                                          OAWebBeanConstants.ADD_BREAD_CRUMB_NO);      
    }
    if (pageContext.getParameter("NoBtn") != null)
    {
         //null
         System.out.println("in no btn ");
         pageContext.removeSessionValue("dialogPageSession");
    }
     /* if ("VIEWITEM".equals(EVENT_PARAM)) 
      {
          OAViewObject vo=(OAViewObject)PoAM.findViewObject("CLMPoLinesTabVO"); 
          OARow row=(OARow)vo.getCurrentRow();
          Number LineId=(Number)row.getAttribute("ClmPoLineId");
          Number HdrId=(Number)row.getAttribute("clmPoHdrId");
          OAViewObject ItemVO = PoAM.getCLMPoLineItemsTabVO();
          ItemVO.setWhereClause(null);
          ItemVO.setWhereClauseParams(null);
          ItemVO.setWhereClause("CLM_PO_HDR_ID=:1 and CLM_PO_LINE_ID=:2");
          ItemVO.setWhereClauseParam(0, HdrId);
          ItemVO.setWhereClauseParam(0, HdrId);
      }*/
      /*if("CreateCircuit".equals(pageContext.getParameter(EVENT_PARAM)))
       {
            String PO_BW_REQ_ID=pageContext.getParameter("BW_REQ_ID");
            String PO_CLM_ID=pageContext.getParameter("BW_CLM_ID");
            HashMap hm=new HashMap();
            hm.put("PO_BW_REQ_ID",PO_BW_REQ_ID);
            hm.put("PO_CLM_ID",PO_CLM_ID);
            hm.put("circuitMode","CreateCircuitMode");
            pageContext.forwardImmediately("OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMCreateCircuitPG", 
                                            null, 
                                            OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                            null, hm, true, 
                                            OAWebBeanConstants.ADD_BREAD_CRUMB_NO);
       }*/
       if("CapacityUtilization".equals(pageContext.getParameter(EVENT_PARAM)))
       {
            String PO_HDR_ID=pageContext.getParameter("PO_HDR_ID");
            String PO_CLM_ID=pageContext.getParameter("PO_CLM_ID");
            HashMap hm=new HashMap();
            hm.put("PO_HDR_ID",PO_HDR_ID);
            hm.put("PO_CLM_ID",PO_CLM_ID);
            //  hm.put("pMode","EditMode");
            pageContext.forwardImmediately("OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMCapacityUtilPG", 
                                            null                                    , 
                                            OAWebBeanConstants.KEEP_MENU_CONTEXT    ,    
                                            null                                    , 
                                            hm                                      , 
                                            true                                    , 
                                            OAWebBeanConstants.ADD_BREAD_CRUMB_NO);
    }      
    if("CreateCircuit".equals(pageContext.getParameter(EVENT_PARAM)))
    {      
        String      PO_HDR_ID   =   pageContext.getParameter("PO_HDR_ID");
        String      PO_CLM_ID   =   pageContext.getParameter("PO_CLM_ID");
        HashMap     hm          =   new HashMap();
        hm.put("PO_HDR_ID",PO_HDR_ID);
        hm.put("PO_CLM_ID",PO_CLM_ID);
        //   hm.put("circuitMode","EditMode");
        //    hm.put("pMode","EditMode");        
        pageContext.forwardImmediately  (   "OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMCreateCircuitPG", 
                                            null                                , 
                                            OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                            null                                ,
                                            hm                                  , 
                                            true                                , 
                                            OAWebBeanConstants.ADD_BREAD_CRUMB_NO
                                        );
        }              
    }
    public oracle.jbo.domain.Date castToJBODate(OAPageContext pageContext,String aDate) 
    {
        DateFormat formatter;
        java.util.Date date;
        if (!aDate.isEmpty()) 
        {
        //System.out.println("is not empty");
            try 
            {
                System.out.println("try block="+aDate);
                formatter = new SimpleDateFormat("dd-MMM-yyyy");
                date = formatter.parse(aDate);
                java.sql.Date sqlDate = new java.sql.Date(date.getTime());
                oracle.jbo.domain.Date jboDate = 
                new oracle.jbo.domain.Date(sqlDate);
                //System.out.println("sql date "+sqlDate);
                return jboDate;
            } 
            catch (Exception e) 
            {
                System.out.println("catch ex date"+e.getMessage());
            }
        }
        return null;
    }
    public oracle.jbo.domain.Date castToJboDate(OAPageContext pageContext,String aDate) 
    {
        DateFormat formatter;
        java.util.Date date;
        
        if (!aDate.isEmpty()) 
        {
            //System.out.println("is not empty");
            try 
            {
                System.out.println("try block="+aDate);
                formatter = new SimpleDateFormat("yyyy-MM-dd");
                date = formatter.parse(aDate);
                java.sql.Date sqlDate = new java.sql.Date(date.getTime());
                oracle.jbo.domain.Date jboDate = 
                new oracle.jbo.domain.Date(sqlDate);
                System.out.println("jbo date"+jboDate);            
                return jboDate;
            } 
            catch (Exception e) 
            {
                System.out.println("catch ex date"+e.getMessage());
            }
        }
        return null;
        }
     }
