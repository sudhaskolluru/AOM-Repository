/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package oracle.apps.sfc.clm.poform.webui;

import com.sun.java.util.collections.HashMap;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.sfc.clm.poform.server.CLMCreatePoAMImpl;
import oracle.apps.sfc.clm.poform.server.CLMPoAttachmentsTabVOImpl;

import oracle.cabo.ui.data.DataObject;
import oracle.jbo.Row;
import oracle.jbo.domain.BlobDomain;


/**
 * Controller for ...
 */
public class CLMPoAddAttachmentCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
    CLMCreatePoAMImpl PoAM =  (CLMCreatePoAMImpl)pageContext.getApplicationModule(webBean);
    
    String aMode        =   pageContext.getParameter("aMode");
    String attachID     =   pageContext.getParameter("AttachID");
    String PO_HDR_ID    =   pageContext.getParameter("PO_HDR_ID");
    
    String pMode        = pageContext.getParameter("pModeVal");
    String poBwreqID    = pageContext.getParameter("poBwreqID");      
    
    System.out.println("aMode "+aMode);
    System.out.println("poBwreqID"+poBwreqID);
    System.out.println("attachID  "+attachID);
    System.out.println("PO_HDR_ID "+PO_HDR_ID);    
    pageContext.putSessionValue("DocBwReqIDSessionVal",poBwreqID);
    pageContext.putSessionValue("DocpModeSessionVal",pMode);

    if("UpdateAttachments".equalsIgnoreCase(aMode))
    {
        OAViewObject vo = PoAM.getCLMPoAttachmentsTabVO();
        vo.setWhereClause(null);
        vo.setWhereClauseParams(null);
        vo.setWhereClause("OAF_ATTACH_ID=:1");
        vo.setWhereClauseParam(0,attachID);
        vo.executeQuery();
    }
    else
    {   
        System.out.println("in po attach add pg"+PO_HDR_ID+"="+poBwreqID);
        PoAM.createAttach(pMode,poBwreqID,PO_HDR_ID);           
    }
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    CLMCreatePoAMImpl PoAM =  (CLMCreatePoAMImpl)pageContext.getApplicationModule(webBean);
    String Event = pageContext.getParameter(EVENT_PARAM);
    
    if ("BACKATTACH".equalsIgnoreCase(Event)) 
    {  
        String DocpoBwreqID =   pageContext.getSessionValue("DocBwReqIDSessionVal")+"";
        String pMode        =   pageContext.getSessionValue("DocpModeSessionVal")+"";
        
        HashMap     h   =   new HashMap();
        h.put("PO_BW_REQ_ID",DocpoBwreqID);        
        h.put("pMode",pMode);
        
        pageContext.forwardImmediately  (   
                                            "OA.jsp?page=/oracle/apps/sfc/clm/poform/webui/CLMPoViewAttachmentPG", 
                                            null, (byte)0, null, h, true, 
                                            "N"
                                        );
    }
    if("UPLOAD".equals(Event))  
    {
        System.out.println("Inside Upload");
        
        String Category =   pageContext.getParameter("UploadCategory");
        String Desc     =   pageContext.getParameter("FileDesc");
        System.out.println("Category desc"+Category+" "+Desc);
        
        OADBTransaction dbtransaction = PoAM.getOADBTransaction();
        
        DataObject fileUploadData = pageContext.getNamedDataObject("uploadFile");
        try 
        {
            if (fileUploadData != null) 
            {
                String fileName     = (String)fileUploadData.selectValue(null, "UPLOAD_FILE_NAME");
                String contentType  = (String)fileUploadData.selectValue(null, "UPLOAD_FILE_MIME_TYPE");
                System.out.println("file name" + fileName);
                System.out.println("contentType name" + contentType);
                BlobDomain                  uploadedByteStream  = (BlobDomain)fileUploadData.selectValue(null, fileName);
                CLMPoAttachmentsTabVOImpl   vo                  = PoAM.getCLMPoAttachmentsTabVO();
                Row row = (Row)vo.getCurrentRow();
                System.out.println("create row");
                row.setAttribute("FileName", fileName);
                row.setAttribute("FileContent", uploadedByteStream);
                System.out.println("Developer Debug Message, insertRow");                              
                dbtransaction.commit();
            }//file uploaded
            else
                throw new OAException("Select file to Upload", OAException.ERROR);
        }//TRY
        catch (Exception e)
        {
            throw new OAException("Exception : "+e.getMessage());        
            // System.out.println("catch upload "+e.getMessage());
            // e.printStackTrace();
        }
        throw new OAException("Uploaded Successfully", (byte)3);
        }
  }
}
