/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package oracle.apps.sfc.clm.poform.webui;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.cabo.ui.data.DataObject;
import oracle.jbo.domain.BlobDomain;
import java.io.InputStream;
import java.io.IOException;

import java.io.OutputStream;

import java.sql.SQLException;

import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OAViewObject;

import oracle.apps.fnd.framework.webui.OADataBoundValueViewObject;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;

import oracle.apps.fnd.framework.webui.beans.message.OAMessageFileUploadBean;

import oracle.jbo.Row;

/**
 * Controller for ...
 */
public class CLMpage1CO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
        super.processRequest(pageContext, webBean);
        
        OAApplicationModule am = pageContext.getApplicationModule(webBean);
        am.invokeMethod("createAttach", null);
        //     
        // OATableBean tableBean =(OATableBean) webBean.findChildRecursive("XxsifyBkChqLeafVO1");
        // message Download  
        // OAMessageDownloadBean downloadBean = (OAMessageDownloadBean)tableBean.findChildRecursive("Attachment");
        // OADataBoundValueViewObject contentBoundValue = new OADataBoundValueViewObject(downloadBean,"FileContentType");
        // downloadBean.setAttributeValue(FILE_CONTENT_TYPE, contentBoundValue);  
        //     
        OAMessageFileUploadBean uploadBean = (OAMessageFileUploadBean)webBean.findChildRecursive("AttachedFile");
        OADataBoundValueViewObject displayNameBoundValue = new OADataBoundValueViewObject(uploadBean, "FileName");
        uploadBean.setAttributeValue(OAWebBeanConstants.DOWNLOAD_FILE_NAME, displayNameBoundValue);
        OADataBoundValueViewObject contentBoundValue = new OADataBoundValueViewObject(uploadBean, "FileContentType");
        uploadBean.setAttributeValue(OAWebBeanConstants.FILE_CONTENT_TYPE, contentBoundValue);
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    OAApplicationModule am = pageContext.getApplicationModule(webBean);
    
    if (pageContext.getParameter("CommitBtn") != null) 
    {
        OAViewObject vo = (OAViewObject)am.findViewObject("XxsifyBkChqLeafVO1");
        oracle.jbo.domain.Number fileId = (oracle.jbo.domain.Number)vo.getCurrentRow().getAttribute("FileId");
        Row row = (Row)vo.getCurrentRow();
        
        DataObject fileUploadData =  (DataObject)pageContext.getNamedDataObject("AttachedFile");
        
        String uFileName = "";          
        if(fileUploadData != null)
        {
            uFileName= fileId.toString()+"_"+(String) fileUploadData.selectValue(null,"UPLOAD_FILE_NAME");
            String contentType =  (String)fileUploadData.selectValue(null,"UPLOAD_FILE_MIME_TYPE");
            row.setAttribute("AttachedFile", createBlobDomain(fileUploadData));
            row.setAttribute("AttachedFileName", uFileName);
            row.setAttribute("Contenttype", contentType);
        }  
        // File Upload Ends 
        
        am.invokeMethod("apply");  
        //                   String fileName = (String)vo.getCurrentRow().getAttribute("AttachedFileName");
        OAException confirmMessage = new OAException("File "+uFileName+" uploaded succesfully .",OAException.CONFIRMATION);              
        pageContext.putDialogMessage(confirmMessage);                    
    }
    if (pageContext.getParameter("execute") != null) 
    {                
        OAViewObject vo = (OAViewObject)am.findViewObject("XxsifyBkChqLeafVO1");
        vo.setWhereClause(null);
        vo.setWhereClauseParams(null);
        vo.executeQuery();
    }        
    
    }
    
    private BlobDomain createBlobDomain(DataObject pfileUploadData)
    {
    // init the internal variables
    InputStream in = null;
    BlobDomain blobDomain = null;
    OutputStream out = null;
    
    try
    {
        String pFileName =  (String) pfileUploadData.selectValue(null,"UPLOAD_FILE_NAME");
        BlobDomain uploadedByteStream = (BlobDomain)pfileUploadData.selectValue(null,pFileName);
        // Get the input stream representing the data from the client
        in = uploadedByteStream.getInputStream();
        // create the BlobDomain datatype to store the data in the db
        blobDomain = new BlobDomain();
        // get the outputStream for hte BlobDomain
        out = blobDomain.getBinaryOutputStream();
        byte buffer[] = new byte[8192];
        for(int bytesRead = 0; (bytesRead = in.read(buffer, 0, 8192)) != -1;)
        out.write(buffer, 0, bytesRead);
        in.close();
    }
    catch (IOException e)
    {
    e.printStackTrace();
    }
    catch (SQLException e)
    {
    e.fillInStackTrace();
    }
        // return the filled BlobDomain
        return blobDomain;
    }
}
  